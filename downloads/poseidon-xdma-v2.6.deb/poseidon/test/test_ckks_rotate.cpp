//
// Created by zjk on 23-4-16.
//

#include <iostream>
#include <fstream>   //头文件包含
#include "../Release/define.h"
#include "../Release/homomorphic_DFT.h"
#include "../Release/common.h"

#include <vector>
#include <complex>

#include "../Release/Ciphertext.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/ParametersLiteral.h"
#include "../Release/util/precision.h"
#include "../Release/util/matrix_operation.h"
#define RNS_C 2
//inline void print_example_banner(std::string title)
//{
//    if (!title.empty())
//    {
//        std::size_t title_length = title.length();
//        std::size_t banner_length = title_length + 2 * 10;
//        std::string banner_top = "+" + std::string(banner_length - 2, '-') + "+";
//        std::string banner_middle = "|" + std::string(9, ' ') + title + std::string(9, ' ') + "|";
//
//        std::cout << std::endl << banner_top << std::endl << banner_middle << std::endl << banner_top << std::endl;
//    }
//}
using  namespace  poseidon;

void test_ckks_rotate(){
    //=====================config======================================
    CKKSParametersLiteralDefault ckks_param_literal(degree_4096);
    poseidon::PoseidonContext context(ckks_param_literal);


    //=====================init random data ============================
    std::vector<std::complex<double>> vec;
    std::vector<std::complex<double>> vec_result;
    std::vector<vector<std::complex<double>>> mat;
    int vec_size = 1 << ckks_param_literal.LogSlots;
    mat.resize(vec_size);
    //create message
    vector<complex<double>> message;
    vector<complex<double>> message1;
    sample_random_complex_vector(message, vec_size);
    sample_random_complex_vector(message1, vec_size);


    //=====================init keys & Plain & Ciph =========================
    Plaintext plainA,plainB,plainRes;
    Ciphertext cipherA,cipherB,cipherRes;
    PublicKey public_key;
    RelinKeys relinKeys;
    GaloisKeys rotKeys;
    GaloisKeys conjKeys;
    vector<int> steps{1,2,3};
    CKKSEncoder ckks_encoder(context);
    //=====================keys  =========================
    KeyGenerator kgen(context);
    kgen.create_public_key(public_key);
    kgen.create_relin_keys(relinKeys);
    kgen.create_galois_keys(steps,rotKeys);
    kgen.create_conj_keys(conjKeys);
    Encryptor enc(context,public_key,kgen.secret_key());
    Decryptor dec(context,kgen.secret_key());

    //===================== Doing ==============================
    //encode
    ckks_encoder.encode(message,plainA,context.scaling_factor());
    ckks_encoder.encode(message1,plainB, context.scaling_factor());
    //encrypt
    enc.encrypt(plainA,cipherA);
    enc.encrypt(plainB,cipherB);

    auto ckks_eva = EvaluatorFactory::SoftFactory()->create(context);

    //rotate
    print_example_banner("Example: Rotation / Rotation in CKKS");
    auto start = chrono::high_resolution_clock::now();
    ckks_eva->rotate(cipherA,cipherRes,rotKeys,1);
    //ckks_eva->add(cipherA,cipherB,cipherRes);
    //ckks_eva->multiply(cipherA,cipherB,cipherRes,relinKeys);

    ckks_eva->read(cipherRes);
    auto stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);
    matrix_operations::rotate(vec_result,-1,vec_result);
//    auto ttt = message;
//    for(int i = 0; i < vec_size; i++){
//        ttt[i] *= message1[i];
//    }
    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]),imag(message[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }

    GetPrecisionStats(vec_result,message);
    return;

    //add
    print_example_banner("Example: Add / Add in CKKS");
    start = chrono::high_resolution_clock::now();
    ckks_eva->add(cipherA,cipherB,cipherRes);
    ckks_eva->read(cipherRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]+message1[i]),imag(message[i]+message1[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }

    //sub
    print_example_banner("Example: Sub / Sub in CKKS");
    start = chrono::high_resolution_clock::now();
    ckks_eva->sub(cipherA,cipherB,cipherRes);
    ckks_eva->read(cipherRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]-message1[i]),imag(message[i]-message1[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }

    //add_plain
    print_example_banner("Example: add_plain / add_plain in CKKS");
    start = chrono::high_resolution_clock::now();
    ckks_eva->add_plain(cipherA,plainB,cipherRes);
    ckks_eva->read(cipherRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]+message1[i]),imag(message[i]+message1[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }

    //multiply_plain
    print_example_banner("Example: multiply_plain / multiply_plain in CKKS");
    start = chrono::high_resolution_clock::now();
    ckks_eva->add_plain(cipherA,plainB,cipherRes);
    ckks_eva->read(cipherRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]*message1[i]),imag(message[i]*message1[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }






    //multiply
    print_example_banner("Example: Multiply / Multiply  in CKKS");
    start = chrono::high_resolution_clock::now();
    ckks_eva->multiply(cipherA,cipherB,cipherRes,relinKeys);
    ckks_eva->read(cipherRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]*message1[i]),imag(message[i]*message1[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }

    //rescale
    print_example_banner("Example: Rescale / Rescale  in CKKS");
    start = chrono::high_resolution_clock::now();
    ckks_eva->rescale(cipherRes);
    ckks_eva->read(cipherRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]*message1[i]),imag(message[i]*message1[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }

    //conjugate
    print_example_banner("Example: Conjugate / Conjugate in CKKS");
    start = chrono::high_resolution_clock::now();
    ckks_eva->conjugate(cipherA,cipherRes,conjKeys);
    ckks_eva->read(cipherRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]),imag(-message[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }



}