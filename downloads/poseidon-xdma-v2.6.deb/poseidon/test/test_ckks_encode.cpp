//
// Created by zjk on 23-4-16.
//

#include <iostream>
#include <fstream>   //头文件包含



#include <vector>
#include <complex>

#include "../Release/Ciphertext.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/Evaluator.h"
#include "../Release/ParametersLiteral.h"


#define RNS_C 2

using  namespace  poseidon::util;


void test_ckks_encode(){
    //=====================config======================================

    CKKSParametersLiteralDefault ckks_param_literal(degree_16384);
    poseidon::PoseidonContext context(ckks_param_literal);
    auto start = chrono::high_resolution_clock::now();
    auto stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;
    //=====================init random data ============================
    std::vector<std::complex<double>> vec;
    std::vector<std::complex<double>> vec_result;
    std::vector<vector<std::complex<double>>> mat;
    int vec_size = 1 << ckks_param_literal.LogSlots;
    mat.resize(vec_size);
    //create message
    vector<complex<double>> message(vec_size);
    vector<complex<double>> message1;
    sample_random_complex_vector(message, vec_size);
    auto pi = 3.141592653589793;
//    for(auto i = 0; i < vec_size; i++) {
//        message[i] = complex<double>(0.38- (double)i/(double)vec_size, 0.62 -(double) i/(double)vec_size);
//    }
    sample_random_complex_vector(message1, vec_size);


    //=====================init keys & Plain & Ciph =========================
    Plaintext plainA,plainB,plainRes;
    Ciphertext cipherA,cipherB,cipherRes,cipherRes2;
    PublicKey public_key;
    RelinKeys relinKeys;
    GaloisKeys rotKeys;
    GaloisKeys conjKeys;
    vector<int> steps{1,2,3};
    CKKSEncoder ckks_encoder(context);
    //=====================keys  =========================
    KeyGenerator kgen(context);
    kgen.create_public_key(public_key);
    Encryptor enc(context,public_key,kgen.secret_key());
    Decryptor dec(context,kgen.secret_key());

    //===================== Doing ==============================
    //encode
    start = chrono::high_resolution_clock::now();
    ckks_encoder.encode(message,plainA, (uint64_t)1 << 45);

    //encrypt
    enc.encrypt(plainA,cipherA);




    //decode & decrypt
    dec.decrypt(cipherA,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]),imag(message[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }
    GetPrecisionStats(vec_result,message);

    
}