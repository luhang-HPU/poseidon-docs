//
// Created by zjk on 23-4-16.
//

#include <iostream>
#include <fstream>   //头文件包含
#include "../Release/define.h"
#include "../Release/homomorphic_DFT.h"


#include <cstdlib>
#include <vector>
#include <cmath>
#include <complex>


#include "../Release/util/number_theory.h"
#include "../Release/hardware/ConfigGen.h"

#include <gmpxx.h>
#include "../Release/Ciphertext.h"

#include "../Release/util/matrix_operation.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/BatchEncoder.h"
#include "../Release/random/random_sample.h"

#include "../Release/random/RandomGen.h"
#include "../Release/random/Blake2xbPRNG.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/ParametersLiteral.h"
#include "../Release/rlwe.h"
#include "../Release/RelinKeys.h"
#include "../Release/Evaluator.h"
#include "../Release/HardwareEvaluator.h"
#define RNS_C 2
#include "../Release/linear_transform.h"
#include "../Release/util/matrix_operation.h"
using  namespace  poseidon;




void test(){




    //=====================config======================================

    //BFVParametersLiteralDefault ckks_param_literal(degree_8192);
    CKKSParametersLiteralDefault ckks_param_literal(degree_8192);
    PoseidonContext context(ckks_param_literal);

    auto rng = make_shared<Blake2xbPRNGFactory>(Blake2xbPRNGFactory());
    context.set_random_generator(rng);
    //HomomorphicDFTMatrixLiteral d(0, ckks_param_literal.LogN, ckks_param_literal.LogSlots, 19, vector<int>(3, 1), true, 0.062499999999090505, false, 1);
    HomomorphicDFTMatrixLiteral d(0, ckks_param_literal.LogN, ckks_param_literal.LogSlots, 19, vector<int>(3, 1), true, 0.0, false, 1);

//  //=======================+++++++++++++++++++++++++
//    vector <uint64_t> aa;
//    vector <uint64_t> bb;
//    for(int i = 0; i < 2048; i++){
//        aa.push_back(i);
//        bb.push_back(i);
//    }
//    int delta = 555;
//    uint64_t mod = context.crt_context()->primes()[0];
//    apsi::util::cal_matching_polyn(aa,bb,mod,delta);









    //=====================init random data ============================
    std::vector<std::complex<double>> vec;
    std::vector<std::complex<double>> vec_result;
    std::vector<vector<std::complex<double>>> mat;
    int mat_size = 1 << ckks_param_literal.LogSlots;
    mat.resize(mat_size);
    //create message
    vector<complex<double>> message;
    vector<complex<double>> message1;
    vector<complex<double>> message_tmp;
    vector<complex<double>> message_sum(mat_size << 1,0.0);
    sample_random_complex_vector(message, mat_size);
    sample_random_complex_vector(message1, mat_size);

    FFT aa(context.poly_degree()*2);
    auto messageReal = message;
    auto messageImag = message;
    std::vector<std::complex<double>> messageReal2(1 << ckks_param_literal.LogSlots);
    std::vector<std::complex<double>> messageReal3(1 << ckks_param_literal.LogSlots);
    for(int i = 0; i < message.size();i++){
        messageReal[i].imag(0);
        messageImag[i].imag(0);
        messageImag[i].real(message[i].imag());
    }
    aa.embedding_inv(messageReal,messageReal2,1 << ckks_param_literal.LogSlots);
    aa.embedding_inv(messageImag,messageReal3,1 << ckks_param_literal.LogSlots);


    //=====================init  Plain & Ciph =========================
    Plaintext plainA,plainB,plainRes,plainT;
    Ciphertext cipherA,cipherB,cipherRes,cipherRes1,cipherRes2,cipherRes3;
    PublicKey public_key;
    RelinKeys relinKeys;
    GaloisKeys rotKeys;
    GaloisKeys conjKeys;
    vector<uint32_t> rot_elemt;
    CKKSEncoder ckks_encoder(context);

//    //=====================GenMatrices  =========================
//
//    auto x = d.GenMatrices();
//    vector<int> rotarion_steps;
//
//    vector<MatrixPlain> plain_mat( x.size());
//
    auto start = chrono::high_resolution_clock::now();
//    int leveld = d.getLevelStart();
//    for(int i = 0; i < x.size(); i++){
//
//        GenLinearTransformBSGS(plain_mat[i],rotarion_steps, ckks_encoder, x[i],  leveld, context.crt_context()->primes()[leveld] ,0,d.getLogSlots());
//        leveld--;
//    }
//
//    for(int i = 0; i < x.size(); i++) {
//        for(auto tt : x[i]){
//            matrix_operations::multiply(message,tt.second,message_tmp);
//            matrix_operations::rotate(message_tmp,-tt.first,message1);
//            matrix_operations::add(message1,message_sum,message_sum);
//        }
//
//    }



//    auto stop = chrono::high_resolution_clock::now();
//    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);
//    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //=====================keys  =========================
    //rot_elemt.push_back(25);
    KeyGenerator kgen(context);
    kgen.create_public_key(public_key);
    kgen.create_relin_keys(relinKeys);
    //kgen.create_galois_keys(rotarion_steps,rotKeys);
   // kgen.create_galois_keys(rot_elemt,rotKeys);
    kgen.create_conj_keys(conjKeys);

    Encryptor enc(context,public_key,kgen.secret_key());
    Decryptor dec(context,kgen.secret_key());
    //===================== Doing ==============================
    //encode
    ckks_encoder.encode(message,plainA,context.scaling_factor());
    ckks_encoder.encode(message1,plainB, context.crt_context()->primes_q()[plainA.metaData()->getLevel()]);

    //encrypt
    enc.encrypt(plainA,cipherA);
    enc.encrypt(plainB,cipherB);
    //evaluate
    auto ckks_eva = EvaluatorFactory::SoftFactory()->create(context);
     //ckks_eva->add(cipherA,cipherB,cipherRes);
    //ckks_eva.sub(cipherA,cipherB,cipherRes);
    //ckks_eva->add_plain(cipherA,plainB,cipherRes);
    //ckks_eva->multiply_plain( cipherA,plainB,cipherRes);//
    ckks_eva->multiply( cipherA,cipherB,cipherRes,relinKeys);
    //ckks_eva->conjugate(cipherA,cipherRes,conjKeys);
    //ckks_eva->ftt_inv(cipherA,cipherA);
    //ckks_eva->ftt_fwd(cipherA,cipherRes);
    //ckks_eva->rotate(cipherA,cipherRes,rotKeys,25);
    //ckks_eva->conjugate(cipherA,cipherRes,conjKeys);
    //ckks_eva->rescale(cipherRes,cipherRes);
    //ckks_eva->read(cipherRes);
    cout << "111"<< endl;
    start = chrono::high_resolution_clock::now();
//    ckks_eva->multiplyByDiagMatrixBSGS(cipherA,plain_mat[0],cipherRes1,rotKeys);
//    ckks_eva->multiplyByDiagMatrixBSGS(cipherRes1,plain_mat[1],cipherRes1,rotKeys);
//    ckks_eva->multiplyByDiagMatrixBSGS(cipherRes1,plain_mat[2],cipherRes1,rotKeys);

    ckks_eva->conjugate(cipherRes1,cipherRes2,conjKeys);
    ckks_eva->add(cipherRes1,cipherRes2,cipherRes3);

//    stop = chrono::high_resolution_clock::now();
//    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
//    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;
    //ckks_eva->read(cipherRes);

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);



    for(int i = 0; i < 10; i++){
        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal2[i].real()),imag(messageReal2[i].real()));
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message1[i]*message[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }
    int a = 0;




}