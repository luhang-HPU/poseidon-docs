//
// Created by zjk on 23-4-16.
//

#include <iostream>
#include <fstream>   //头文件包含
#include <algorithm>
#include <memory>
#include <sstream>
#include <string>
#include <vector>
#include <gmpxx.h>
#include <complex>

#include "../Release/util/number_theory.h"
#include "../Release/hardware/ConfigGen.h"
#include "../Release/Ciphertext.h"

#include "../Release/util/matrix_operation.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/BatchEncoder.h"
#include "../Release/random/random_sample.h"
#include "../Release/random/RandomGen.h"
#include "../Release/random/Blake2xbPRNG.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/ParametersLiteral.h"
#include "../Release/rlwe.h"
#include "../Release/RelinKeys.h"

#include "../Release/Evaluator.h"
#include "../Release/HardwareEvaluator.h"

#include "../Release/bfv/MemoryPool2.h"
#include "../Release/linear_transform.h"
#include "../Release/util/matrix_operation.h"
using  namespace  poseidon;
//std::vector<std::uint32_t> getBytes(std::string const &s)
//{
//    std::vector<std::uint32_t> bytes;
//    bytes.reserve(std::size(s));
//
//    std::transform(std::begin(s), std::end(s), std::back_inserter(bytes), [](char const &c){
//        return std::uint32_t(c);
//    });
//
//    return bytes;
//}


void test_bfv_matrixPir(){

    //=====================config======================================
    BFVParametersLiteralDefault bfv_param_literal(degree_16);
    PoseidonContext context(bfv_param_literal);
    auto rng = make_shared<Blake2xbPRNGFactory>(Blake2xbPRNGFactory());
    context.set_random_generator(rng);


    //=====================init random data ============================
    std::vector<uint32_t> vec;
    std::vector<uint32_t> vec_result,vec_result1;
    int mat_size = 1 << bfv_param_literal.LogSlots;
    std::vector<vector<uint32_t>> mat(mat_size,vector<uint32_t>(mat_size,0));
    std::vector<vector<uint32_t>> mat_T(mat_size);//(mat_size,vector<complex<double>>(mat_size));
    std::vector<vector<uint32_t>> mat_T1;
    //create message
    BatchEncoder bfv_encoder(context);
    vector<uint32_t> message(mat_size,0);
    message[0] = 1;

    //=====================init  Plain & Ciph =========================
    Plaintext plainA,plainB,plainRes,plainRes1,plainT;
    Ciphertext cipherA,cipherB,cipherRes,cipherRes1,cipherRes2,cipherRes3;
    PublicKey public_key;
    RelinKeys relinKeys;
    GaloisKeys rotKeys;
    GaloisKeys conjKeys;
    vector<uint32_t> rot_elemt;

    bfv_encoder.encode(message,plainA);
    //=====================GenMatrices  ========================
    MatrixPlain matrixPlain;

    for(int i = 0; i < mat_size; i++){
        sample_random_vector(mat[i],mat_size,100);
    }
    int level = context.crt_context()->maxLevel();
    matrix_operations::transpose_matrix(mat,mat_T1);
    for(int i = 0; i < mat.size(); i++){
        matrix_operations::diagonal(mat_T1, i,mat_T[i]);
    }
    GenMatrixformBSGS(matrixPlain,matrixPlain.rot_index, bfv_encoder, mat_T,
                      level ,context.crt_context()->primes_q()[level], 1, bfv_param_literal.LogSlots);






    //=====================keys  =========================
    //
    KeyGenerator kgen(context);
    kgen.create_public_key(public_key);

    kgen.create_relin_keys(relinKeys);
    vector<int> rot_index_tmp;
    for(auto index : matrixPlain.rot_index){
        if(index >= mat_size/2){
            rot_index_tmp.push_back(index - mat_size/2);
        }
        else{
            rot_index_tmp.push_back(index);
        }
    }
    rot_index_tmp.push_back(0);
    kgen.create_galois_keys(rot_index_tmp,rotKeys);
    // kgen.create_galois_keys(rot_elemt,rotKeys);
    kgen.create_conj_keys(conjKeys);

    Encryptor enc(context,public_key,kgen.secret_key());
    Decryptor dec(context,kgen.secret_key());
    //===================== Doing ==============================
    //encode

    bfv_encoder.encode(message,plainA);

    //encrypt
    enc.encrypt(plainA,cipherA);
    //evaluate
    auto ckks_eva = EvaluatorFactory::SoftFactory()->create(context);
    cout << "111"<< endl;
    auto start = chrono::high_resolution_clock::now();

    ckks_eva->multiplyByDiagMatrixBSGS(cipherA,matrixPlain,cipherRes,rotKeys);
    ckks_eva->read(cipherRes);

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    bfv_encoder.decode(plainRes,vec_result);


    for(int i = 0; i < 8; i++){
        printf("soft vec[%d] : %d  \n",i,mat[0][i]);
        printf("result vec[%d] : %d  \n",i,vec_result[i]);
    }



}