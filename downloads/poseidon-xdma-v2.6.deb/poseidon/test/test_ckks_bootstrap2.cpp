//
// Created by zjk on 23-4-16.
//

#include <iostream>
#include <fstream>   //头文件包含
#include "../Release/define.h"
#include "../Release/homomorphic_DFT.h"
#include "../Release/linear_transform.h"

#include <cstdlib>
#include <vector>
#include <cmath>
#include <complex>


#include "../Release/util/number_theory.h"
#include "../Release/hardware/ConfigGen.h"
#include <gmpxx.h>
#include "../Release/Ciphertext.h"

#include "../Release/util/matrix_operation.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/BatchEncoder.h"
#include "../Release/random/random_sample.h"

#include "../Release/random/RandomGen.h"
#include "../Release/random/Blake2xbPRNG.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/ParametersLiteral.h"
#include "../Release/rlwe.h"
#include "../Release/RelinKeys.h"

#include "../Release/HardwareEvaluator.h"
#define RNS_C 2
#include "../Release/linear_transform.h"
#include "../Release/util/matrix_operation.h"
#include "../Release/homomorphic_mod.h"
#include "../Release/util/precision.h"
using  namespace  poseidon;

void test_ckks_bootstrap2(){

    uint32_t q0_bit = 63;
    auto q_def = 31;
    vector<uint32_t> logQTmp{31,31,31,31,31,31,31,31,31,31,  31,31,31,31,31,31,31,31,31,31,  31,31,31,31,31,31,31,31,31,31}; //,31,31,31,31,31,31,31,31,31,31
    vector<uint32_t> logPTmp{31,31,31,31,31,31,31,31,31,31,  31,31,31,31,31,31,31,31,31,31,  31,31,31,31,31,31,31,31,31,31};//,31,31,31,31,31,31,31,31,31,31
    ParametersLiteral ckks_param_literal(CKKS, 11, 10, logQTmp, logPTmp, q_def, 30,0,1);


    //=====================config======================================
    PoseidonContext context(ckks_param_literal);
    auto q0 = context.crt_context()->q0();
    //=====================init random data ============================
    std::vector<std::complex<double>> vec;
    std::vector<std::complex<double>> vec_result,vec_result1;
    std::vector<vector<std::complex<double>>> mat;
    int mat_size = 1 << ckks_param_literal.LogSlots;
    mat.resize(mat_size);
    //create message
    vector<complex<double>> message;
    vector<complex<double>> message1;
    sample_random_complex_vector(message, mat_size);
    message[0] = complex<double>(0.5,0.5);

    //=====================init  Plain & Ciph =========================
    Plaintext plainA,plainB,plainRes,plainRes1,plainT;
    Ciphertext cipherA,cipherB,cipherRes,cipherRes1,cipherRes2,cipherRes3;
    PublicKey public_key;
    RelinKeys relinKeys;
    GaloisKeys rotKeys;
    GaloisKeys conjKeys;
    vector<uint32_t> rot_elemt;
    //

    CKKSEncoder ckks_encoder(context);

    //=====================EvalMod  ========================
    auto level_start = ckks_param_literal.LogQ.size() - 1;

    EvalModPoly evalModPoly(context, CosDiscrete,(uint64_t)1 << (q0_bit - 25) ,level_start-6,8, 3,16,0,30);
    auto scFac = evalModPoly.ScFac();
    double K = evalModPoly.K();
    auto qDiff = evalModPoly.QDiff();
    auto q0OverMessageRatio = exp2(round(log2((double)q0 / (double)evalModPoly.MessageRatio()) ) ) ;
    // If the scale used during the EvalMod step is smaller than Q0, then we cannot increase the scale during
    // the EvalMod step to get a free division by MessageRatio, and we need to do this division (totally or partly)
    // during the CoeffstoSlots step

    auto CoeffsToSlotsScaling = 1.0;
    CoeffsToSlotsScaling *= evalModPoly.qDiv() / (K * scFac * qDiff);

    auto SlotsToCoeffsScaling = (double)context.scaling_factor().get_ui();
    SlotsToCoeffsScaling = SlotsToCoeffsScaling / ((double)evalModPoly.ScalingFactor().get_ui() / (double)evalModPoly.MessageRatio() );
    //auto SlotsToCoeffsScaling = 1;


    HomomorphicDFTMatrixLiteral d(0, ckks_param_literal.LogN, ckks_param_literal.LogSlots, level_start, vector<int>(3,1), true, CoeffsToSlotsScaling, false, 1);

//    EvalModPoly evalModPoly(context, poseidon::CosDiscrete,(int64_t)1 << 36 ,level_start-3,4, 3,14,7,32);
    // -1 : slot_to_coeff imag multiply -1i real low modulus , dft start at level 8
    HomomorphicDFTMatrixLiteral x(1, ckks_param_literal.LogN, ckks_param_literal.LogSlots,  8 , vector<int>(3,1), true, SlotsToCoeffsScaling, false, 1);
    LinearMatrixGroup mat_group;
    LinearMatrixGroup mat_group_dec;
    d.create(mat_group,ckks_encoder,2);
    x.create(mat_group_dec,ckks_encoder,1);





    //=====================keys  =========================
    KeyGenerator kgen(context);
    kgen.create_public_key(public_key);
    kgen.create_relin_keys(relinKeys);
    kgen.create_galois_keys(mat_group.rot_index(),rotKeys);
    kgen.create_conj_keys(conjKeys);

    Encryptor enc(context,public_key,kgen.secret_key());
    Decryptor dec(context,kgen.secret_key());

    //===================== Doing ==============================
    //encode
    ckks_encoder.encode(message,plainA,(int64_t) 1 << q_def );
    //ckks_encoder.encode(message,plainB,context.scaling_factor());
    //encrypt
    enc.encrypt(plainA,cipherA);
    //enc.encrypt(plainB,cipherB);
    //evaluate

    auto ckks_eva = EvaluatorFactory::SoftFactory()->create(context);
    cout << "111"<< endl;
    //ckks_eva->evaluatePolyVector(cipherA,cipherRes,polys,cipherA.metaData()->getScalingFactor(),relinKeys,ckks_encoder);



    // Scale the message to Delta = Q/MessageRatio

    auto start = chrono::high_resolution_clock::now();
    //ckks_eva->multiply_const(cipherA,10,cipherA);
    //ckks_eva->multiply(cipherA,cipherA,cipherA,relinKeys);
    ckks_eva->bootstrap(cipherA,cipherRes,evalModPoly,mat_group,mat_group_dec,relinKeys,rotKeys,conjKeys,ckks_encoder);
    auto stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;
    //ckks_eva->multiply( cipherA,cipherA,cipherRes,relinKeys);
    ckks_eva->read(cipherRes);
//    auto stop = chrono::high_resolution_clock::now();
//    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);
//    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;
    //decode & decrypt

    dec.decrypt(cipherRes,plainRes);
/*
    ckks_eva->ftt_inv(plainRes,plainRes);
    ckks_eva->ftt_inv(plainA,plainA);
    mpz_t  ww[2048];
    mpz_t  zz[2048];
    mpz_t  tt[2048];
    mpz_t coeff_modulus;
    mpz_init_set_ui(coeff_modulus,1);
    for(int i = 0; i < 2048; i++){
        mpz_init(ww[i]);
        mpz_init(zz[i]);
        mpz_init(tt[i]);
    }


    for(int i = 0; i < context.crt_context()->num_primes_q(); i++){
        mpz_mul_ui(coeff_modulus,coeff_modulus,context.crt_context()->primes_q()[i]);
    }
    auto mod_num = plainRes.metaData()->getLevel() + 1;
    vector<uint32_t> modulus(context.crt_context()->primes_q());
    modulus.resize(mod_num);
    Util::conv_rns_to_x(modulus,plainRes.poly()->rns_coeffs_q, ww, 1<<ckks_param_literal.LogN);
    Util::conv_rns_to_x(context.crt_context()->primes_q(),plainA.poly()->rns_coeffs_q, zz, 1<<ckks_param_literal.LogN);
    gmp_printf("mod: %Zd\n",coeff_modulus);
    for(int i = 0; i < 10; i++){
        gmp_printf("ww: %Zd\n",ww[i]);
        gmp_printf("zz: %Zd\n",zz[i]);


    }

    //return;
    mpz_class ttttmp;
    uint64_t tt_tmp;
    int flag = 0;
    //auto q0_div_2 = context.crt_context()->primes_q()[0] / 2;
    mpz_class q0_v = context.crt_context()->q0();
    mpz_class q0_div_2 = context.crt_context()->q0();
    mpz_div_ui(q0_div_2.get_mpz_t(),q0_div_2.get_mpz_t(),2);



    for(int i = 0; i < 2048; i++){
        mpz_mod_ui(tt[i],ww[i],context.crt_context()->q0());
        auto pos = mpz_cmp(tt[i],q0_div_2.get_mpz_t());
        if(pos > 0){
            flag = 1;
            mpz_sub(tt[i],q0_v.get_mpz_t(),tt[i]);
        }
        else{
            flag = 0;
        }
        for(int j = 0; j < mod_num; j++){
            mpz_mod_ui(ttttmp.get_mpz_t(),tt[i],context.crt_context()->primes_q()[j]);
            if(flag == 1){
                plainRes.poly()->rns_coeffs_q[j][i] = context.crt_context()->primes_q()[j] - ttttmp.get_ui();
            }
            else if(flag == 0) {
                plainRes.poly()->rns_coeffs_q[j][i] = ttttmp.get_ui();
            }
        }
    }

//    for(int i = 0; i < 5; i++){
//        gmp_printf("src plain: %Zd\n",zz[i]);
//        gmp_printf("res plain: %Zd\n",ww[i]);
//        gmp_printf("pos res plain: %Zd\n",tt[i]);
//    }

    ckks_eva->ftt_fwd(plainRes,plainRes);









    //dec.decrypt(cipherA,plainRes);
*/

    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < mat_size; i++){
        //message[i] *= 10;
        //message[i]*=  message[i];
    }
    for(int i = 0; i < 10; i++){

        printf("source vec[%d] : %0.10f + %0.10f I \n",i,(real(message[i])), imag(message[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,(real(vec_result[i])), imag(vec_result[i]));
    }
    GetPrecisionStats(vec_result,message);





}