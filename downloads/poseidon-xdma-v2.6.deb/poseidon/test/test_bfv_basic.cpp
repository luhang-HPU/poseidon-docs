//
// Created by zjk on 23-4-16.
//
//#include <SEAL-4.1/seal/ciphertext.h>
//#include <SEAL-4.1/seal/ciphertext.h>
//#include <SEAL-4.1/seal/ciphertext.h>
//#include <SEAL-4.1/seal/plaintext.h>
//#include <SEAL-4.1/seal/encryptionparams.h>
//#include <SEAL-4.1/seal/seal.h>
//#include <SEAL-4.1/seal/modulus.h>
//#include <SEAL-4.1/seal/context.h>
//#include <SEAL-4.1/seal/keygenerator.h>
//#include <SEAL-4.1/seal/publickey.h>
//#include <SEAL-4.1/seal/relinkeys.h>
//#include <SEAL-4.1/seal/secretkey.h>
//#include <SEAL-4.1/seal/evaluator.h>
//#include <SEAL-4.1/seal/batchencoder.h>
//#include <SEAL-4.1/seal/decryptor.h>
//#include <SEAL-4.1/seal/util/uintcore.h>
//#include <SEAL-4.1/seal/encryptor.h>
#include <iostream>
#include <fstream>   //头文件包含
#include "../Release/define.h"
#include "../Release/homomorphic_DFT.h"

#include <algorithm>
#include <chrono>
#include <cstddef>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <mutex>
#include <numeric>
#include <random>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
#include <gmpxx.h>

#include <cstdlib>
#include <vector>
#include <cmath>
#include <complex>


#include "../Release/util/number_theory.h"
#include "../Release/hardware/ConfigGen.h"

#include <gmpxx.h>
#include "../Release/Ciphertext.h"

#include "../Release/util/matrix_operation.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/BatchEncoder.h"
#include "../Release/random/random_sample.h"

#include "../Release/random/RandomGen.h"
#include "../Release/random/Blake2xbPRNG.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/ParametersLiteral.h"
#include "../Release/rlwe.h"
#include "../Release/RelinKeys.h"

#include "../Release/Evaluator.h"
#include "../Release/HardwareEvaluator.h"

#include "../Release/bfv/MemoryPool2.h"
#define RNS_C 2
#include "../Release/linear_transform.h"
#include "../Release/util/matrix_operation.h"
#include "../Release/util/cosine_approx.h"
using  namespace  poseidon;

//unsigned int bit_reversett(unsigned int n, uint32_t bits) {
//    unsigned int reversed = 0;
//    for (uint32_t i = 0; i < bits; i++) {
//        reversed <<= 1;
//        reversed |= n & 1;
//        n >>= 1;
//    }
//
//    return reversed;
//}
//
//std::vector<uint32_t> bit_reverse_vectt(const std::vector<uint32_t> &vec){
//    std::vector<uint32_t> res(vec.size(), 0);
//    auto length_log2 = (uint32_t)log2(vec.size());
//    for(size_t i=0;i<vec.size();i++){
//        res[i]=vec[bit_reversett(i, length_log2)];
//    }
//    return res;
//}
using namespace poseidon::util;
void test_bfv_basic(){

    //auto aa =  ApproximateCos(16, 30,1 << 8,3);
    //=====================config======================================
//    seal::EncryptionParameters parms(seal::scheme_type::bfv);
//    size_t poly_modulus_degree = 2048<<1;
//    parms.set_poly_modulus_degree(poly_modulus_degree);
//    parms.set_coeff_modulus(seal::CoeffModulus::BFVDefault(poly_modulus_degree));
//    parms.set_plain_modulus(seal::PlainModulus::Batching(poly_modulus_degree, 20));
//
//    seal::SEALContext contextseal(parms);
//    seal::KeyGenerator keygen(contextseal);
//    seal::SecretKey secret_key = keygen.secret_key();







    BFVParametersLiteralDefault ckks_param_literal(degree_16384);
    PoseidonContext context(ckks_param_literal);

    //=====================BFV ============================
    PublicKey public_key1;
    Plaintext plainA,plainB,plainC,plainD;
    Ciphertext ciphA,ciphB,ciphC,ciphD,ciphRes;
    RelinKeys relinKeys;
    GaloisKeys rotKeys;
    uint32_t degree = 1 << ckks_param_literal.LogN;
    vector<uint32_t> rot_elemt{degree*2-1,25};
    //KeyGenerator kgen1(context,aa);
    KeyGenerator kgen1(context);


    kgen1.create_public_key(public_key1);
    kgen1.create_relin_keys(relinKeys);
    kgen1.create_galois_keys(rot_elemt,rotKeys);
    Encryptor enc1(context,public_key1,kgen1.secret_key());
    Decryptor dec1(context,kgen1.secret_key());


    default_random_engine e;
    vector<uint32_t> ccc,ddd;
    uniform_int_distribution<unsigned >u(0, sqrt(ckks_param_literal.T));
    for(int i = 0; i < 1 << ckks_param_literal.LogSlots; i++){
        ccc.push_back(i);
        //ccc.push_back(u(e));
    }
    BatchEncoder bfvenc(context);
    bfvenc.encode(ccc,plainA);
    bfvenc.encode(ccc,plainB);
    enc1.encrypt(plainA,ciphA);
    enc1.encrypt(plainB,ciphB);

    auto eva = EvaluatorFactory::DefaultFactory()->create(context,relinKeys);

    //ADD
    print_example_banner("Example: Add / Add in BFV");
    auto start = chrono::high_resolution_clock::now();
    eva->add(ciphA,ciphB,ciphRes);
    eva->read(ciphRes);
    auto stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    dec1.decrypt(ciphRes,plainD);
    bfvenc.decode(plainD,ddd);
    for(int i = 0; i < 10; i++){
        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal2[i].real()),imag(messageReal2[i].real()));
        printf("source vec[%d] : %ld \n",i,ccc[i]);
        printf("result vec[%d] : %ld \n",i,ddd[i]);
    }

//SUB
    print_example_banner("Example: SUB / SUB in BFV");
    start = chrono::high_resolution_clock::now();
    eva->sub(ciphA,ciphB,ciphRes);
    eva->read(ciphRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    dec1.decrypt(ciphRes,plainD);
    bfvenc.decode(plainD,ddd);
    for(int i = 0; i < 10; i++){
        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal2[i].real()),imag(messageReal2[i].real()));
        printf("source vec[%d] : %ld \n",i,ccc[i]);
        printf("result vec[%d] : %ld \n",i,ddd[i]);
    }

    //ADD_PLAIN
    print_example_banner("Example: ADD_PLAIN / ADD_PLAIN in BFV");
    start = chrono::high_resolution_clock::now();
    eva->add_plain(ciphA,plainB,ciphRes);
    eva->read(ciphRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    dec1.decrypt(ciphRes,plainD);
    bfvenc.decode(plainD,ddd);
    for(int i = 0; i < 10; i++){
        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal2[i].real()),imag(messageReal2[i].real()));
        printf("source vec[%d] : %ld \n",i,ccc[i]);
        printf("result vec[%d] : %ld \n",i,ddd[i]);
    }


    //MULTIPLY_PLAIN
    print_example_banner("Example: MULTIPLY_PLAIN / MULTIPLY_PLAIN in BFV");
    start = chrono::high_resolution_clock::now();
    eva->multiply_plain(ciphA,plainB,ciphRes);
    eva->read(ciphRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    dec1.decrypt(ciphRes,plainD);
    bfvenc.decode(plainD,ddd);
    for(int i = 0; i < 10; i++){
        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal2[i].real()),imag(messageReal2[i].real()));
        printf("source vec[%d] : %ld \n",i,ccc[i]);
        printf("result vec[%d] : %ld \n",i,ddd[i]);
    }

    //rotate_row
    print_example_banner("Example: ROTATE_ROW / ROTATE_ROW in BFV");
    start = chrono::high_resolution_clock::now();
    eva->rotate_row(ciphA,2,rotKeys, ciphRes);
    eva->read(ciphRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    dec1.decrypt(ciphRes,plainD);
    bfvenc.decode(plainD,ddd);
    for(int i = 0; i < 10; i++){
        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal2[i].real()),imag(messageReal2[i].real()));
        printf("source vec[%d] : %ld \n",i,ccc[i]);
        printf("result vec[%d] : %ld \n",i,ddd[i]);
    }

    //rotate_col
    print_example_banner("Example: ROTATE_COL / ROTATE_COL in BFV");
    start = chrono::high_resolution_clock::now();
    eva->rotate_col(ciphA,rotKeys, ciphRes);
    eva->read(ciphRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    dec1.decrypt(ciphRes,plainD);
    bfvenc.decode(plainD,ddd);
    for(int i = 0; i < 10; i++){
        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal2[i].real()),imag(messageReal2[i].real()));
        printf("source vec[%d] : %ld \n",i,ccc[i]);
        printf("result vec[%d] : %ld \n",i,ddd[i]);
    }

    //MULTIPLY
    print_example_banner("Example: MULTIPLY / MULTIPLY in BFV");
    start = chrono::high_resolution_clock::now();
    eva->multiply(ciphA,ciphB, ciphRes,relinKeys);
    eva->read(ciphRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    dec1.decrypt(ciphRes,plainD);
    bfvenc.decode(plainD,ddd);
    for(int i = 0; i < 10; i++){
        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal2[i].real()),imag(messageReal2[i].real()));
        printf("source vec[%d] : %ld \n",i,ccc[i]*ccc[i]);
        printf("result vec[%d] : %ld \n",i,ddd[i]);
    }

}

