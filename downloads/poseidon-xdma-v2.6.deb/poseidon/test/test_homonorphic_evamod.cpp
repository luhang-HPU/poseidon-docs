//
// Created by zjk on 23-4-16.
//

#include <iostream>
#include <fstream>   //头文件包含
#include "../Release/define.h"
#include "../Release/homomorphic_DFT.h"
#include "../Release/linear_transform.h"

#include <cstdlib>
#include <vector>
#include <cmath>
#include <complex>


#include "../Release/util/number_theory.h"
#include "../Release/hardware/ConfigGen.h"
#include <gmpxx.h>
#include "../Release/Ciphertext.h"

#include "../Release/util/matrix_operation.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/BatchEncoder.h"
#include "../Release/random/random_sample.h"

#include "../Release/random/RandomGen.h"
#include "../Release/random/Blake2xbPRNG.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/ParametersLiteral.h"
#include "../Release/rlwe.h"
#include "../Release/RelinKeys.h"

#include "../Release/HardwareEvaluator.h"
#define RNS_C 2
#include "../Release/linear_transform.h"
#include "../Release/util/matrix_operation.h"
#include "../Release/homomorphic_mod.h"
using  namespace  poseidon;

double fiii(double x)  {
    //return  1 / (exp(-x) + 1);
    return sin(6.283185307179586 * x) ;
}


void test_homonorphic_evamod(){

    //=====================config======================================
    //BFVParametersLiteralDefault ckks_param_literal(degree_2048);
    CKKSParametersLiteralDefault ckks_param_literal(degree_2048);
    PoseidonContext context(ckks_param_literal);

    auto rng = make_shared<Blake2xbPRNGFactory>(Blake2xbPRNGFactory());
    context.set_random_generator(rng);

    //=====================init random data ============================
    std::vector<std::complex<double>> vec;
    std::vector<std::complex<double>> vec_result,vec_result1;
    std::vector<vector<std::complex<double>>> mat;
    int mat_size = 1 << ckks_param_literal.LogSlots;
    mat.resize(mat_size);
    //create message
    vector<complex<double>> message;
    vector<complex<double>> message1;
    sample_random_complex_vector(message, mat_size);
    sample_random_complex_vector(message1, mat_size);

    //=====================init  Plain & Ciph =========================
    Plaintext plainA,plainB,plainRes,plainRes1,plainT;
    Ciphertext cipherA,cipherB,cipherRes,cipherRes1,cipherRes2,cipherRes3;
    PublicKey public_key;
    RelinKeys relinKeys;
    GaloisKeys rotKeys;
    GaloisKeys conjKeys;
    vector<uint32_t> rot_elemt;
    CKKSEncoder ckks_encoder(context);
    //=====================EvalMod  ========================
    EvalModPoly evalModPoly(context, SinContinuous,(int64_t)1 << 31+4 ,18,4, 0,14,7,128);

    //===================== EvalMod test data====================
    vector<complex<double>> kq_values(1 << ckks_param_literal.LogSlots);
    int k = evalModPoly.K();
//    double q_0 = context.crt_context()->primes_q()[0];
    double q_0 = context.crt_context()->q0();

    double Q = (double)context.crt_context()->q0() / exp2(round(log2((double)context.crt_context()->primes_q()[0]))) * (double) evalModPoly.MessageRatio();
    uniform_real_distribution<double> u(-k, k);
    uniform_real_distribution<double> u2(-1, 1);
    default_random_engine e(time(NULL));
    for(int i = 0; i < kq_values.size();i++){
        double r1 = u(e);
        double r2 = u2(e);
        kq_values[i] = complex<double>(round(r1)*Q+r2,0);
        //kq_values[i] = complex<double>(r2,0);

    }

    vector <Polynomial> poly_v{evalModPoly.arcsinPoly()};
    vector<vector<int>> slotsIndex(1,vector<int>(context.poly_degree() >> 1,0));
    vector<int> idxF(context.poly_degree() >> 1);


    for(int i = 0; i < context.poly_degree() >> 1; i++){
        idxF[i] = i;   // Index with all even slots
    }
    slotsIndex[0] = idxF; // Assigns index of all even slots to poly[0] = f(x)
    PolynomialVector polys(poly_v,slotsIndex);

    //=====================keys  =========================
    KeyGenerator kgen(context);
    kgen.create_public_key(public_key);
    kgen.create_relin_keys(relinKeys);
    //kgen.create_galois_keys(mat_group.rot_index(),rotKeys);
    kgen.create_conj_keys(conjKeys);

    Encryptor enc(context,public_key,kgen.secret_key());
    Decryptor dec(context,kgen.secret_key());

    //===================== Doing ==============================
    //encode
    ckks_encoder.encode(kq_values,plainA,(int64_t) 1 << (31 - 4) );
    //ckks_encoder.encode(message,plainB,context.scaling_factor());
    //encrypt
    enc.encrypt(plainA,cipherA);
    //enc.encrypt(plainB,cipherB);
    //evaluate
    auto ckks_eva = EvaluatorFactory::SoftFactory()->create(context);
    cout << "111"<< endl;
    auto a = -8.0;
    auto b = 8.0;
    auto deg = 64;

    //ckks_eva->evaluatePolyVector(cipherA,cipherRes,polys,cipherA.metaData()->getScalingFactor(),relinKeys,ckks_encoder);



    printf("Evaluation of the function f(x) for even slots and g(x) for odd slots in the range [%0.2f, %0.2f] (degree of approximation: %d)\n", a, b, deg);
    // Scale the message to Delta = Q/MessageRatio

    double scale = exp2(round(log2(q_0/evalModPoly.MessageRatio()))) ;
    scale = scale / cipherA.metaData()->getScalingFactor().get_d();
    ckks_eva->multiply_const(cipherA,scale,cipherA,true);
    // Scale the message up to Sine/MessageRatio
    scale = evalModPoly.ScalingFactor().get_d() / cipherA.metaData()->getScalingFactor().get_d();
    scale /=  evalModPoly.MessageRatio();
    ckks_eva->multiply_const(cipherA,scale,cipherA,true);
    mpf_class cc;
    mpf_mul_ui(cc.get_mpf_t(),  cipherA.metaData()->getScalingFactor().get_mpf_t(),scale);
    cipherA.metaData()->setScalingFactor(cc);
    auto start = chrono::high_resolution_clock::now();
//
    ckks_eva->multiply_const(cipherA,(double)1/(evalModPoly.QDiff()*(evalModPoly.K())),cipherA);//
    ckks_eva->rescale(cipherA);
//
    ckks_eva->eval_mod(cipherA,cipherRes,evalModPoly,relinKeys,ckks_encoder);
    //ckks_eva->multiply( cipherA,cipherA,cipherRes,relinKeys);
    //ckks_eva->read(cipherRes);
//    auto stop = chrono::high_resolution_clock::now();
//    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);
//    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;
    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    auto tmp_res = kq_values;
    for(int i = 0; i < kq_values.size(); i++){
        tmp_res[i] -= complex<double>(evalModPoly.MessageRatio()*evalModPoly.QDiff()* round(real(kq_values[i])/(evalModPoly.MessageRatio()/evalModPoly.QDiff())), 0);
        //values[i] = sin2pi2pi(values[i] / complex(evm.MessageRatio*evm.QDiff(), 0)) * complex(evm.MessageRatio*evm.QDiff(), 0) / 6.283185307179586
    }
    for(int i = 0; i < 10; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(tmp_res[i]),imag(0));

        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,asin( (real(kq_values[i])))/2/M_PI,imag(0));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,(real(vec_result[i])), imag(vec_result[i]));
    }





}