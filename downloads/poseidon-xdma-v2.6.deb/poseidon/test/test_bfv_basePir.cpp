//
// Created by zjk on 23-4-16.
//

#include <iostream>
#include <fstream>   //头文件包含
#include <algorithm>
#include <memory>
#include <sstream>
#include <string>
#include <vector>
#include <gmpxx.h>
#include <complex>

#include "../Release/util/number_theory.h"
#include "../Release/hardware/ConfigGen.h"
#include "../Release/Ciphertext.h"

#include "../Release/util/matrix_operation.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/BatchEncoder.h"
#include "../Release/random/random_sample.h"
#include "../Release/random/RandomGen.h"
#include "../Release/random/Blake2xbPRNG.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/ParametersLiteral.h"
#include "../Release/rlwe.h"
#include "../Release/RelinKeys.h"

#include "../Release/Evaluator.h"
#include "../Release/HardwareEvaluator.h"

#include "../Release/bfv/MemoryPool2.h"
#include "../Release/linear_transform.h"
#include "../Release/util/matrix_operation.h"
using  namespace  poseidon;
std::vector<std::uint32_t> getBytes(std::string const &s)
{
    std::vector<std::uint32_t> bytes;
    bytes.reserve(std::size(s));

    std::transform(std::begin(s), std::end(s), std::back_inserter(bytes), [](char const &c){
        return std::uint32_t(c);
    });

    return bytes;
}


void test_basePir(){

    string strA = "Data0!";
    string strB = "Data1!";
    string strC = "Data2!";
    string strD = "Data3!";
    string strE = "Data4!";
    string strF = "Data5!";
    string strG = "Data6!";
    string strH = "Data7!";

    std::vector<uint32_t> data1 = getBytes(strA);
    std::vector<uint32_t> data2 = getBytes(strB);
    std::vector<uint32_t> data3 = getBytes(strC);
    std::vector<uint32_t> data4 = getBytes(strD);
    std::vector<uint32_t> data5 = getBytes(strE);
    std::vector<uint32_t> data6 = getBytes(strF);
    std::vector<uint32_t> data7 = getBytes(strG);
    std::vector<uint32_t> data8 = getBytes(strH);
    data1.resize(4096);
    data2.resize(4096);
    data3.resize(4096);
    data4.resize(4096);
    data5.resize(4096);
    data6.resize(4096);
    data7.resize(4096);
    data8.resize(4096);

    vector<uint32_t> index1(4096,0);
    vector<uint32_t> index2(4096,0);
    vector<uint32_t> index3(4096,0);
    vector<uint32_t> index4(4096,0);
    vector<uint32_t> index5(4096,0);
    vector<uint32_t> index6(4096,0);
    vector<uint32_t> index7(4096,0);
    vector<uint32_t> index8(4096,0);
    vector<uint32_t> flag(4096,1);

    int ai;
    cout << "Please enter the index of PIR  (0-7):" << endl;
    scanf(" %d", &ai);
    switch(ai){
        case(0):{
            index1.swap(flag);
            break;
        }
        case(1):{
            index2.swap(flag);
            break;
        }
        case(2):{
            index3.swap(flag);
            break;
        }
        case(3):{
            index4.swap(flag);
            break;
        }

        case(4):{
            index5.swap(flag);
            break;
        }
        case(5):{
            index6.swap(flag);
            break;
        }
        case(6):{
            index7.swap(flag);
            break;
        }
        case(7):{
            index8.swap(flag);
            break;
        }
    }

    //=====================config======================================
    BFVParametersLiteralDefault ckks_param_literal(degree_4096);
    PoseidonContext context(ckks_param_literal);


    //=====================BFV ============================
    PublicKey public_key;

    Plaintext plainIndexA,plainIndexB,plainIndexC,plainIndexD,plainIndexE,plainIndexF,plainIndexG,plainIndexH;
    Plaintext plainA,plainB,plainC,plainD,plainE,plainF,plainG,plainH,plainRes;
    Ciphertext cipherIndexA,cipherIndexB,cipherIndexC,cipherIndexD,cipherIndexE,cipherIndexF,cipherIndexG,cipherIndexH;

    KeyGenerator kgen(context);
    kgen.create_public_key(public_key);
    Encryptor enc(context,public_key,kgen.secret_key());
    Decryptor dec(context,kgen.secret_key());

    BatchEncoder encoder(context);
    encoder.encode(data1,plainA);
    encoder.encode(data2,plainB);
    encoder.encode(data3,plainC);
    encoder.encode(data4,plainD);
    encoder.encode(data5,plainE);
    encoder.encode(data6,plainF);
    encoder.encode(data7,plainG);
    encoder.encode(data8,plainH);

    encoder.encode(index1,plainIndexA);
    encoder.encode(index2,plainIndexB);
    encoder.encode(index3,plainIndexC);
    encoder.encode(index4,plainIndexD);
    encoder.encode(index5,plainIndexE);
    encoder.encode(index6,plainIndexF);
    encoder.encode(index7,plainIndexG);
    encoder.encode(index8,plainIndexH);

    enc.encrypt(plainIndexA,cipherIndexA);
    enc.encrypt(plainIndexB,cipherIndexB);
    enc.encrypt(plainIndexC,cipherIndexC);
    enc.encrypt(plainIndexD,cipherIndexD);
    enc.encrypt(plainIndexE,cipherIndexE);
    enc.encrypt(plainIndexF,cipherIndexF);
    enc.encrypt(plainIndexG,cipherIndexG);
    enc.encrypt(plainIndexH,cipherIndexH);

    auto eva = EvaluatorFactory::DefaultFactory()->create(context);
    Ciphertext ciph1,ciph2,ciph3,ciph4,ciph5,ciph6,ciph7,ciph8;

    eva->multiply_plain(cipherIndexA,plainA,ciph1);
    eva->multiply_plain(cipherIndexB,plainB,ciph2);
    eva->multiply_plain(cipherIndexC,plainC,ciph3);
    eva->multiply_plain(cipherIndexD,plainD,ciph4);
    eva->multiply_plain(cipherIndexE,plainE,ciph5);
    eva->multiply_plain(cipherIndexF,plainF,ciph6);
    eva->multiply_plain(cipherIndexG,plainG,ciph7);
    eva->multiply_plain(cipherIndexH,plainH,ciph8);
//
    eva->add(ciph1,ciph2,ciph2);
    eva->add(ciph3,ciph4,ciph4);
    eva->add(ciph5,ciph6,ciph6);
    eva->add(ciph7,ciph8,ciph8);
    eva->add(ciph2,ciph4,ciph2);
    eva->add(ciph6,ciph8,ciph6);
    eva->add(ciph2,ciph6,ciph2);

    vector<uint32_t> res_data;

    eva->read(ciph2);
    dec.decrypt(ciph2,plainRes);
    encoder.decode(plainRes,res_data);
    cout << "============= decode ===============" << endl;
    for(int i = 0; i < 10; i++){
        printf("%c\n",(poseidon_byte)res_data[i]);
    }
//    for(int i = 0; i < 10; i++){
//        printf("num:%d\n",res_data[i]);
//    }
}