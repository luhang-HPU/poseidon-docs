//
// Created by zjk on 23-4-16.
//

#include <iostream>
#include <fstream>   //头文件包含
#include "../Release/define.h"
#include "../Release/homomorphic_DFT.h"
#include "../Release/linear_transform.h"

#include <cstdlib>
#include <vector>
#include <cmath>
#include <complex>


#include "../Release/util/number_theory.h"
#include "../Release/hardware/ConfigGen.h"
#include <gmpxx.h>
#include "../Release/Ciphertext.h"

#include "../Release/util/matrix_operation.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/BatchEncoder.h"
#include "../Release/random/random_sample.h"

#include "../Release/random/RandomGen.h"
#include "../Release/random/Blake2xbPRNG.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/ParametersLiteral.h"
#include "../Release/rlwe.h"
#include "../Release/RelinKeys.h"

#include "../Release/Evaluator.h"
#include "../Release/HardwareEvaluator.h"
#define RNS_C 2
#include "../Release/linear_transform.h"
#include "../Release/util/matrix_operation.h"
using  namespace  poseidon;




void test_ckks_fft(){




    //=====================config======================================
    CKKSParametersLiteralDefault ckks_param_literal(degree_2048);
    PoseidonContext context(ckks_param_literal);

    HomomorphicDFTMatrixLiteral d(0, ckks_param_literal.LogN, ckks_param_literal.LogSlots, 19, vector<int>(3,1), true, 2.0, false, 1);

    //=====================init random data ============================
    std::vector<std::complex<double>> vec;
    std::vector<std::complex<double>> vec_result,vec_result1;
    std::vector<vector<std::complex<double>>> mat;
    int mat_size = 1 << ckks_param_literal.LogSlots;
    mat.resize(mat_size);
    //create message
    vector<complex<double>> message;
    vector<complex<double>> message_tmp(mat_size);
    vector<complex<double>> message_sum(mat_size << 1,0.0);
    sample_random_complex_vector(message, mat_size);

    //===================== coeff_to_slot compare data ==================
    FFT aa(context.poly_degree()*2);
    std::vector<std::complex<double>> messageReal(1 << ckks_param_literal.LogSlots);
    aa.embedding_inv(message,messageReal,1 << ckks_param_literal.LogSlots, false);

    //=====================init  Plain & Ciph =========================
    Plaintext plainA,plainB,plainRes;
    Ciphertext cipherA,cipherB,cipherRes;
    PublicKey public_key;
    RelinKeys relinKeys;
    GaloisKeys rotKeys;
    GaloisKeys conjKeys;
    CKKSEncoder ckks_encoder(context);
    //=====================GenMatrices  ========================
    LinearMatrixGroup mat_group;
    LinearMatrixGroup mat_group_dec;

    d.create(mat_group,ckks_encoder,1);
    //=====================keys  =========================
    KeyGenerator kgen(context);
    kgen.create_public_key(public_key);
    kgen.create_relin_keys(relinKeys);
    kgen.create_galois_keys(mat_group.rot_index(),rotKeys);
    kgen.create_conj_keys(conjKeys);

    Encryptor enc(context,public_key,kgen.secret_key());
    Decryptor dec(context,kgen.secret_key());
    //===================== Doing ==============================
    //encode
    ckks_encoder.encode(message,plainA,context.scaling_factor());

    //encrypt
    enc.encrypt(plainA,cipherA);
    //evaluate
    auto ckks_eva = EvaluatorFactory::DefaultFactory()->create(context);
    ckks_eva->dft(cipherA,mat_group,cipherRes,rotKeys);
    ckks_eva->read(cipherRes);
    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 10; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal[i]),imag(messageReal[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));

    }



}