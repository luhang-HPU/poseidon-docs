//
// Created by zjk on 23-4-16.
//

#include <iostream>
#include <fstream>   //头文件包含
#include "../Release/define.h"
#include "../Release/homomorphic_DFT.h"

#include <algorithm>
#include <chrono>
#include <cstddef>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <mutex>
#include <numeric>
#include <random>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
#include <gmpxx.h>

#include <cstdlib>
#include <vector>
#include <cmath>
#include <complex>


#include "../Release/util/number_theory.h"
#include "../Release/hardware/ConfigGen.h"

#include <gmpxx.h>
#include "../Release/Ciphertext.h"

#include "../Release/util/matrix_operation.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/BatchEncoder.h"
#include "../Release/random/random_sample.h"

#include "../Release/random/RandomGen.h"
#include "../Release/random/Blake2xbPRNG.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/ParametersLiteral.h"
#include "../Release/rlwe.h"
#include "../Release/RelinKeys.h"

#include "../Release/Evaluator.h"
#include "../Release/HardwareEvaluator.h"

#include "../Release/bfv/MemoryPool2.h"
#define RNS_C 2
#include "../Release/linear_transform.h"
#include "../Release/util/matrix_operation.h"
using  namespace  poseidon;

//unsigned int bit_reversett(unsigned int n, uint32_t bits) {
//    unsigned int reversed = 0;
//    for (uint32_t i = 0; i < bits; i++) {
//        reversed <<= 1;
//        reversed |= n & 1;
//        n >>= 1;
//    }
//
//    return reversed;
//}
//
//std::vector<uint32_t> bit_reverse_vectt(const std::vector<uint32_t> &vec){
//    std::vector<uint32_t> res(vec.size(), 0);
//    auto length_log2 = (uint32_t)log2(vec.size());
//    for(size_t i=0;i<vec.size();i++){
//        res[i]=vec[bit_reversett(i, length_log2)];
//    }
//    return res;
//}

void test_bfv_encode(){


//    seal::EncryptionParameters parms(seal::scheme_type::bfv);
//    size_t poly_modulus_degree = 2048<<1;
//    parms.set_poly_modulus_degree(poly_modulus_degree);
//    parms.set_coeff_modulus(seal::CoeffModulus::BFVDefault(poly_modulus_degree));
//    parms.set_plain_modulus(seal::PlainModulus::Batching(poly_modulus_degree, 20));
/*
    seal::SEALContext contextseal(parms);
    seal::KeyGenerator keygen(contextseal);
    seal::SecretKey secret_key = keygen.secret_key();


    size_t coeff_count = parms.poly_modulus_degree();
    size_t coeff_modulus_size = parms.coeff_modulus().size();


    vector<vector<uint32_t>> cc(coeff_modulus_size);
    vector<vector<uint32_t>> aa(coeff_modulus_size,vector<uint32_t>(coeff_count,0));
    vector<vector<uint32_t>> bb(coeff_modulus_size,vector<uint32_t>(coeff_count,0));
    vector<vector<uint32_t>> key_coeff_c0(coeff_modulus_size,vector<uint32_t>(coeff_count,0));
    vector<vector<uint32_t>> key_coeff_c1(coeff_modulus_size,vector<uint32_t>(coeff_count,0));

    for(int i = 0; i < coeff_count*coeff_modulus_size; i++){
        aa[i/coeff_count][i % coeff_count] = secret_key.data()[i];
    }
//
//    auto ntt_tables = contextseal.key_context_data()->small_ntt_tables();
//    seal::util::RNSIter secret_keytt(secret_key.data().data(), coeff_count);
//    seal::util::inverse_ntt_negacyclic_harvey(secret_keytt, coeff_modulus_size, ntt_tables);
//    for(int i = 0; i < coeff_count*coeff_modulus_size; i++){
//        bb[i/coeff_count][i % coeff_count] = secret_key.data()[i];
//    }


//
    for(size_t j=0;j<coeff_modulus_size;j++) {
        aa[j] = bit_reverse_vectt(aa[j]);
        //bit_reverse_u32(aa[j],cc[j],4096);

    }

*/
    //=====================config======================================
    BFVParametersLiteralDefault ckks_param_literal(degree_8192);
    PoseidonContext context(ckks_param_literal);
    //Hardware_BFVBGV_Api api(context);
    //auto memoryManager=  bfv::MemoryManager::getInstance(api);
    auto rng = make_shared<Blake2xbPRNGFactory>(Blake2xbPRNGFactory());
    context.set_random_generator(rng);

    //=====================BFV ============================
    PublicKey public_key1;
    Plaintext plainB,plainC,plainD;
    Ciphertext ciphertextB,ciphertextC,ciphertextD;
    RelinKeys relinKeys;
    GaloisKeys rotKeys;
    vector<uint32_t> rot_elemt{(uint32_t)(1 << ckks_param_literal.LogN)*2-1,25,5};
    //KeyGenerator kgen1(context,aa);
    KeyGenerator kgen1(context);


    kgen1.create_public_key(public_key1);
    kgen1.create_relin_keys(relinKeys);
    kgen1.create_galois_keys(rot_elemt,rotKeys);
    Encryptor enc1(context,public_key1,kgen1.secret_key());
    Decryptor dec1(context,kgen1.secret_key());


//    seal::RelinKeys relin_keys;
//    keygen.create_relin_keys(relin_keys);
////
//    auto key_vec=relin_keys.data()[seal::RelinKeys::get_index(2)];
//    for(size_t i=0;i<2;i++){
//        seal::Ciphertext key_ciph=key_vec[i].data();
//        for(size_t j=0;j<2*coeff_count*(coeff_modulus_size);j++){
//            if(j<((coeff_modulus_size)*coeff_count))
//                key_coeff_c0[j/coeff_count][j%coeff_count]=key_ciph.data()[j];
//            else
//                key_coeff_c1[j/coeff_count-coeff_modulus_size][j%coeff_count]=key_ciph.data()[j];
//        }
//
//        for(size_t j=0;j<coeff_modulus_size;j++) {
//            key_coeff_c0[j] = bit_reverse_vectt(key_coeff_c0[j]);
//            key_coeff_c1[j] = bit_reverse_vectt(key_coeff_c1[j]);
//        }
//        relinKeys.data()[0][i].data().c0()->rns_coeffs_q[0].assign(key_coeff_c0[0].begin(),key_coeff_c0[0].end());
//        relinKeys.data()[0][i].data().c0()->rns_coeffs_q[1].assign(key_coeff_c0[1].begin(),key_coeff_c0[1].end());
//        relinKeys.data()[0][i].data().c0()->rns_coeffs_p[0].assign(key_coeff_c0[2].begin(),key_coeff_c0[2].end());
//
//        relinKeys.data()[0][i].data().c1()->rns_coeffs_q[0].assign(key_coeff_c1[0].begin(),key_coeff_c1[0].end());
//        relinKeys.data()[0][i].data().c1()->rns_coeffs_q[1].assign(key_coeff_c1[1].begin(),key_coeff_c1[1].end());
//        relinKeys.data()[0][i].data().c1()->rns_coeffs_p[0].assign(key_coeff_c1[2].begin(),key_coeff_c1[2].end());
//    }

//    seal::GaloisKeys rotate_keys;
//    keygen.create_galois_keys(rot_elemt,rotate_keys);
//    auto key_vec=rotate_keys.data()[seal::GaloisKeys::get_index(8191)];
//    for(size_t i=0;i<2;i++){
//        seal::Ciphertext key_ciph=key_vec[i].data();
//        for(size_t j=0;j<2*coeff_count*(coeff_modulus_size);j++){
//            if(j<((coeff_modulus_size)*coeff_count))
//                key_coeff_c0[j/coeff_count][j%coeff_count]=key_ciph.data()[j];
//            else
//                key_coeff_c1[j/coeff_count-coeff_modulus_size][j%coeff_count]=key_ciph.data()[j];
//        }
//
//        for(size_t j=0;j<coeff_modulus_size;j++) {
//            key_coeff_c0[j] = bit_reverse_vectt(key_coeff_c0[j]);
//            key_coeff_c1[j] = bit_reverse_vectt(key_coeff_c1[j]);
//        }
//        auto index = rotKeys.get_index(8191);
//        rotKeys.data()[index][i].data().c0()->rns_coeffs_q[0].assign(key_coeff_c0[0].begin(),key_coeff_c0[0].end());
//        rotKeys.data()[index][i].data().c0()->rns_coeffs_q[1].assign(key_coeff_c0[1].begin(),key_coeff_c0[1].end());
//        rotKeys.data()[index][i].data().c0()->rns_coeffs_p[0].assign(key_coeff_c0[2].begin(),key_coeff_c0[2].end());
//
//        rotKeys.data()[index][i].data().c1()->rns_coeffs_q[0].assign(key_coeff_c1[0].begin(),key_coeff_c1[0].end());
//        rotKeys.data()[index][i].data().c1()->rns_coeffs_q[1].assign(key_coeff_c1[1].begin(),key_coeff_c1[1].end());
//        rotKeys.data()[index][i].data().c1()->rns_coeffs_p[0].assign(key_coeff_c1[2].begin(),key_coeff_c1[2].end());
//    }




    default_random_engine e;
    vector<uint32_t> ccc,ddd;
    uniform_int_distribution<unsigned >u(0, sqrt(ckks_param_literal.T));
    for(int i = 0; i < 1 << ckks_param_literal.LogSlots; i++){
        ccc.push_back(i);
        //ccc.push_back(u(e));
    }
    BatchEncoder bfvenc(context);
    bfvenc.encode(ccc,plainC);
    bfvenc.encode(ccc,plainB);
    enc1.encrypt(plainC,ciphertextC);
    enc1.encrypt(plainB,ciphertextB);

    auto eva = EvaluatorFactory::DefaultFactory()->create(context,relinKeys);
    eva->add(ciphertextB,ciphertextC,ciphertextD);
    //eva->rotate_row(ciphertextB,1,rotKeys,ciphertextD);
//    eva->rotate_row(ciphertextB,2,rotKeys,ciphertextD);
//    eva->rotate_col(ciphertextD,rotKeys,ciphertextD);

    cout << 111 << endl;
    //eva->multiply_plain(ciphertextB,plainC,ciphertextD);
    cout << "end" << endl;
    eva->multiply(ciphertextB,ciphertextC,ciphertextD,relinKeys);

    //eva->sub(ciphertextB,ciphertextC,ciphertextD);
    for(int i = 0; i < 4096; i++){
        //eva->multiply(ciphertextB,ciphertextC,ciphertextD,relinKeys);
    }
    eva->read(ciphertextD);
    dec1.decrypt(ciphertextD,plainD);
    bfvenc.decode(plainD,ddd);
    for(int i = 0; i < 10; i++){
        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal2[i].real()),imag(messageReal2[i].real()));
        printf("source vec[%d] : %ld \n",i,ccc[i]);
        printf("result vec[%d] : %ld \n",i,ddd[i]);
    }

//    for(int i = 0; i < 4096; i++){
//        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal2[i].real()),imag(messageReal2[i].real()));
//        if(ddd[i] != 2*ccc[i]){
//            printf("fail!");
//        }
//    }for(int i = 0; i < 4096; i++){
//        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal2[i].real()),imag(messageReal2[i].real()));
//        if(ddd[i] != 2*ccc[i]){
//            printf("fail!");
//        }
//    }
    cout << "pass" <<endl;
}