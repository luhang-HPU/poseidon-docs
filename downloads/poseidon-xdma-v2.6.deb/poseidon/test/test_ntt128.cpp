//
// Created by zjk on 23-4-16.
//

#include <iostream>
#include <fstream>   //头文件包含
#include "../Release/define.h"
#include "../Release/homomorphic_DFT.h"
#include "../Release/linear_transform.h"

#include <cstdlib>
#include <vector>
#include <cmath>
#include <complex>


#include "../Release/util/number_theory.h"
#include "../Release/hardware/ConfigGen.h"
#include <gmpxx.h>
#include "../Release/Ciphertext.h"

#include "../Release/util/matrix_operation.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/BatchEncoder.h"
#include "../Release/random/random_sample.h"

#include "../Release/random/RandomGen.h"
#include "../Release/random/Blake2xbPRNG.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/ParametersLiteral.h"
#include "../Release/rlwe.h"
#include "../Release/RelinKeys.h"

#include "../Release/Evaluator.h"
#include "../Release/HardwareEvaluator.h"
#define RNS_C 2
#include "../Release/linear_transform.h"
#include "../Release/util/matrix_operation.h"
using  namespace  poseidon;




void test_ntt128(){
    auto start = chrono::high_resolution_clock::now();
    auto stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;
    CKKSParametersLiteralDefault ckks_param_literal(degree_2048);
    poseidon::PoseidonContext context(ckks_param_literal);
    //=====================init random data ============================
    std::vector<std::complex<double>> vec;
    std::vector<std::complex<double>> vec_result;
    std::vector<vector<std::complex<double>>> mat;
    int vec_size = 1 << ckks_param_literal.LogSlots;
    mat.resize(vec_size);
    //create message
    vector<complex<double>> message;
    vector<complex<double>> message1;
    sample_random_complex_vector(message, vec_size);
    sample_random_complex_vector(message1, vec_size);


    //=====================init keys & Plain & Ciph =========================
    Plaintext plainA,plainB,plainRes;
    Ciphertext cipherA,cipherB,cipherRes,cipherRes2;
    PublicKey public_key;
    RelinKeys relinKeys;


    CKKSEncoder ckks_encoder(context);
    //=====================keys  =========================
    KeyGenerator kgen(context);
    kgen.create_public_key(public_key);
    kgen.create_relin_keys(relinKeys);
    Encryptor enc(context,public_key,kgen.secret_key());
    Decryptor dec(context,kgen.secret_key());

    //===================== Doing ==============================
    //encode
    start = chrono::high_resolution_clock::now();
    ckks_encoder.encode(message,plainA,context.scaling_factor());
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "ENCODE TIME: " << duration.count() << " microseconds"<< endl;
    ckks_encoder.encode(message1,plainB, context.scaling_factor());
   // auto ckks_eva = EvaluatorFactory::DefaultFactory()->create(context);



//    //rotate
    print_example_banner("Example: Rotation / Rotation in CKKS");
    start = chrono::high_resolution_clock::now();
    //vector<vector<uint32_t>> plainRes0(8192,vector<uint32_t>(128,0));
    //vector<vector<uint32_t>> plainRes1(8192,vector<uint32_t>(128,0));
    vector<vector<uint32_t>> plainVec(8192,vector<uint32_t>(128,0));
    for(size_t i=0;i<8192;i++){
        for(size_t j=0;j<128;j++){
            plainVec[i][j]=rand()%0x10001;
        }
    }

    plainA.poly()->rns_coeffs_q.resize(8192);
    for(int i = 0; i < 8192; i++){
        plainA.poly()->rns_coeffs_q[i].resize(128);
    }
    plainA.poly()->rns_coeffs_q = plainVec;
    Plaintext  plainRes0 = plainA;
    Plaintext  plainRes1 = plainA;


    HardwareEvaluator::ntt128(plainA,plainRes0);
    HardwareEvaluator::intt128(plainRes0,plainRes1);

    for(size_t i=0;i<8192;i++){
        for(size_t j=0;j<128;j++){
            assert(plainVec[i][j]==plainRes1.poly()->rns_coeffs_q[i][j]);

        }
    }
    cout << "correct" << endl;

    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt















    

}