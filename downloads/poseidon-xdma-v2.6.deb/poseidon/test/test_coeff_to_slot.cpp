//
// Created by zjk on 23-4-16.
//

#include <iostream>
#include <fstream>   //头文件包含
#include "../Release/define.h"
#include "../Release/homomorphic_DFT.h"
#include "../Release/linear_transform.h"

#include <cstdlib>
#include <vector>
#include <cmath>
#include <complex>


#include "../Release/util/number_theory.h"
#include "../Release/hardware/ConfigGen.h"
#include <gmpxx.h>
#include "../Release/Ciphertext.h"

#include "../Release/util/matrix_operation.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/BatchEncoder.h"
#include "../Release/random/random_sample.h"

#include "../Release/random/RandomGen.h"
#include "../Release/random/Blake2xbPRNG.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/ParametersLiteral.h"
#include "../Release/rlwe.h"
#include "../Release/RelinKeys.h"

#include "../Release/Evaluator.h"
#include "../Release/HardwareEvaluator.h"
#define RNS_C 2
#include "../Release/linear_transform.h"
#include "../Release/util/matrix_operation.h"
#include "../Release/util/precision.h"
using  namespace  poseidon;




void test_ckks_coeff_to_slot(){




    //=====================config======================================
    CKKSParametersLiteralDefault ckks_param_literal(degree_2048);
    PoseidonContext context(ckks_param_literal);

    HomomorphicDFTMatrixLiteral d(0, ckks_param_literal.LogN, ckks_param_literal.LogSlots, 19, vector<int>(3,1), true, 1.0, false, 1);
    HomomorphicDFTMatrixLiteral x(1, ckks_param_literal.LogN, ckks_param_literal.LogSlots, 19-6, vector<int>(3,1), true, 1.0, false, 1);


    //=====================init random data ============================
    std::vector<std::complex<double>> vec;
    std::vector<std::complex<double>> vec_result,vec_result1;
    std::vector<vector<std::complex<double>>> mat;
    int mat_size = 1 << ckks_param_literal.LogSlots;
    mat.resize(mat_size);
    //create message
    vector<complex<double>> message;
    vector<complex<double>> message_tmp(mat_size);
    vector<complex<double>> message_sum(mat_size << 1,0.0);
    sample_random_complex_vector(message, mat_size);
    for(int i = 0; i < mat_size; i++){
        message[i] = complex<double>(0.79 - (double)i/4096,0.38 -(double)(i)/4096);
    }
    //===================== coeff_to_slot compare data ==================
    FFT aa(context.poly_degree()*2);
    std::vector<std::complex<double>> messageReal2(1 << ckks_param_literal.LogSlots);
    aa.embedding_inv(message,messageReal2,1 << ckks_param_literal.LogSlots, false);

    //=====================init  Plain & Ciph =========================
    Plaintext plainA,plainB,plainRes,plainRes1,plainT;
    Ciphertext cipherA,cipherB,cipherRes,cipherRes1,cipherRes2,cipherRes3;
    PublicKey public_key;
    RelinKeys relinKeys;
    GaloisKeys rotKeys;
    GaloisKeys conjKeys;
    vector<uint32_t> rot_elemt;
    CKKSEncoder ckks_encoder(context);
    //=====================GenMatrices  ========================
    LinearMatrixGroup mat_group;
    LinearMatrixGroup mat_group_dec;

    d.create(mat_group,ckks_encoder,1);
    x.create(mat_group_dec,ckks_encoder,1);
    //=====================keys  =========================
    KeyGenerator kgen(context);
    kgen.create_public_key(public_key);
    kgen.create_relin_keys(relinKeys);
    kgen.create_galois_keys(mat_group.rot_index(),rotKeys);
    kgen.create_conj_keys(conjKeys);

    Encryptor enc(context,public_key,kgen.secret_key());
    Decryptor dec(context,kgen.secret_key());
    //===================== Doing ==============================
    //encode
    ckks_encoder.encode(message,plainA,context.scaling_factor());

    //encrypt
    enc.encrypt(plainA,cipherA);
    //evaluate

    auto ckks_eva = EvaluatorFactory::DefaultFactory()->create(context);
    auto start = chrono::high_resolution_clock::now();
    ckks_eva->coeff_to_slot(cipherA,mat_group,cipherRes,cipherRes1,rotKeys,conjKeys,ckks_encoder);
    auto stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;
    ckks_eva->read(cipherRes);
    ckks_eva->read(cipherRes1);
    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    dec.decrypt(cipherRes1,plainRes1);
    ckks_encoder.decode(plainRes,vec_result);
    ckks_encoder.decode(plainRes1,vec_result1);

    for(int i = 0; i < 10; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal2[i]),imag(messageReal2[i]));
        printf("real vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
        printf("image vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result1[i]),imag(vec_result1[i]));
    }
    GetPrecisionStats(vec_result,messageReal2);



}