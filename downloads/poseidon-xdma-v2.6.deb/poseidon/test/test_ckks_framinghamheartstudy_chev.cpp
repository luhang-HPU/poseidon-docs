//
// Created by lxs on 8/1/23.
//
#include <iostream>
#include <fstream>   //头文件包含
#include "../Release/define.h"
#include "../Release/homomorphic_DFT.h"
#include "../Release/linear_transform.h"

#include <cstdlib>
#include <vector>
#include <cmath>
#include <complex>


#include "../Release/util/number_theory.h"
#include "../Release/hardware/ConfigGen.h"
#include <gmpxx.h>
#include "../Release/Ciphertext.h"

#include "../Release/util/matrix_operation.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/BatchEncoder.h"
#include "../Release/random/random_sample.h"

#include "../Release/random/RandomGen.h"
#include "../Release/random/Blake2xbPRNG.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/ParametersLiteral.h"
#include "../Release/rlwe.h"
#include "../Release/RelinKeys.h"

#include "../Release/Evaluator.h"
#include "../Release/HardwareEvaluator.h"
#define RNS_C 2
#include "../Release/linear_transform.h"
#include "../Release/util/matrix_operation.h"
#include "../Release/homomorphic_mod.h"
#include "../Release/util/chebyshev_interpolation.h"
#include <math.h>

using namespace std;
using namespace poseidon;

double this_fun(double x)  {
    return  exp(x) / (exp(x) + 1);
    //return sin(6.283185307179586 * x) ;
}

int test_ckks_framinghamheartstudy_chev()
{
    //=====================config======================================
//    uint32_t q0_bit = 62;
//    auto q_def = q0_bit - 7;
//    vector<uint32_t> logQTmp{31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31};//20
//    vector<uint32_t> logPTmp{31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31};//20
//    ParametersLiteral ckks_param_literal(CKKS, 11, 10, logQTmp, logPTmp, q_def, 192,0,1);


    CKKSParametersLiteralDefault ckks_param_literal(degree_2048);
    PoseidonContext context(ckks_param_literal);

    //=====================init data ============================
    int vec_size = 1 << ckks_param_literal.LogSlots;
    double age, sbp, dbp, chl, height, weight;
    age = 26;
    sbp = 100;
    dbp = 70;
    chl = 100;
    height = 71;
    weight = 180;
    //输入个人身体参数，例：26, 100, 70, 100, 72, 180
    // printf("Please input your age:");
    // scanf("%lf", &age);
    // printf("\nPlease input your SBP:");
    // scanf("%lf", &sbp);
    // printf("\nPlease input your DBP:");
    // scanf("%lf", &dbp);
    // printf("\nPlease input your CHL:");
    // scanf("%lf", &chl);
    // printf("\nPlease input your height:");
    // scanf("%lf", &height);
    // printf("\nPlease input your weight:");
    // scanf("%lf", &weight);
    // printf("\n");

    //create message
    vector<complex<double>> message_age, message_sbp, message_dbp, message_chl, message_height, message_weight, vec_result;
    message_age.resize(vec_size);
    message_sbp.resize(vec_size);
    message_dbp.resize(vec_size);
    message_chl.resize(vec_size);
    message_height.resize(vec_size);
    message_weight.resize(vec_size);

    //message下标为0的地址存储对应身体数据的原始值
    message_age[0] = age;
    message_sbp[0] = sbp;
    message_dbp[0] = dbp;
    message_chl[0] = chl;
    message_height[0] = height;
    message_weight[0] = weight;

    //coef存储对应系数
    double coef_age = 0.072;
    double coef_sbp = 0.013;
    double coef_dbp = -0.029;
    double coef_chl = 0.008;
    double coef_height = -0.053;
    double coef_weight = 0.021;

    //taylor展开的系数
    double taylor_coef_0 = 1.0 / 2;
    double taylor_coef_1 = 1.0 / 4;
    double taylor_coef_3 = -1.0 / 48;
    double taylor_coef_5 = 1.0 / 480;
    double taylor_coef_7 = -17.0 / 80640;
    double taylor_coef_9 = 31 / 1451520;

    //=====================init  Plain & Ciph =========================
    Plaintext plain_age, plain_sbp, plain_dbp, plain_chl, plain_height, plain_weight, plain_result;
    Ciphertext cipher_age, cipher_sbp, cipher_dbp, cipher_chl, cipher_height, cipher_weight, cipher_x, cipher_x_square, cipher_result;
    PublicKey public_key;
    RelinKeys relinKeys;
    // GaloisKeys rotKeys;
    GaloisKeys conjKeys;
    // vector<uint32_t> rot_elemt;
    CKKSEncoder ckks_encoder(context);
//=====================poly init===================================
    auto a = -8.0;
    auto b = 8.0;
    auto deg = 64;
    printf("Evaluation of the function f(x) for even slots and g(x) for odd slots in the range [%0.2f, %0.2f] (degree of approximation: %d)\n", a, b, deg);

    auto approxF = util::Approximate(this_fun, a, b, deg);
    approxF.lead() = true;
    //auto approxG = util::Approximate(g, a, b, deg);
    vector <Polynomial> poly_v{approxF};
    vector<vector<int>> slotsIndex(1,vector<int>(context.poly_degree() >> 1,0));
    vector<int> idxF(context.poly_degree() >> 1);


    for(int i = 0; i < context.poly_degree() >> 1; i++){
        idxF[i] = i;   // Index with all even slots
    }

    slotsIndex[0] = idxF; // Assigns index of all even slots to poly[0] = f(x)


    PolynomialVector polys(poly_v,slotsIndex);

    //=====================keys  =========================
    KeyGenerator kgen(context);
    kgen.create_public_key(public_key);
    kgen.create_relin_keys(relinKeys);
    // kgen.create_galois_keys(steps,rotKeys);
    kgen.create_conj_keys(conjKeys);
    Encryptor enc(context,public_key,kgen.secret_key());
    Decryptor dec(context,kgen.secret_key());


    //-------------------encode--------------------------------
    ckks_encoder.encode(message_age, plain_age, context.scaling_factor());
    ckks_encoder.encode(message_sbp, plain_sbp, context.scaling_factor());
    ckks_encoder.encode(message_dbp, plain_dbp, context.scaling_factor());
    ckks_encoder.encode(message_chl, plain_chl, context.scaling_factor());
    ckks_encoder.encode(message_height, plain_height, context.scaling_factor());
    ckks_encoder.encode(message_weight, plain_weight, context.scaling_factor());

    //-------------------encrypt--------------------------------
    enc.encrypt(plain_age,cipher_age);
    enc.encrypt(plain_sbp,cipher_sbp);
    enc.encrypt(plain_dbp,cipher_dbp);
    enc.encrypt(plain_chl,cipher_chl);
    enc.encrypt(plain_height,cipher_height);
    enc.encrypt(plain_weight,cipher_weight);

    //-------------------------calculate----------------------------------
    //创建CKKS Evaluator
    auto ckks_eva = EvaluatorFactory::DefaultFactory()->create(context);

    auto start = chrono::high_resolution_clock::now();

    //计算 x = 0.072∙Age+0.013∙SBP-0.029∙DBP+0.008∙CHL-0.053∙height+0.021∙weight

    ckks_eva->multiply_const(cipher_age, coef_age, cipher_age);
    ckks_eva->multiply_const(cipher_sbp, coef_sbp, cipher_sbp);
    ckks_eva->multiply_const(cipher_dbp, coef_dbp, cipher_dbp);
    ckks_eva->multiply_const(cipher_chl, coef_chl, cipher_chl);
    ckks_eva->multiply_const(cipher_height, coef_height, cipher_height);
    ckks_eva->multiply_const(cipher_weight, coef_weight, cipher_weight);

    ckks_eva->add(cipher_age, cipher_sbp, cipher_x);
    ckks_eva->add(cipher_x, cipher_dbp, cipher_x);
    ckks_eva->add(cipher_x, cipher_chl, cipher_x);
    ckks_eva->add(cipher_x, cipher_height, cipher_x);
    ckks_eva->add(cipher_x, cipher_weight, cipher_x);
    ckks_eva->rescale(cipher_x);

    //计算e^x/(e^x+1)
    ckks_eva->multiply_const(cipher_x,(2.0/(double)(b-a)),cipher_x);
    ckks_eva->rescale(cipher_x);
    ckks_eva->evaluatePolyVector(cipher_x,cipher_result,polys,cipher_x.metaData()->getScalingFactor(),relinKeys,ckks_encoder);
    ckks_eva->read(cipher_result);
    auto stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //---------------------decode & decrypt-------------------------------
    dec.decrypt(cipher_result, plain_result);
    ckks_encoder.decode(plain_result, vec_result);

    printf("answer after FHE = %.8f \n",real(vec_result[0]));

    //expected answer
    double x = coef_age * age + coef_sbp * sbp + coef_dbp * dbp + coef_chl * chl + coef_height * height + coef_weight * weight;

    printf("expected answer = %.8f \n",exp(x) / (exp(x) + 1));

    return 0;
}
