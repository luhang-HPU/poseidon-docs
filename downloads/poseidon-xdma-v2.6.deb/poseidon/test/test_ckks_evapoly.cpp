//
// Created by zjk on 23-4-16.
//

#include <iostream>
#include <fstream>   //头文件包含
#include "../Release/define.h"
#include "../Release/homomorphic_DFT.h"
#include "../Release/linear_transform.h"

#include <cstdlib>
#include <vector>
#include <cmath>
#include <complex>


#include "../Release/util/number_theory.h"
#include "../Release/hardware/ConfigGen.h"
#include <gmpxx.h>
#include "../Release/Ciphertext.h"

#include "../Release/util/matrix_operation.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/BatchEncoder.h"
#include "../Release/random/random_sample.h"

#include "../Release/random/RandomGen.h"
#include "../Release/random/Blake2xbPRNG.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/ParametersLiteral.h"
#include "../Release/rlwe.h"
#include "../Release/RelinKeys.h"

#include "../Release/Evaluator.h"
#include "../Release/HardwareEvaluator.h"
#define RNS_C 2
#include "../Release/linear_transform.h"
#include "../Release/util/matrix_operation.h"
#include "../Release/homomorphic_mod.h"
#include "../Release/util/chebyshev_interpolation.h"
#include <math.h>
using  namespace  poseidon;

double f(double x)  {
    auto i = 1 / (exp(-x) + 1);
    return i;
}

double g(double x)  {
    auto i = f(x) * (1 - f(x));
    return i;
}

double myround(double x)  {
    return round(x*100000000) / 100000000;
}


using namespace poseidon;
void test_ckks_evapoly(){

    //=====================config======================================


    CKKSParametersLiteralDefault ckks_param_literal(degree_2048);
    PoseidonContext context(ckks_param_literal);


    //=====================poly init===================================
    auto a = -8.0;
    auto b = 8.0;
    auto deg = 64;
    printf("Evaluation of the function f(x) for even slots and g(x) for odd slots in the range [%0.2f, %0.2f] (degree of approximation: %d)\n", a, b, deg);

    auto approxF = util::Approximate(f, a, b, deg);
    auto approxG = util::Approximate(g, a, b, deg);
    vector <Polynomial> poly_v{approxF,approxG};
    vector<vector<int>> slotsIndex(2,vector<int>(context.poly_degree() >> 1,0));
    vector<int> idxF(context.poly_degree() >> 2);
    vector<int> idxG(context.poly_degree() >> 2);

    for(int i = 0; i < context.poly_degree() >> 2; i++){
        idxF[i] = i * 2;   // Index with all even slots
        idxG[i] = i*2 + 1; // Index with all odd slots
    }

    slotsIndex[0] = idxF; // Assigns index of all even slots to poly[0] = f(x)
    slotsIndex[1] = idxG; // Assigns index of all odd slots to poly[1] = g(x)

    PolynomialVector polys(poly_v,slotsIndex);

    //=====================init random data ============================
    std::vector<std::complex<double>> vec;
    std::vector<std::complex<double>> vec_result,vec_result1;
    std::vector<vector<std::complex<double>>> mat;
    int mat_size = 1 << ckks_param_literal.LogSlots;
    mat.resize(mat_size);
    //create message
    vector<complex<double>> message;

    sample_random_complex_vector(message, mat_size);
    for(int i = 0; i < message.size(); i++){
        message[i].imag(0);
    }
    vector<complex<double>> message1(message.size());
    for (size_t i = 0; i < context.poly_degree() >> 1; i++) {
        message1[i*2].real(f(message[i*2].real())) ;
        message1[i*2+1].real(g(message[i*2+1].real()))  ;
    }

    //=====================init  Plain & Ciph =========================
    Plaintext plainA,plainB,plainRes,plainRes1,plainT;
    Ciphertext cipherA,cipherB,cipherRes,cipherRes1,cipherRes2,cipherRes3;
    PublicKey public_key;
    RelinKeys relinKeys;
    GaloisKeys rotKeys;
    GaloisKeys conjKeys;
    vector<uint32_t> rot_elemt;
    CKKSEncoder ckks_encoder(context);
    //=====================EvalMod  ========================
    //EvalModPoly evalModPoly(context, SinContinuous,(mpf_class)((int64_t)1 << 40) ,12,6, 1,14,7,127);


    //=====================keys  =========================
    KeyGenerator kgen(context);
    kgen.create_public_key(public_key);
    kgen.create_relin_keys(relinKeys);
    //kgen.create_galois_keys(mat_group.rot_index(),rotKeys);
    kgen.create_conj_keys(conjKeys);

    Encryptor enc(context,public_key,kgen.secret_key());
    Decryptor dec(context,kgen.secret_key());

    //===================== Doing ==============================
    //encode
//    mpf_class big_scaling = context.scaling_factor();
//    mpf_mul(big_scaling.get_mpf_t(),big_scaling.get_mpf_t(),big_scaling.get_mpf_t());
    ckks_encoder.encode(message,plainA,context.scaling_factor());
    ckks_encoder.encode(message,plainB,context.scaling_factor());
    //encrypt
    enc.encrypt(plainA,cipherA);
    enc.encrypt(plainB,cipherB);
    //evaluate
    auto ckks_eva = EvaluatorFactory::SoftFactory()->create(context);
    cout << "111"<< endl;

    auto start = chrono::high_resolution_clock::now();
    ckks_eva->multiply_const(cipherA,(2.0/(double)(b-a)),cipherA);
    ckks_eva->rescale(cipherA);
    ckks_eva->evaluatePolyVector(cipherA,cipherRes,polys,cipherA.metaData()->getScalingFactor(),relinKeys,ckks_encoder);
    //ckks_eva->eval_mod(cipherA,evalModPoly,relinKeys);
    //ckks_eva->multiply( cipherA,cipherA,cipherRes,relinKeys);
    //ckks_eva->read(cipherRes);
    auto stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;
    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);


    for(int i = 0; i < 10; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message1[i]),imag(message1[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }

}