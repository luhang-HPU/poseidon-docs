//
// Created by zjk on 23-4-16.
//

#include <iostream>
#include <fstream>   //头文件包含
#include "../Release/define.h"
#include "../Release/homomorphic_DFT.h"
#include "../Release/linear_transform.h"

#include <cstdlib>
#include <vector>
#include <cmath>
#include <complex>


#include "../Release/util/number_theory.h"
#include "../Release/hardware/ConfigGen.h"
#include <gmpxx.h>
#include "../Release/Ciphertext.h"

#include "../Release/util/matrix_operation.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/BatchEncoder.h"
#include "../Release/random/random_sample.h"

#include "../Release/random/RandomGen.h"
#include "../Release/random/Blake2xbPRNG.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/ParametersLiteral.h"
#include "../Release/rlwe.h"
#include "../Release/RelinKeys.h"

#include "../Release/Evaluator.h"
#include "../Release/HardwareEvaluator.h"
#define RNS_C 2
#include "../Release/linear_transform.h"
#include "../Release/util/matrix_operation.h"
using  namespace  poseidon;


void test_pir(){
    //=====================config======================================
    CKKSParametersLiteralDefault ckks_param_literal(degree_2048);
    PoseidonContext context(ckks_param_literal);



    //=====================init random data ============================
    std::vector<std::complex<double>> vec;
    std::vector<std::complex<double>> vec_result,vec_result1;
    int mat_size = 1 << ckks_param_literal.LogSlots;
    std::vector<vector<std::complex<double>>> mat(mat_size,vector<complex<double>>(mat_size,0));
    std::vector<vector<std::complex<double>>> mat_T(mat_size);//(mat_size,vector<complex<double>>(mat_size));
    std::vector<vector<std::complex<double>>> mat_T1;
    //create message
    vector<complex<double>> message(mat_size,0);

    message[1] = 1;

    vector<complex<double>> message_tmp(mat_size);
    vector<complex<double>> message_sum(mat_size << 1,0.0);



    //=====================init  Plain & Ciph =========================
    Plaintext plainA,plainB,plainRes,plainRes1,plainT;
    Ciphertext cipherA,cipherB,cipherRes,cipherRes1,cipherRes2,cipherRes3;
    PublicKey public_key;
    RelinKeys relinKeys;
    GaloisKeys rotKeys;
    GaloisKeys conjKeys;
    CKKSEncoder ckks_encoder(context);
    //=====================GenMatrices  ========================
    MatrixPlain matrixPlain;

    for(int i = 0; i < mat_size; i++){
        sample_random_complex_vector2(mat[i],mat_size);
    }
    auto level = context.crt_context()->maxLevel();
    matrix_operations::transpose_matrix(mat,mat_T1);
    for(int i = 0; i < mat.size(); i++){
        matrix_operations::diagonal(mat_T1, i,mat_T[i]);
    }
    GenMatrixformBSGS(matrixPlain,matrixPlain.rot_index, ckks_encoder, mat_T,
                           level ,context.crt_context()->primes_q()[level], 1, ckks_param_literal.LogSlots);






    //=====================keys  =========================
    //
    KeyGenerator kgen(context);
    kgen.create_public_key(public_key);

    kgen.create_relin_keys(relinKeys);
    kgen.create_galois_keys(matrixPlain.rot_index,rotKeys);
   // kgen.create_galois_keys(rot_elemt,rotKeys);
    kgen.create_conj_keys(conjKeys);

//    string a = PublicKeyToString(rotKeys.data()[2][0]);
//    std::istringstream iss(a);
//    PublicKey a_key;
//    StringToRNSPublicKeyFromStream(iss, a_key);

    Encryptor enc(context,public_key,kgen.secret_key());
    Decryptor dec(context,kgen.secret_key());
    //===================== Doing ==============================
    //encode

    ckks_encoder.encode(message,plainA,context.scaling_factor());
    //encrypt

    enc.encrypt(plainA,cipherA);
    //evaluate
    auto ckks_eva = EvaluatorFactory::SoftFactory()->create(context);
    auto start = chrono::high_resolution_clock::now();
    ckks_eva->multiplyByDiagMatrixBSGS(cipherA,matrixPlain,cipherRes,rotKeys);
    ckks_eva->read(cipherRes);

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);


    for(int i = 0; i < 8; i++){
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(mat[1][i]), imag(mat[1][i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }



}