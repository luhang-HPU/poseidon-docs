//
// Created by zjk on 23-4-16.
//

#include <iostream>
#include <fstream>   //头文件包含
#include "../Release/define.h"
#include "../Release/homomorphic_DFT.h"

#include <algorithm>
#include <chrono>
#include <cstddef>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <mutex>
#include <numeric>
#include <random>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
#include <gmpxx.h>

#include <cstdlib>
#include <vector>
#include <cmath>
#include <complex>


#include "../Release/util/number_theory.h"
#include "../Release/hardware/ConfigGen.h"

#include <gmpxx.h>
#include "../Release/Ciphertext.h"

#include "../Release/util/matrix_operation.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/BatchEncoder.h"
#include "../Release/random/random_sample.h"

#include "../Release/random/RandomGen.h"
#include "../Release/random/Blake2xbPRNG.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/ParametersLiteral.h"
#include "../Release/rlwe.h"
#include "../Release/RelinKeys.h"

#include "../Release/Evaluator.h"
#include "../Release/HardwareEvaluator.h"

#include "../Release/bfv/MemoryPool2.h"
#define RNS_C 2
#include "../Release/linear_transform.h"
#include "../Release/util/matrix_operation.h"
using  namespace  poseidon;



void test_bgv_encode(){

    //=====================config======================================
    BGVParametersLiteralDefault ckks_param_literal(degree_4096);
    PoseidonContext context(ckks_param_literal);
    //Hardware_BFVBGV_Api api(context);
    //auto memoryManager=  bfv::MemoryManager::getInstance(api);
    auto rng = make_shared<Blake2xbPRNGFactory>(Blake2xbPRNGFactory());
    context.set_random_generator(rng);

    //=====================BFV ============================
    PublicKey public_key1;
    Plaintext plainB,plainC,plainD;
    Ciphertext ciphertextB,ciphertextC,ciphertextD;
    RelinKeys relinKeys;
    GaloisKeys rotKeys;
    vector<uint32_t> rot_elemt{8191,25,5};
    //KeyGenerator kgen1(context,aa);
    KeyGenerator kgen1(context);

    kgen1.create_public_key(public_key1);
    kgen1.create_relin_keys(relinKeys);
    kgen1.create_galois_keys(rot_elemt,rotKeys);
    Encryptor enc1(context,public_key1,kgen1.secret_key());
    Decryptor dec1(context,kgen1.secret_key());

    default_random_engine e;
    vector<uint32_t> ccc,ddd;
    uniform_int_distribution<unsigned >u(0, sqrt(ckks_param_literal.T));
    for(int i = 0; i < 1 << ckks_param_literal.LogSlots; i++){
        ccc.push_back(i);
        //ccc.push_back(u(e));
    }
    BatchEncoder bfvenc(context);
    bfvenc.encode(ccc,plainC);
//    bfvenc.encode(ccc,plainB);
    //enc1.encrypt(plainC,ciphertextC);
//    enc1.encrypt(plainB,ciphertextB);
//
//    auto eva = EvaluatorFactory::DefaultFactory()->create(context,relinKeys);
//    eva->add(ciphertextB,ciphertextC,ciphertextD);
//
//    cout << 111 << endl;
//    //eva->multiply_plain(ciphertextB,plainC,ciphertextD);
//    cout << "end" << endl;
//    //eva->multiply(ciphertextB,ciphertextC,ciphertextD,relinKeys);
//
//    //eva->sub(ciphertextB,ciphertextC,ciphertextD);
//    for(int i = 0; i < 4096; i++){
//        //eva->multiply(ciphertextB,ciphertextC,ciphertextD,relinKeys);
//    }
//    eva->read(ciphertextD);
    //dec1.decrypt(ciphertextC,plainD);
    bfvenc.decode(plainC,ddd);
    for(int i = 0; i < 10; i++){
        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal2[i].real()),imag(messageReal2[i].real()));
        printf("source vec[%d] : %ld \n",i,ccc[i]);
        printf("result vec[%d] : %ld \n",i,ddd[i]);
    }

//    for(int i = 0; i < 4096; i++){
//        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal2[i].real()),imag(messageReal2[i].real()));
//        if(ddd[i] != 2*ccc[i]){
//            printf("fail!");
//        }
//    }for(int i = 0; i < 4096; i++){
//        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(messageReal2[i].real()),imag(messageReal2[i].real()));
//        if(ddd[i] != 2*ccc[i]){
//            printf("fail!");
//        }
//    }
    cout << "pass" <<endl;
}