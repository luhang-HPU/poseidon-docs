//
// Created by zjk on 23-4-16.
//

#include <iostream>
#include <fstream>   //头文件包含



#include <vector>
#include <complex>

#include "../Release/Ciphertext.h"
#include "../Release/CKKSEncoder.h"
#include "../Release/KeyGenerator.h"
#include "../Release/Encryptor.h"
#include "../Release/Decryptor.h"
#include "../Release/Evaluator.h"
#include "../Release/ParametersLiteral.h"


#define RNS_C 2

using  namespace  poseidon::util;
Ciphertext Rot(shared_ptr<Evaluator> eva, Ciphertext &ciph,  const GaloisKeys &rotKeys, int r){
    Ciphertext cipherRes;
    eva->rotate(ciph,cipherRes,rotKeys,r);
    return cipherRes;
}


void test_ckks_basic(){
    //=====================config======================================
    uint32_t q0_bit = 31;
    auto q_def = q0_bit;
    //vector<uint32_t> logQTmp{31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31};
    //vector<uint32_t> logPTmp{31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31,31};
    vector<uint32_t> logQTmp{31,31,31,31,31,31,31,31,31,31, 31,31,31,31,31,31,31,31,31,31 , 31,31,31,31,31, 31,31,31,31,31};//,31,31,31,31}; //
    vector<uint32_t> logPTmp{31,31,31,31,31,31,31,31,31,31, 31,31,31,31,31,31,31,31,31,31 , 31,31,31,31,31, 31,31,31,31,31};//,31,31,31,31,31,31,31,31,31,31,31};  //

//    vector<uint32_t> logQTmp{31,31,31,31,31,31,31,31,31,31, 31,31,31,31,31,31,31,31,31,31,31,31,31}; //
//    vector<uint32_t> logPTmp{31,31,31,31,31,31,31,31,31,31, 31,31,31,31,31,31,31,31,31,31,31,31,31};  //

    ParametersLiteral ckks_param_literal(CKKS, 15, 14, logQTmp, logPTmp, q_def, 192,0,0);
    //CKKSParametersLiteralDefault ckks_param_literal(degree_32768);
    poseidon::PoseidonContext context(ckks_param_literal);
    auto start = chrono::high_resolution_clock::now();
    auto stop = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;
    //=====================init random data ============================
    std::vector<std::complex<double>> vec;
    std::vector<std::complex<double>> vec_result;
    std::vector<vector<std::complex<double>>> mat;
    int vec_size = 1 << ckks_param_literal.LogSlots;
    mat.resize(vec_size);
    //create message
    vector<complex<double>> message;
    vector<complex<double>> message1;
    sample_random_complex_vector(message, vec_size);
    sample_random_complex_vector(message1, vec_size);


    //=====================init keys & Plain & Ciph =========================
    Plaintext plainA,plainB,plainRes;
    Ciphertext cipherA,cipherB,cipherRes,cipherRes2;
    PublicKey public_key;
    RelinKeys relinKeys;
    GaloisKeys rotKeys;
    GaloisKeys conjKeys;
    vector<int> steps{1,2,3,64,512};
    CKKSEncoder ckks_encoder(context);
    //=====================keys  =========================
    KeyGenerator kgen(context);
    kgen.create_public_key(public_key);
    kgen.create_relin_keys(relinKeys);
    kgen.create_galois_keys(steps,rotKeys);
    kgen.create_conj_keys(conjKeys);
    Encryptor enc(context,public_key,kgen.secret_key());
    Decryptor dec(context,kgen.secret_key());

    //===================== Doing ==============================
    //encode
    start = chrono::high_resolution_clock::now();
    ckks_encoder.encode(message,plainA,context.scaling_factor());
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "ENCODE TIME: " << duration.count() << " microseconds"<< endl;
    ckks_encoder.encode(message1,plainB, context.scaling_factor());
    //encrypt
    start = chrono::high_resolution_clock::now();
    enc.encrypt(plainA,cipherA);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "ENCRYPT TIME: " << duration.count() << " microseconds"<< endl;
    enc.encrypt(plainB,cipherB);
    printf("Doing config...\n");
    auto ckks_eva = EvaluatorFactory::DefaultFactory()->create(context);


    //ntt
    print_example_banner("Example: NTT / INTT in CKKS");
    start = chrono::high_resolution_clock::now();


    //ckks_eva->add(cipherA,cipherA,cipherA);
    ckks_eva->ftt_inv(cipherA,cipherA);

    ckks_eva->ftt_fwd(cipherA,cipherA);
    ckks_eva->read(cipherA);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherA,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]),imag(message[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }

   //rotate
    print_example_banner("Example: Rotation / Rotation in CKKS");
    start = chrono::high_resolution_clock::now();

    //ckks_eva->multiply_const(cipherA,1000,cipherRes,true);
//    for(int i = 0; i < 10; i++){
//        ckks_eva->add(cipherA,cipherA,cipherRes);
//    }

    ckks_eva->rotate(cipherA,cipherRes,rotKeys,512);
    ckks_eva->read(cipherRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]),imag(message[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }


    //add
    Ciphertext cipherRes1,cipherRes3,cipherRes4,cipherRes5;
    print_example_banner("Example: Add / Add in CKKS");
    start = chrono::high_resolution_clock::now();

    ckks_eva->add(cipherA,cipherB,cipherRes);



    ckks_eva->read(cipherRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]+message1[i]),imag(message[i]+message1[i]));
        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real((message[i]+message1[i])*message[i]),imag((message[i]+message1[i])*message[i]));
        //printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]+message1[i]),imag(message[i]+message1[i]));

        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }


    //multiply_plain
    print_example_banner("Example: multiply_plain / multiply_plain in CKKS");
    start = chrono::high_resolution_clock::now();
    ckks_eva->multiply_plain(cipherA,plainB,cipherRes);
    ckks_eva->rescale(cipherRes);
    ckks_eva->read(cipherRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]*message1[i]),imag(message[i]*message1[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }


    //sub
    print_example_banner("Example: Sub / Sub in CKKS");
    start = chrono::high_resolution_clock::now();
    ckks_eva->sub(cipherA,cipherB,cipherRes);
    ckks_eva->read(cipherRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]-message1[i]),imag(message[i]-message1[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }




    //add_plain
    print_example_banner("Example: add_plain / add_plain in CKKS");
    start = chrono::high_resolution_clock::now();
    ckks_eva->add_plain(cipherA,plainB,cipherRes);
    ckks_eva->read(cipherRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]+message1[i]),imag(message[i]+message1[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }



//conjugate

    print_example_banner("Example: Conjugate / Conjugate in CKKS");
    start = chrono::high_resolution_clock::now();
    ckks_eva->conjugate(cipherA,cipherRes2,conjKeys);
    ckks_eva->read(cipherRes2);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes2,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]),imag(-message[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }



    //multiply
    print_example_banner("Example: Multiply / Multiply  in CKKS");
    start = chrono::high_resolution_clock::now();
    ckks_eva->multiply(cipherA,cipherB,cipherRes,relinKeys);
    //ckks_eva->rescale(cipherRes);
    ckks_eva->read(cipherRes);
//    ckks_eva->rescale(cipherRes);
//    ckks_eva->read(cipherRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]*message1[i]),imag(message[i]*message1[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }

    //rescale
    print_example_banner("Example: Rescale / Rescale  in CKKS");
    start = chrono::high_resolution_clock::now();
    ckks_eva->rescale(cipherRes);
    ckks_eva->read(cipherRes);
    stop = chrono::high_resolution_clock::now();
    duration = chrono::duration_cast<chrono::microseconds>(stop - start);
    cout << "EXP TIME: " << duration.count() << " microseconds"<< endl;

    //decode & decrypt
    dec.decrypt(cipherRes,plainRes);
    ckks_encoder.decode(plainRes,vec_result);

    for(int i = 0; i < 4; i++){
        printf("source vec[%d] : %0.10f + %0.10f I \n",i,real(message[i]*message1[i]),imag(message[i]*message1[i]));
        printf("result vec[%d] : %0.10f + %0.10f I \n",i,real(vec_result[i]), imag(vec_result[i]));
    }

    
}