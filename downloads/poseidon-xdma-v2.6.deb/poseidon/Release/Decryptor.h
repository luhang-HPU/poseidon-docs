//
// Created by lxs on 6/7/23.
//

#ifndef POSEIDON_DECRYPTOR_H
#define POSEIDON_DECRYPTOR_H

#include "PoseidonContext.h"
#include "PublicKey.h"
#include "SecretKey.h"
#include "Plaintext.h"
namespace poseidon {

    class Decryptor {
    public:
        /**
       Creates a Decryptor instance initialized with the specified PoseidonContext
       and secret key.

       @param[in] context The PoseidonContext
       @param[in] secret_key The secret key
       @throws std::invalid_argument if the encryption parameters are not valid
       @throws std::invalid_argument if secret_key is not valid
       */
        Decryptor(const PoseidonContext &context, const SecretKey &secret_key);

        /*
        Decrypts a Ciphertext and stores the result in the destination parameter.

        @param[in] encrypted The ciphertext to decrypt
        @param[out] destination The plaintext to overwrite with the decrypted
        ciphertext
        @throws std::invalid_argument if encrypted is not valid for the encryption
        parameters
        @throws std::invalid_argument if encrypted is not in the default NTT form
        */
        void decrypt(const Ciphertext &encrypted, Plaintext &destination);

        /*
        Computes the invariant noise budget (in bits) of a ciphertext. The
        invariant noise budget measures the amount of room there is for the noise
        to grow while ensuring correct decryptions. This function works only with
        the BFV scheme.

        @par Invariant Noise Budget
        The invariant noise polynomial of a ciphertext is a rational coefficient
        polynomial, such that a ciphertext decrypts correctly as long as the
        coefficients of the invariantnoise polynomial are of absolute value less
        than 1/2. Thus, we call the infinity-norm of the invariant noise polynomial
        the invariant noise, and for correct decryption requireit to be less than
        1/2. If v denotes the invariant noise, we define the invariant noise budget
        as -log2(2v). Thus, the invariant noise budget starts from some initial
        value, which depends on the encryption parameters, and decreases when
        computations are performed. When the budget reaches zero, the ciphertext
        becomes too noisy to decrypt correctly.

        @param[in] encrypted The ciphertext
        @throws std::invalid_argument if the scheme is not BFV
        @throws std::invalid_argument if encrypted is not valid for the encryption
        parameters
        @throws std::invalid_argument if encrypted is in NTT form
        */
       // int invariant_noise_budget(const Ciphertext &encrypted);

    private:
        void bfv_decrypt(const Ciphertext &encrypted, Plaintext &destination);

        void ckks_decrypt(const Ciphertext &encrypted, Plaintext &destination);

        void bgv_decrypt(const Ciphertext &encrypted, Plaintext &destination);

        Decryptor(const Decryptor &copy) = delete;

        Decryptor(Decryptor &&source) = delete;

        void dot_product_ct_sk_array(const Ciphertext &encrypted, Plaintext& plain);

        Decryptor &operator=(const Decryptor &assign) = delete;

        Decryptor &operator=(Decryptor &&assign) = delete;

        SecretKey secret_key_;

        PoseidonContext context_;
    };

} // poseidon

#endif //POSEIDON_DECRYPTOR_H
