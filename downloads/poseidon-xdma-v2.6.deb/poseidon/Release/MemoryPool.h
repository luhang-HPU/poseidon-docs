
// Created by zjk on 23-4-15.
//

#include "define.h"
#include <bits/stdc++.h>
using namespace std;
#ifndef MEMORYPOOL
#define MEMORYPOOL

class Ciph;

namespace poseidon
{
    enum Operation_type {
        ckks_add_ciph_src,
        ckks_add_ciph_dst,
        ckks_add_plain_src,
        ckks_add_plain_dst,
        ckks_sub_ciph_src,
        ckks_sub_ciph_dst,
        ckks_multiply_plain_src,
        ckks_multiply_plain_dst,
        ckks_multiply_ciph_src,
        ckks_multiply_ciph_dst,
        ckks_rescale_src,
        ckks_rescale_dst,
        ckks_conjugate_src,
        ckks_conjugate_dst,
        ckks_ftt_fwd_src,
        ckks_ftt_fwd_dst,
        ckks_ftt_inv_src,
        ckks_ftt_inv_dst,
        ckks_rotate_src,
        ckks_rotate_dst,
        ckks_rotate_key
    };

    class MemoryPool {

    private:
        int degree_;
        int rns_max_;
        int inst_degree_type_; //other instruction
        int degree_type_;  //dma_pull/push
        int max_poly_num_;  //space = max_poly_num_* 1*rns_max_num_

//        static const uint64_t HBM_SIZE=1;
//        static const uint64_t SIZE_PER_HBM=134217728;
        uint64_t HBM_ADDR;
        static const  uint32_t HBM_SIZE         =   1           ;
        static const  uint32_t SIZE_PER_HBM     =   134217728/32;
//        static const  uint32_t FIRST_HBM_ADDR   =   0x14000000  ;
//        static const  uint32_t SECOND_HBM_ADDR  =   0x114000000 ;

        //segment tree
        vector<int> l_max[HBM_SIZE];                      // max left length of plenty addr in target segment
        vector<int> r_max[HBM_SIZE];                      // max right length of plenty addr in target segment
        vector<int> mid_max[HBM_SIZE];                    // max length of plenty addr in target segment
        vector<int> tree_pool_index_list[HBM_SIZE];       // tail addr of target addr block
        vector<int> mid_max_index[HBM_SIZE];              // left index of max length of plenty addr in target segment
        vector<int> tag[HBM_SIZE];                        // lazy tag. -1 is empty.

        //map
        unordered_map<int, uint64_t> ID_hard_addr_map;    // ID with addr in hardware
        map<uint64_t, int> hard_addr_ID_map;              // addr in hardware with ID
        unordered_map<int, Ciph*> ID_soft_addr_map;       // ID with addr in software
        set<pair<int,int> > len_ID_set;                   // ID with len

        void upd(int ind, int rt, int l, int r, int al, int ar, int val);
        int query(int ind, int rt, int l, int r, int len);
        void push_up(int ind, int rt, int l, int r);
        void push_down(int ind,int rt, int l, int r);
        int get(int ind,int rt, int l, int r, int x);
        bool can_apply(int ind,int L,int R);
        int get_space_first();
        int get_space_second();
        uint64_t fixed_apply(int id,int poly_num,uint64_t pool_index);
        uint64_t apply(int id,int poly_num);
        uint64_t remove(int id);
        void abstract_from_hardware(int id);






    public:
        MemoryPool(const MemoryPool&) = default;
        MemoryPool() = default;
        MemoryPool(DegreeType degree_type, uint64_t base_addr,int rns_max);
        MemoryPool(MemoryPool& other) = default;

        Ciph* get_by_id(int id);
        uint64_t put_by_id_with_kept(void* soft_addr, int id, int poly_num, const set<int> &kept=set<int>(),bool plain=false,uint64_t fixed_addr = 0);
        uint64_t put_by_id_with_kept_without_XDMA(void* soft_addr, int id, uint32_t poly_num, const set<int> &kept=set<int>());
        void release(int id);
        void init(int ind,int rt, int l, int r);

        int degree();
        int inst_degree_type();
        int degree_type();
        unordered_map<int, Ciph*> get_soft_map();

    };

    class MemoryManager {
    private:
        int rns_max_;

        static const int HBM_NUM = 4;
        unordered_map<int, int> ID_HBM_map;
        vector<MemoryPool> memoryPools;
        int curID;
        static MemoryManager* memoryManager;
        MemoryManager(DegreeType degree_type,int rns_max);

    public:
        MemoryManager(MemoryManager& other) = delete;
        void operator = (const MemoryManager&)=delete;
        static MemoryManager* getInstance(DegreeType degree_type,int rns_max);
        static MemoryManager* getInstance();
        static void destory();

        int compute_id();
        Ciph* get_by_id(int id);
        uint64_t put_by_id_with_kept(void* soft_addr, int id, int poly_num, Operation_type operation_type, const set<int> &kept=set<int>(),bool plain=false,uint64_t  fixed_addr = 0);
        uint64_t put_by_id_with_kept_without_XDMA(void* soft_addr, int id, uint32_t poly_num, Operation_type operation_type, const set<int> &kept=set<int>());
        void release(int id);

        int degree();
        int inst_degree_type();
        int degree_type();
        unordered_map<int, Ciph*> get_soft_map(int HBM_num);
        unordered_map<int, int> get_ID_HBM_map();

    };

}
#endif