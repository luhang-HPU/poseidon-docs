#include "../define.h"

#include <cstdlib>
#include <cmath>

#include <complex>
#include "bit_operations.h"



class FFT
{
private:
	int fft_length_;


    std::vector <complex<double>> roots_of_unity_;
    std::vector <complex<double>> roots_of_unity_inv_;
    std::vector <int> reversed_bits_;
    std::vector <int> rot_group_;
  // int reversed_bits[FFT_LENGTH/4];//
  // int rot_group[FFT_LENGTH/4];


public:
  FFT(int fft_length);
	//int embedding_inv(Comp *vec,Comp *to_scale_down,int length);
    int embedding_inv(vector<std::complex<double>> vec,vector<std::complex<double>>& to_scale_down,int slot_num,bool reversed = true);
	//int embedding(Comp *coeffs,Comp *result,int length);
    int embedding(vector<complex<double>> coeffs,vector<complex<double>>& result,int length);
};

