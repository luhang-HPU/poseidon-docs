#include <complex>
#include "../define.h"
using namespace std;

int reverse_bits(int value,int width);
int bit_reverse_vec(const vector<complex<double>>& values,vector<complex<double>>& result);
int bit_reverse_vec_int(int *values, int length, vector <long long> &result);
int bit_reverse_int(const vector<int> &values, vector <long long> &result, uint32_t degree);
int bit_reverse_u32(const vector<uint32_t> &values,std::vector <uint32_t> &result,uint32_t degree);



