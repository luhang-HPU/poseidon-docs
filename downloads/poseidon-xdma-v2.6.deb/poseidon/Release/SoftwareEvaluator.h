//
// Created by lxs on 23-6-16.
//

#ifndef POSEIDON_SOFTWAREEVALUATOR_H
#define POSEIDON_SOFTWAREEVALUATOR_H
#include "PoseidonContext.h"
#include "Evaluator.h"
#include "polynomial_evaluation.h"
#include "util/chebyshev_interpolation.h"
#include "util/RNSTool.h"
namespace poseidon {

    class SoftwareEvaluator : public Evaluator
    {
    public:
        SoftwareEvaluator(const PoseidonContext &context)
            : Evaluator(context)
        {}

    public:
        void rotate_row(Ciphertext &encrypted, int rot_step, const GaloisKeys &galois_keys, Ciphertext &destination) override;
        void rotate_col(Ciphertext &encrypted, const GaloisKeys &galois_keys, Ciphertext &destination) override;


    public:
        void ftt_fwd( Plaintext &plain ,Plaintext &result) override;
        void ftt_fwd( Ciphertext &ciph, Ciphertext &result) override;
        void ftt_inv( Plaintext &plain ,Plaintext &result) override;
        void ftt_inv( Ciphertext &ciph ,Ciphertext &result) override;

        void add_plain( Ciphertext &ciph,  Plaintext &plain,Ciphertext &result) override;
        void add( Ciphertext &ciph1,  Ciphertext &ciph2,Ciphertext &result) override;
        void sub( Ciphertext &ciph1,  Ciphertext &ciph2,Ciphertext &result) override;
        void rotate( Ciphertext &ciph, Ciphertext &result,const GaloisKeys &rot_key, int r) override;
        void rescale(Ciphertext &ciph) override;
        void rescale_dynamic(Ciphertext &ciph,mpf_class scale) override;

        void conjugate( Ciphertext &ciph,Ciphertext &result ,const GaloisKeys &conj_key) override;
        void multiply( Ciphertext &ciph0, Ciphertext &ciph1,Ciphertext &result, const RelinKeys &relin_key) override;
        void multiply_dynamic( Ciphertext &ciph1, Ciphertext &ciph2,Ciphertext &result, const RelinKeys &relin_key) override;
        void multiplyByDiagMatrixBSGS( Ciphertext &ciph, MatrixPlain& plain_mat,Ciphertext &result,const GaloisKeys &rot_key) override;
        void multiplyByDiagMatrixBSGS_test( Ciphertext &ciph, MatrixPlain& plain_mat,Ciphertext &result,const GaloisKeys &rot_key) ;
        void evaluatePolyVector( Ciphertext &ciph,Ciphertext &destination,const PolynomialVector &polys,mpf_class scalingfactor,const RelinKeys &relin_key,CKKSEncoder &encoder) override;
        void evaluatePolyVector( Ciphertext &ciph,Ciphertext &destination,const PolynomialVector &polys,mpf_class scalingfactor,const RelinKeys &relin_key,CKKSEncoder &encoder,Decryptor &dec);

        void dft( Ciphertext &ciph, LinearMatrixGroup& matrix_group,Ciphertext &result,const GaloisKeys &rot_key) override;
        void coeff_to_slot( Ciphertext &ciph, LinearMatrixGroup& matrix_group,Ciphertext &result_real,Ciphertext &result_imag,
                           const GaloisKeys &rot_key,const GaloisKeys &conj_key,CKKSEncoder &encoder) override;
        void slot_to_coeff( Ciphertext &ciph_real, Ciphertext &ciph_imag, LinearMatrixGroup& matrix_group,Ciphertext &result,
        const GaloisKeys &rot_key,const GaloisKeys &conj_key,CKKSEncoder &encoder) override;

        void eval_mod( Ciphertext &ciph,Ciphertext &result,const EvalModPoly &eva_poly,const RelinKeys &relin_key,CKKSEncoder &encoder) override;
        void bootstrap(Ciphertext &ciph,Ciphertext &result,const EvalModPoly &eva_poly,LinearMatrixGroup& matrix_group0,LinearMatrixGroup &matrix_group1,
                       const RelinKeys &relin_key, const GaloisKeys &rot_key,const GaloisKeys &conj_key,CKKSEncoder &encoder) override;
//        void exp_taylor(const Ciphertext &ciph, Ciphertext &result,const RelinKeys &relin_key) override;
//        void exp(const Ciphertext &ciph, Ciphertext &result, complex<double> const_data,const RelinKeys &relin_key, CKKSEncoder enc) override;

    protected:
        void ckks_add_plain(Ciphertext &encrypted, Plaintext &plain, Ciphertext &destination) override;
        void ckks_multiply_plain( Ciphertext &ciph,  Plaintext &plain,Ciphertext &result,bool isDirect) override;
        void bfv_bgv_multiply_plain( Ciphertext &encrypted,  Plaintext &plain,Ciphertext &destination) override;

    private:
        int low_modulus(Ciphertext& ciph, int level);
        int low_modulus(Plaintext& ciph, int level);
        void read(Ciphertext &ciph) override{

        }
        void ckks_add( Ciphertext &ciph1, Ciphertext &ciph2,Ciphertext &result);
        void ckks_sub( Ciphertext &ciph1,  Ciphertext &ciph2,Ciphertext &result);
        void ckks_multiply( Ciphertext &ciph0, Ciphertext &ciph1,Ciphertext &result, const RelinKeys &relin_key) ;
        void bgv_multiply( Ciphertext &ciph0, Ciphertext &ciph1,Ciphertext &result, const RelinKeys &relin_key) ;
        void bfv_multiply( Ciphertext &ciph0, Ciphertext &ciph1,Ciphertext &result, const RelinKeys &relin_key) ;

        void bfv_bgv_add( Ciphertext &ciph1, Ciphertext &ciph2,Ciphertext &result);
        void bfv_bgv_sub( Ciphertext &ciph1,  Ciphertext &ciph2,Ciphertext &result);
        void relinearize(RNSPolynomial c0, RNSPolynomial c1, RNSPolynomial c2, Ciphertext &result, const RelinKeys&  relin_key);
        void ckks_relinearize_inplace(RNSPolynomial c0, RNSPolynomial c1, RNSPolynomial c2, Ciphertext &result, const RelinKeys&  relin_key);
        void bfv_bgv_relinearize_inplace(RNSPolynomial c0, RNSPolynomial c1, RNSPolynomial c2, Ciphertext &result, const RelinKeys&  relin_key);

        void switch_key(Ciphertext& ciph, Ciphertext &result, const vector<PublicKey>& switch_key);
        void ckks_switch_key_lazy_inplace(Ciphertext& ciph, Ciphertext &result, const PublicKey& switch_key);
        void ckks_switch_key_inplace(Ciphertext& ciph, Ciphertext &result, const PublicKey& switch_key);
        void bfv_bgv_switch_key_inplace(Ciphertext& ciph, Ciphertext &result, const vector<PublicKey> &switch_key);
        void GenPower(map <int,Ciphertext> &monomialBasis,int n,bool lazy,bool isChev,mpf_class scale,const RelinKeys &relin_key);
        void genPower(map <int,Ciphertext> &monomialBasis,int n,bool lazy,bool isChev,mpf_class scale,const RelinKeys &relin_key);
        void GenPower(map <int,Ciphertext> &monomialBasis,int n,bool lazy,bool isChev,mpf_class scale,const RelinKeys &relin_key,Decryptor &dec,CKKSEncoder &encoder);
        void genPower(map <int,Ciphertext> &monomialBasis,int n,bool lazy,bool isChev,mpf_class scale,const RelinKeys &relin_key,Decryptor &dec,CKKSEncoder &encoder);


        void bfv_bgv_add_plain( Ciphertext &ciph,  Plaintext &plain,Ciphertext &result);
        void recurse(const map <int,Ciphertext> &monomialBasis,const RelinKeys &relinKeys,int targetLevel ,mpf_class targetScale ,
                     const PolynomialVector &pol, int log_split,int log_degree, Ciphertext &destination,CKKSEncoder &ckksEncoder,bool isOdd,bool isEven,int &num);
        void evaluatePolyFromPolynomialBasis(bool is_even,bool is_odd, const map <int,Ciphertext> &monomialBasis,const RelinKeys &relinKeys ,int targetLevel ,mpf_class targetScale ,
                                        const PolynomialVector &pol, int log_split,int log_degree, Ciphertext &destination,CKKSEncoder &encoder);
        void recurse_dynamic(const map <int,Ciphertext> &monomialBasis,const RelinKeys &relinKeys ,int targetLevel ,mpf_class targetScale ,
                                                const PolynomialVector &pol, int log_split,int log_degree, Ciphertext &destination,CKKSEncoder &encoder,bool isOdd,bool isEven,int &num,Decryptor &dec);
//        tuple<int,mpf_class> pre_scalar_level(bool is_even,bool is_odd, const map <int,Ciphertext> &monomialBasis,mpf_class currentScale,int currentLevel,
//                                                      const PolynomialVector &pol, int log_split,int log_degree);

        };

    class SoftwareEnvaluatorFactory : public EvaluatorFactory
    {
    protected:
        auto create_impl(const PoseidonContext &context) -> shared_ptr<Evaluator> override
        {
            return  make_shared<SoftwareEvaluator>(context);
        }

        auto create_impl(const PoseidonContext &context, const RelinKeys &relinKeys) -> shared_ptr<Evaluator> override
        {
            return  make_shared<SoftwareEvaluator>(context);
        }
    };
} // poseidon

#endif //POSEIDON_SOFTWAREEVALUATOR_H
