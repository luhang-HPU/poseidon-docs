//
// Created by lxs on 6/8/23.
//

#ifndef POSEIDON_RELINKEYS_H
#define POSEIDON_RELINKEYS_H
#include "KeySwitchKey.h"
namespace poseidon {

    class RelinKeys : public KeySwitchKey
    {
    public:
        inline static std::size_t get_index(std::size_t key_power)
        {
            if (key_power < 2)
            {
                throw std::invalid_argument("key_power cannot be less than 2");
            }
            return key_power - 2;
        }

    };

} // poseidon

#endif //POSEIDON_RELINKEYS_H
