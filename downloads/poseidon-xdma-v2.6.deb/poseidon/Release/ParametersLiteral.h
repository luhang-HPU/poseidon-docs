//
// Created by lxs on 5/19/23.
//

#ifndef POSEIDON_PARAMETERSLITERAL_H
#define POSEIDON_PARAMETERSLITERAL_H
#include <iostream>
#include <vector>
#include "define.h"
using namespace std;
namespace poseidon {
    class ParametersLiteral {
        public:
            SchemeType Type;
            DegreeType degreeType;
            uint32_t LogN;                                                 // Log2 of the ringdegree
            uint32_t LogSlots;                                             // Log2 of the number of slots
            vector<uint32_t> LogQ;                                        // Log2 of the ciphertext prime moduli
            vector<uint32_t> LogP;                                        // Log2 of the key-switch auxiliary prime moduli
            vector<uint32_t> Q;
            vector<uint32_t> P;
            uint32_t LogScale;                                             // Log2 of the scale
            uint32_t H;
            uint32_t T;
            int q0_level;

            ParametersLiteral();
            ParametersLiteral(SchemeType Type, uint32_t LogN, uint32_t LogSlots, const vector<uint32_t>& LogQ, const vector<uint32_t>& LogP, uint32_t LogScale, uint32_t H,uint32_t T = 0,int q0_level = 0);
    };



    class CKKSParametersLiteralDefault : public ParametersLiteral{
        private:
            int init(DegreeType degreeType);
        public:
            CKKSParametersLiteralDefault(DegreeType degreeType);
    };

    class BFVParametersLiteralDefault : public ParametersLiteral{
    private:
        int init(DegreeType degreeType);
    public:
        BFVParametersLiteralDefault(DegreeType degreeType);
    };

    class BGVParametersLiteralDefault : public ParametersLiteral{
    private:
        int init(DegreeType degreeType);
    public:
        BGVParametersLiteralDefault(DegreeType degreeType);
    };


}

#endif //POSEIDON_PARAMETERSLITERAL_H




