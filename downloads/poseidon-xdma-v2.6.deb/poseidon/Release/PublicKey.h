//
// Created by lxs on 6/5/23.
//

#ifndef POSEIDON_PUBLICKEY_H
#define POSEIDON_PUBLICKEY_H
#include "Ciphertext.h"
namespace poseidon {

    class PublicKey {
        friend class KeyGenerator;
    public:
        /**
        Creates an empty public key.
        */
        PublicKey();
        PublicKey(const PublicKey &copy) = default;
        PublicKey(PublicKey &&source) = default;
        ~PublicKey() = default;
        /**
        Copies an old PublicKey to the current one.

        @param[in] assign The PublicKey to copy from
        */
        PublicKey &operator=(const PublicKey &assign) = default;
        /**
       Moves an old PublicKey to the current one.

       @param[in] assign The PublicKey to move from
       */
        PublicKey &operator=(PublicKey &&assign) = default;
        inline Ciphertext &data() noexcept
        {
            return pk_;
        }

        inline const Ciphertext data() const noexcept
        {
            return pk_;
        }

//        inline Ciphertext &data() const noexcept
//        {
//            return pk_;
//        }


    private:
        Ciphertext pk_;
    };

} // poseidon

#endif //POSEIDON_PUBLICKEY_H
