//
// Created by lxs on 5/29/23.
//

#ifndef POSEIDON_SECRETKEY_H
#define POSEIDON_SECRETKEY_H
#include "rns_polynomial.h"
namespace poseidon {

    class SecretKey {
    public:
        SecretKey();
        SecretKey(const SecretKey& copy);
        SecretKey &operator=(const SecretKey &assign) ;
        ~SecretKey();
        RNSPolynomial* poly() const;
        int newPoly(const PoseidonContext& context, int poly_degree,int rns_num_q,int rns_num_p,int p_offset);

    private:
        RNSPolynomial* sk0_;

    };

} // poseidon

#endif //POSEIDON_SECRETKEY_H
