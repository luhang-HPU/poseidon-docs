//
// Created by lxs on 23-6-21.
//

#ifndef POSEIDON_GALOIS_H
#define POSEIDON_GALOIS_H

#include "define.h"
#include <vector>
using  namespace std;
namespace poseidon {

    // Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

        namespace util {
            class GaloisTool{
            public:
                GaloisTool(uint32_t poly_degree)
                  :poly_degree_(poly_degree)
                {

                }
                std::vector<std::uint32_t> get_elts_all() const noexcept;
                vector<uint32_t> get_elts_from_steps(const vector<int> &steps) const;
                uint32_t get_elt_from_step(int step) const;

            private:
                static constexpr std::uint32_t generator_ = 5;

                uint32_t poly_degree_;
            };

        }
} // poseidon

#endif //POSEIDON_GALOIS_H
