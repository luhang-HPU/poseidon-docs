//
// Created by lxs on 6/5/23.
//

#ifndef POSEIDON_CIPHERTEXT_H
#define POSEIDON_CIPHERTEXT_H
#include "rns_polynomial.h"
#include "MetaData.h"
namespace poseidon {

    class Ciphertext {
    public:
        /**
        Creates an empty public key.
        */
        Ciphertext();
        Ciphertext(const Ciphertext &copy);
        Ciphertext(Ciphertext &&source) = default;
        ~Ciphertext();
        /**
        Copies an old PublicKey to the current one.

        @param[in] assign The PublicKey to copy from
        */
        Ciphertext &operator=(const Ciphertext &assign);
        /**
       Moves an old PublicKey to the current one.

       @param[in] assign The PublicKey to move from
       */
        Ciphertext &operator=(Ciphertext &&assign);
        void newPoly(const PoseidonContext& context,int rns_num_q,int rns_num_p);
        void newPoly(shared_ptr<CrtContext> crtContext,int rns_num_q,int rns_num_p);
        void newMetaData(const mpf_class &scaling_factor,bool isNTT,int level,int poly_degree);
        void newMetaData(const MetaData& metaData);
        bool isValid() const;
        RNSPolynomial* c0() const;
        RNSPolynomial* c1() const;
        MetaData* metaData() const;
    private:
        RNSPolynomial* c0_ = nullptr;
        RNSPolynomial* c1_ = nullptr;
        MetaData* metaData_ = nullptr;

    private:
        int id_c0;
        int id_c1;
    public:
        void compute_id();
        const int get_id_c0() const;
        void set_id_c0(int id);
        const int get_id_c1() const;
        void set_id_c1(int id);
    };

} // poseidon

#endif //POSEIDON_CIPHERTEXT_H
