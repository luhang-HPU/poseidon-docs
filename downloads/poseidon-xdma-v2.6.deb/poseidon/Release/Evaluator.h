//
// Created by lxs on 23-6-16.
//

#ifndef POSEIDON_EVALUATOR_H
#define POSEIDON_EVALUATOR_H
#include "PoseidonContext.h"
#include "Plaintext.h"
#include "Ciphertext.h"
#include "GaloisKeys.h"
#include "RelinKeys.h"
#include "linear_transform.h"
#include "homomorphic_mod.h"
#include "Decryptor.h"
namespace poseidon {

    enum EnvaluatorType{
        Hardware,
        Software
    };

    class Evaluator {
    public:
        inline Evaluator(const PoseidonContext &context)
          :context_(context),degree_(context.poly_degree()),minScale(context_.scaling_factor() >> 1)
        {
        }
    protected:
        PoseidonContext context_;
        uint32_t degree_;
        void create_complex_constant_plain(std::complex<double> const_data,Plaintext& plain,CKKSEncoder &encoder);
        void create_constant_plain(const mpf_class &const_data,Plaintext& plain,const mpf_class &scaling_factor);
        void raise_modulus(Ciphertext &ciph,Ciphertext& result);
        void raise_modulus_hardware(Ciphertext &ciph,Ciphertext& result);
        void raise_modulus_crt(Ciphertext &ciph,Ciphertext& result);

        virtual void ckks_add_plain(Ciphertext &encrypted, Plaintext &plain, Ciphertext &destination) = 0;
        virtual void ckks_multiply_plain( Ciphertext &ciph,  Plaintext &plain,Ciphertext &result,bool isDirect) = 0;
        virtual void bfv_bgv_multiply_plain( Ciphertext &encrypted,  Plaintext &plain,Ciphertext &destination) = 0;

    public:
        void multiply_plain( Ciphertext &ciph,  Plaintext &plain,Ciphertext &result);
        void multiply_const( Ciphertext &ciph,complex<double> constData,Ciphertext &result,CKKSEncoder &encoder,bool isDirect = false);
        void multiply_const( Ciphertext &ciph,double constData,Ciphertext &result,bool isDirect = false);
        void multiply_const( Ciphertext &ciph,const mpf_class &constData,Ciphertext &result,const mpf_class &scale);
        void set_scale(Ciphertext &ciph,const mpf_class &scale,Ciphertext &result);
        void add_const( Ciphertext &ciph,double constData,Ciphertext &result);
        tuple<int,mpf_class> pre_scalar_level(bool is_even,bool is_odd, const map <int,Ciphertext> &monomialBasis,mpf_class currentScale,int currentLevel,
                                                          const PolynomialVector &pol, int log_split,int log_degree);
        inline void set_min_scale(uint64_t scale)
        {
            minScale = scale;
        }


    public:
        virtual void rotate_row(Ciphertext &encrypted, int rot_step, const GaloisKeys &galois_keys, Ciphertext &destination) = 0;
        virtual void rotate_col(Ciphertext &encrypted, const GaloisKeys &galois_keys, Ciphertext &destination) = 0;
    public:
        virtual void ftt_fwd( Plaintext &plain ,Plaintext &result) = 0;
        virtual void ftt_fwd( Ciphertext &ciph, Ciphertext &result) = 0;
        virtual void ftt_inv( Plaintext &plain ,Plaintext &result) = 0;
        virtual void ftt_inv( Ciphertext &ciph ,Ciphertext &result) = 0;
        virtual void read(Ciphertext &ciph) = 0;

        virtual void add_plain( Ciphertext &ciph,  Plaintext &plain,Ciphertext &result) = 0;
        virtual void add( Ciphertext &ciph1,  Ciphertext &ciph2,Ciphertext &result) = 0;
        virtual void sub( Ciphertext &ciph1,  Ciphertext &ciph2,Ciphertext &result) = 0;
        virtual void rotate( Ciphertext &ciph, Ciphertext &result,const GaloisKeys &rot_key, int r) = 0;
        virtual void rescale(Ciphertext &ciph) = 0;
        virtual void rescale_dynamic(Ciphertext &ciph,mpf_class scale) = 0;
        virtual void conjugate( Ciphertext &ciph,Ciphertext &result,const GaloisKeys &conj_key) = 0;
        virtual void multiply( Ciphertext &ciph0, Ciphertext &ciph1,Ciphertext &result, const RelinKeys &relin_key) = 0;
        virtual void multiply_dynamic( Ciphertext &ciph1, Ciphertext &ciph2,Ciphertext &result, const RelinKeys &relin_key) = 0;
        virtual void multiplyByDiagMatrixBSGS( Ciphertext &ciph, MatrixPlain& plain_mat,Ciphertext &result,const GaloisKeys &rot_key) = 0;
        virtual void evaluatePolyVector( Ciphertext &ciph,Ciphertext &destination,const PolynomialVector &polys,mpf_class scalingfactor,const RelinKeys &relin_key,CKKSEncoder &encoder) = 0;
        virtual void evaluatePolyVector( Ciphertext &ciph,Ciphertext &destination,const PolynomialVector &polys,mpf_class scalingfactor,const RelinKeys &relin_key,CKKSEncoder &encoder,Decryptor &dec) = 0;

//        virtual void exp_taylor(const Ciphertext &ciph, Ciphertext &result,const RelinKeys &relin_key) = 0;
//        virtual void exp(const Ciphertext &ciph, Ciphertext &result, complex<double> const_data,const RelinKeys &relin_key, CKKSEncoder enc) = 0;
        virtual void dft( Ciphertext &ciph, LinearMatrixGroup& matrix_group,Ciphertext &result,const GaloisKeys &rot_key) = 0;
        virtual void coeff_to_slot( Ciphertext &ciph, LinearMatrixGroup& matrix_group,Ciphertext &result_real,Ciphertext &result_imag,
                                   const GaloisKeys &rot_key,const GaloisKeys &conj_key,CKKSEncoder &encoder) = 0;
        virtual void slot_to_coeff( Ciphertext &ciph_real, Ciphertext &ciph_imag, LinearMatrixGroup& matrix_group,Ciphertext &result,
                                   const GaloisKeys &rot_key,const GaloisKeys &conj_key,CKKSEncoder &encoder) = 0;

        virtual void eval_mod( Ciphertext &ciph,Ciphertext &result,const EvalModPoly &eva_poly,const RelinKeys &relin_key,CKKSEncoder &encoder) = 0;
        virtual void bootstrap(Ciphertext &ciph,Ciphertext &result,const EvalModPoly &eva_poly,LinearMatrixGroup& matrix_group0,LinearMatrixGroup &matrix_group1,
                       const RelinKeys &relin_key, const GaloisKeys &rot_key,const GaloisKeys &conj_key,CKKSEncoder &encoder) = 0;

    protected:
        mpf_class minScale;
    };

    class EvaluatorFactory{
    public:
        EvaluatorFactory() = default;
        virtual ~EvaluatorFactory() = default;
        static auto DefaultFactory() -> std::shared_ptr<EvaluatorFactory>;
        static auto SoftFactory() -> std::shared_ptr<EvaluatorFactory>;
        auto create(const PoseidonContext &context) -> std::shared_ptr<Evaluator>;
        auto create(const poseidon::PoseidonContext &context,const RelinKeys &relinKeys) -> std::shared_ptr<Evaluator>;

    protected:
        virtual auto create_impl(const PoseidonContext &context) -> std::shared_ptr<Evaluator> = 0;
        virtual auto create_impl(const PoseidonContext &context,const RelinKeys &relinKeys) -> std::shared_ptr<Evaluator> = 0;
    };

} // poseidon

#endif //POSEIDON_EVALUATOR_H
