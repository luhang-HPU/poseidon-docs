//
// Created by lxs on 23-6-15.
//

#ifndef POSEIDON_HOMOMORPHIC_DFT_H
#define POSEIDON_HOMOMORPHIC_DFT_H
#include "define.h"
#include <complex>
#include <iostream>
#include <memory>
#include <vector>
#include <map>
#include <cmath>
#include "linear_transform.h"
#include "CKKSEncoder.h"
using namespace std;
namespace poseidon {
    typedef int DFTType;
    const DFTType Encode = 0;
    const DFTType Decode = 1;
    vector<complex<double> > GetRootsFloat64(int NthRoot);
    tuple<vector<vector<complex<double> > >, vector<vector<complex<double> > >, vector<std::vector<complex<double> > > > ifftPlainVec(int logN, int dslots, vector<complex<double> > roots, vector<int> pow5);
    tuple<vector<vector<complex<double> > >, vector<vector<complex<double> > >, vector<std::vector<complex<double> > > > fftPlainVec(int logN, int dslots, vector<complex<double> > roots, vector<int> pow5);
    void sliceBitReverseInPlace(std::vector<std::complex<double> >& slice, int N);
    void addToDiagMatrix(std::map<int, std::vector<std::complex<double> > >& diagMat, int index, std::vector<std::complex<double> > vec);
    std::vector<std::complex<double> > add(const std::vector<std::complex<double> >& a, const std::vector<std::complex<double> >& b);
    std::vector<std::complex<double> > mul(const std::vector<std::complex<double> >& a, const std::vector<std::complex<double> >& b);
    std::vector<std::complex<double> > rotate(const std::vector<std::complex<double> >& x, int n);
    std::map<int, std::vector<std::complex<double> > > genFFTDiagMatrix(int logL, int fftLevel, std::vector<std::complex<double> > a, std::vector<std::complex<double> > b, std::vector<std::complex<double> > c, DFTType ltType, bool bitreversed);
    std::map<int, std::vector<std::complex<double> > > multiplyFFTMatrixWithNextFFTLevel(std::map<int, std::vector<std::complex<double> > > vec, int logL, int N, int nextLevel, std::vector<std::complex<double> > a, std::vector<std::complex<double> > b, std::vector<std::complex<double> > c, DFTType ltType, bool bitreversed);
    map<int, vector<complex<double> > > genRepackMatrix(int logL, bool bitreversed);

    class HomomorphicDFTMatrixLiteral {
    private:
            // Member variables
        DFTType type_;
        int logN_;
        int logSlots_;
        int levelStart_;
        std::vector<int> levels_;
        bool repackImag2Real_;
        double scaling_;
        bool bitReversed_;
        int logBSGSRatio_;
        int Depth(bool actual);

    public:
        DFTType getType() const;
        int getLogN() const;
        int getLogSlots() const;
        int getLevelStart() const ;
        const vector<int> &getLevels() const ;
        bool getRepackImag2Real() const ;
        double getScaling() const ;
        bool getBitReversed() const ;
        int getLogBSGSRatio() const ;
        vector<map<int, vector<complex<double> > > > GenMatrices();
        void create(LinearMatrixGroup &mat_group,  CKKSEncoder &encoder,int step);

        HomomorphicDFTMatrixLiteral(DFTType type, int logN, int logSlots,
        int levelStart, vector<int> levels,
        bool repackImag2Real = false,
        double scaling = 1.0,
        bool bitReversed = false,
        int logBSGSRatio = 0);
    };



} // poseidon

#endif //POSEIDON_HOMOMORPHIC_DFT_H
