#ifndef RNS_POLYNOMIAL_H
#define RNS_POLYNOMIAL_H

#include "define.h"
#include "PoseidonContext.h"
#include <gmpxx.h>
namespace poseidon 
{
  class RNSPolynomial
  {
  private:
    int rns_num_q_;
    int rns_num_p_;
    int p_offset_;
    int ring_degree_;
    bool value_is_dot_;
    int id;
    
    std::shared_ptr<poseidon::CrtContext> crt_context_{ nullptr };
    int apply();
    
    
    
    
  public:
    std::vector<std::vector<uint32_t>> rns_coeffs_q{0,std::vector<uint32_t>(0,0)};
    std::vector<std::vector<uint32_t>> rns_coeffs_p{0,std::vector<uint32_t>(0,0)};
    std::vector<uint32_t> rns_coeffs_t{0,0};
    //std::vector<std::vector<uint32_t>> combine_coeffs{0,std::vector<uint32_t>(0,0)};
    RNSPolynomial(const PoseidonContext& param, int rns_num_q, int rns_num_p, bool value_is_dot = false);
    RNSPolynomial(const PoseidonContext& param, vector<vector<uint32_t>> coeffs_q, vector<vector<uint32_t>> coeffs_p, bool value_is_dot = false);
    RNSPolynomial(const PoseidonContext& param, vector<vector<uint32_t>> coeffs_q, bool value_is_dot = false);
    RNSPolynomial(const PoseidonContext& param, mpz_t* coeffs, int rns_num_q, int rns_num_p, bool value_is_dot = false);
    RNSPolynomial(const RNSPolynomial& poly);
    RNSPolynomial(const std::shared_ptr<poseidon::CrtContext> crt_context, int rns_num_q,int rns_num_p,bool value_is_dot = false);

    int init_p();
    void reSize(int level);

    int rns_conj(RNSPolynomial &poly_dest,bool ignore_p = false);
    int rns_coe_conj(RNSPolynomial &poly_dest,bool ignore_p = false);
    int rns_rotate(RNSPolynomial &poly_dest, int k,bool ignore_p = false);
    int mod_mult(RNSPolynomial poly_op2,RNSPolynomial &poly_dest,bool ignore_p = false);
    int mod_add(RNSPolynomial poly_op2,RNSPolynomial &poly_dest,bool ignore_p = false);
    int neg(RNSPolynomial &poly_dest,bool ignore_p = false);
    int mod_sub(RNSPolynomial poly_op2,RNSPolynomial &poly_dest,bool ignore_p = false);
    int mod_up(int level);
    int mod_down(int level);
    int rescale(int level);
    int drop(int level);
    std::shared_ptr<poseidon::CrtContext> get_crt_context();
    int gen_rns_coeffs(mpz_t* coeffs);
    int copy( vector<vector<uint32_t>> coeffs_q, vector<vector<uint32_t>> coeffs_p);
    int copy(const RNSPolynomial& copy);
    int rns_num_q();
    void set_rns_num_q(int value);
    int rns_num_p();
    void set_rns_num_p(int value);
    int degree();
    bool value_is_dot();
    void set_dot_state(bool isTrue);
    void coeff_to_dot();
    void dot_to_coeff();
    void sync_rns_q(const RNSPolynomial& poly);
    void combine(vector<vector<uint32_t>>& poly_dest);

      void setid(int id);
      int getid() const;
  };

}
#endif
