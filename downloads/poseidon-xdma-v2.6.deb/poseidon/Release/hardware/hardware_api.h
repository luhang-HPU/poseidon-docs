#ifndef HARDWARE_API_H
#define HARDWARE_API_H
#include "hardware_structure.h"
#include <vector>
#include "../define.h"
#include "xdma.h"
#include "../PoseidonContext.h"
#include "ConfigGen.h"
#include "../RelinKeys.h"
#include "../GaloisKeys.h"
#include "../Plaintext.h"
using namespace poseidon;
class Hardware_CKKSApi {
public:
    // 构造函数
    Hardware_CKKSApi(std::shared_ptr<CrtContext> crt_context, uint8_t current_rns_num, uint8_t rns_max, uint8_t rns_ud_l, uint8_t rns_ud_h);
//    Hardware_CKKSApi(int rns_num, std::vector<uint32_t> rns_mod, int degree);
    //Hardware_CKKSApi()=default;
    Hardware_CKKSApi(uint8_t rns_max);

    // 析构函数
    ~Hardware_CKKSApi()=default;
    void set_level(int level);
    // ckks_add_ciph 方法
    void hardware_init();

    static void ntt_128(std::vector<std::vector<uint32_t>> &coeff, std::vector<std::vector<uint32_t>> &result);
    static void intt_128(std::vector<std::vector<uint32_t>> &coeff, std::vector<std::vector<uint32_t>> &result);
    void ckks_add_ciph(uint64_t ciph1_addr, uint64_t ciph2_addr, uint64_t wb_addr);
    void ckks_sub_ciph(uint64_t ciph1_addr, uint64_t ciph2_addr, uint64_t wb_addr);
    void ckks_add_plain(uint64_t ciph1, uint64_t plain1, uint64_t wb_addr) ;
    void ckks_mult_plain(uint64_t ciph_addr,uint64_t plain_addr,uint64_t wb_addr) ;
    void ckks_conjugate(uint64_t ciph_addr,uint64_t wb_addr,
                        std::vector<std::vector<uint32_t>> up_param0, std::vector<std::vector<uint32_t>> down_param0,
                        std::vector<std::vector<uint32_t>> up_param1, std::vector<std::vector<uint32_t>> down_param1,
                        std::vector<std::vector<uint32_t>> down_param2) ;
    void ckks_rescale(uint64_t ciph_addr, std::vector<std::vector<uint32_t>> rescale_param, uint64_t wb_addr);
    void ckks_mult_ciph(uint64_t ciph1_addr, uint64_t ciph2_addr, uint64_t wb_addr,
                        std::vector<std::vector<uint32_t>> up_param0, std::vector<std::vector<uint32_t>> down_param0,
                        std::vector<std::vector<uint32_t>> up_param1, std::vector<std::vector<uint32_t>> down_param1,
                        std::vector<std::vector<uint32_t>> down_param2) ;
    void ckks_rotate(uint64_t ciph_addr, uint32_t kr, uint64_t wb_addr, uint64_t  rot_key_addr,
                     std::vector<std::vector<uint32_t>> up_param0,std::vector<std::vector<uint32_t>> down_param0,
                     std::vector<std::vector<uint32_t>> up_param1,std::vector<std::vector<uint32_t>> down_param1,
                     std::vector<std::vector<uint32_t>> down_param2) ;
    void ftt_fwd(uint64_t ciph_addr,uint64_t wb_addr);
    void ftt_inv(uint64_t ciph_addr,uint64_t wb_addr);
    int send_data(const Ciphertext &ciph, const uint64_t &addr); // TO-DO, change to private
    int send_data(const Plaintext &plain, const uint64_t &addr);
    void XDMA_get(uint64_t hard_addr, Ciph *,uint32_t degree);
    void XDMA_send(uint64_t hard_addr, void* soft_addr, bool plain=false);
    static uint32_t *vector2array(std::vector<std::vector<uint32_t>> vector);
    static uint32_t *vector2array(std::vector<std::vector<uint32_t>> vector0,std::vector<std::vector<uint32_t>> vector1);
    static void vectorflatten(std::vector<std::vector<uint32_t>> &src_vec,std::vector<uint32_t> &des_vec);
    static void array2vector(uint32_t *array,std::vector<std::vector<uint32_t>> &,int,int);
    void ckks_config(std::vector<uint32_t> modulus, std::vector<uint64_t> &barrett_c0, std::vector<uint64_t> &barrett_c1,
                      std::vector<std::vector<uint32_t>>& rou, std::vector<std::vector<uint32_t>>& rou_inv,
                      std::vector<uint32_t>& fusion_rou, std::vector<uint32_t>& fusion_rou_inv,
                      const vector<uint32_t> &intt_param);
//    void ckks_config(std::vector<std::vector<uint32_t>>& relinear_key_p0_vector, std::vector<std::vector<uint32_t>>& relinear_key_q0_vector,
//                     std::vector<std::vector<uint32_t>>& relinear_key_p1_vector, std::vector<std::vector<uint32_t>>& relinear_key_q1_vector,
//                     std::vector<std::vector<uint32_t>>& conjugate_key_p0_vector, std::vector<std::vector<uint32_t>>& conjugate_key_q0_vector,
//                     std::vector<std::vector<uint32_t>>& conjugate_key_p1_vector, std::vector<std::vector<uint32_t>>& conjugate_key_q1_vector,
//                     std::vector<uint32_t> modulus, std::vector<uint32_t> barrett_c0, std::vector<uint32_t> barrett_c1,
//                     std::vector<std::vector<uint32_t>>& rou, std::vector<std::vector<uint32_t>>& rou_inv,
//                     std::vector<uint32_t>& fusion_rou, std::vector<uint32_t>& fusion_rou_inv,
//                     vector<uint32_t> intt_param);

    void ckks_conj_key_config(std::vector<std::vector<uint32_t>>& conjugate_key_p0_vector, std::vector<std::vector<uint32_t>>& conjugate_key_q0_vector,
            std::vector<std::vector<uint32_t>>& conjugate_key_p1_vector, std::vector<std::vector<uint32_t>>& conjugate_key_q1_vector);

    void ckks_relin_key_config(std::vector<std::vector<uint32_t>>& relinear_key_p0_vector, std::vector<std::vector<uint32_t>>& relinear_key_q0_vector,
                              std::vector<std::vector<uint32_t>>& relinear_key_p1_vector, std::vector<std::vector<uint32_t>>& relinear_key_q1_vector);


    short rns_num;
    short rns_max;
    short rns_ud_l;
    short rns_ud_h;
private:
    std::shared_ptr<poseidon::CrtContext> crt_context_{ nullptr };
    std::vector<uint32_t> rns_mod;
    short degree;
    uint32_t length;

    uint64_t relinear_key_addr;
};

#endif //HARDWARE_API_H

