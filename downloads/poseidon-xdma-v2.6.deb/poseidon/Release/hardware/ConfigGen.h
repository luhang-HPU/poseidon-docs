#ifndef CFG_GEN_H
#define CFG_GEN_H

#include <vector>
#include "../define.h"
#include "../ConvContext.h"

/*
addr_step    2048bit 
0-1: modulus  32bit
2-4: c        33bit  


*/
#define PARAM_MAX_NUM           120

#define STACK_BIT               256
#define STACK_NUM               8
#define STACK_GROUP_BIT         (STACK_BIT*STACK_NUM)

using namespace std;
namespace poseidon 
{
    class ConfigGen{
    private:
      uint32_t param_max_num_;
      vector <vector <uint32_t>> param_global_list_;
      vector <uint32_t> comb_root_list_;
      vector <uint32_t> param_modulus_;
      vector <uint32_t> param_modulus_c_;
      vector <uint32_t> param_modulus_cc_;
      vector <uint32_t> param_conv_;
      vector <uint32_t> param_conv_inv_;
      int degree_;
      int w_size_;
      int r_size_;
      int cfg_list_num_;
      //uint64_t w_[21][585];
      uint64_t w_[21][8192];
      uint64_t r_[4][384];
      int gen_list_uniform(const vector <uint32_t> &param_src, vector <uint32_t> &param_dest); //modulus , conv_param
      int gen_list_uniform2(const vector<vector <uint32_t>> &param_src,std::vector <uint32_t> &param_dest);

      int cal_w_rns1(vector<uint32_t> rou,uint32_t modulus);
      int gen_list_global(int list_index);
      int gen_list_global2();
      

    public:
      ConfigGen(vector <uint32_t> param_modulus,vector <uint64_t> param_modulus_c,vector <uint64_t> param_modulus_cc, std::vector <ConvContext>  conv,int degree);
      int gen_comb_root_degree_4096_rns1_list(vector <uint32_t> rou,uint32_t modulus);
      int cal_w_chnl_data(const vector<vector<uint32_t>> &rou,vector<uint32_t> modulus);
      vector <vector <uint32_t>> param_list();
      vector <uint32_t> comb_root_list();
      int gen_list_series(const vector <uint64_t> &param_src, int bit_num, vector <uint32_t> &param_dest);
    };
}

#endif