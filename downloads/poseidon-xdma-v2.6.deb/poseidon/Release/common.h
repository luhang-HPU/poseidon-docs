//
// Created by lxs on 5/30/23.
//

#ifndef POSEIDON_COMMON_H
#define POSEIDON_COMMON_H
#include "define.h"

namespace poseidon {
    namespace util{
        constexpr int bytes_per_uint64 = sizeof(std::uint64_t);

        constexpr int bits_per_nibble = 4;

        constexpr int bits_per_byte = 8;

        // IsNegligibleThreshold : threshold under which a coefficient
// of a polynomial is ignored.
        constexpr double IsNegligibleThreshold  = 1e-14;

        constexpr int bits_per_uint64 = bytes_per_uint64 * bits_per_byte;

        constexpr int nibbles_per_byte = 2;

        constexpr int nibbles_per_uint64 = bytes_per_uint64 * nibbles_per_byte;

        void poseidon_memzero(void *data, size_t size);

//        template <typename T, typename = std::enable_if_t<is_uint32_v<T> || is_uint64_v<T>>>
//        inline T reverse_bits(T operand, int bit_count)
//        {
//#ifdef SEAL_DEBUG
//            if (bit_count < 0 ||
//                static_cast<std::size_t>(bit_count) > mul_safe(sizeof(T), static_cast<std::size_t>(bits_per_byte)))
//            {
//                throw std::invalid_argument("bit_count");
//            }
//#endif
//            // Just return zero if bit_count is zero
//            return (bit_count == 0) ? T(0)
//                                    : reverse_bits(operand) >> (sizeof(T) * static_cast<std::size_t>(bits_per_byte) -
//                                                                static_cast<std::size_t>(bit_count));
//        }
        inline void print_example_banner(std::string title)
        {
            if (!title.empty())
            {
                std::size_t title_length = title.length();
                std::size_t banner_length = title_length + 2 * 10;
                std::string banner_top = "+" + std::string(banner_length - 2, '-') + "+";
                std::string banner_middle = "|" + std::string(9, ' ') + title + std::string(9, ' ') + "|";

                std::cout << std::endl << banner_top << std::endl << banner_middle << std::endl << banner_top << std::endl;
            }
        }
        inline constexpr int hamming_weight(unsigned char value)
        {
            int t = static_cast<int>(value);
            t -= (t >> 1) & 0x55;
            t = (t & 0x33) + ((t >> 2) & 0x33);
            return (t + (t >> 4)) & 0x0F;
        }

        template <typename... Ts>
        struct VoidType
        {
            using type = void;
        };

        template <typename... Ts>
        using poseidon_void_t = typename VoidType<Ts...>::type;

        template <typename ForwardIt, typename Size, typename Func>
        inline ForwardIt poseidon_for_each_n(ForwardIt first, Size size, Func &&func)
        {
            for (; size--; (void)++first)
            {
                func(*first);
            }
            return first;
        }

        template <typename T, typename...>
        struct IsUInt64
                : std::conditional<
                        std::is_integral<T>::value && std::is_unsigned<T>::value && (sizeof(T) == sizeof(std::uint64_t)),
                        std::true_type, std::false_type>::type
        {};

        template <typename T, typename U, typename... Rest>
        struct IsUInt64<T, U, Rest...>
                : std::conditional<IsUInt64<T>::value && IsUInt64<U, Rest...>::value, std::true_type, std::false_type>::type
        {};

        template <typename T, typename... Rest>
        constexpr bool is_uint64_v = IsUInt64<T, Rest...>::value;

        template <typename T, typename...>
        struct IsUInt32
                : std::conditional<
                        std::is_integral<T>::value && std::is_unsigned<T>::value && (sizeof(T) == sizeof(std::uint32_t)),
                        std::true_type, std::false_type>::type
        {};

        template <typename T, typename U, typename... Rest>
        struct IsUInt32<T, U, Rest...>
                : std::conditional<IsUInt32<T>::value && IsUInt32<U, Rest...>::value, std::true_type, std::false_type>::type
        {};

        template <typename T, typename... Rest>
        constexpr bool is_uint32_v = IsUInt32<T, Rest...>::value;



        template <typename T, typename = std::enable_if_t<is_uint32_v<T> || is_uint64_v<T>>>
         inline constexpr T reverse_bits(T operand) noexcept
        {
            if constexpr(is_uint32_v<T>)
                    {
                            operand = (((operand & T(0xaaaaaaaa)) >> 1) | ((operand & T(0x55555555)) << 1));
                    operand = (((operand & T(0xcccccccc)) >> 2) | ((operand & T(0x33333333)) << 2));
                    operand = (((operand & T(0xf0f0f0f0)) >> 4) | ((operand & T(0x0f0f0f0f)) << 4));
                    operand = (((operand & T(0xff00ff00)) >> 8) | ((operand & T(0x00ff00ff)) << 8));
                    return static_cast<T>(operand >> 16) | static_cast<T>(operand << 16);
                    }
            else if constexpr(is_uint64_v<T>)
                    {

                            return static_cast<T>(reverse_bits(static_cast<std::uint32_t>(operand >> 32))) |
                            (static_cast<T>(reverse_bits(static_cast<std::uint32_t>(operand & T(0xFFFFFFFF)))) << 32);

                    }
        }

    template <typename T, typename = std::enable_if_t<is_uint32_v<T> || is_uint64_v<T>>>
     inline T reverse_bits(T operand, int bit_count)
        {

            // Just return zero if bit_count is zero
            return (bit_count == 0) ? T(0)
            : reverse_bits(operand) >> (sizeof(T) * static_cast<std::size_t>(bits_per_byte) -
            static_cast<std::size_t>(bit_count));
        }

    }

} // poseidon

#endif //POSEIDON_COMMON_H
