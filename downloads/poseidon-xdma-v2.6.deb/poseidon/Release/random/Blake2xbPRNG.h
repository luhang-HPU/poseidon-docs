//
// Created by lxs on 6/1/23.
//

#ifndef POSEIDON_BLAKE2XBPRNG_H
#define POSEIDON_BLAKE2XBPRNG_H
#include "UniformRandomGenerator.h"
#include "UniformRandomGeneratorFactory.h"
#include "blake2.h"
#include "blake2-impl.h"
namespace poseidon {

    class Blake2xbPRNG:public UniformRandomGenerator{
    public:
        /**
        Creates a new Blake2xbPRNG instance initialized with the given seed.

        @param[in] seed The seed for the random number generator
        */
        Blake2xbPRNG(prng_seed_type seed) : UniformRandomGenerator(seed)
        {}

        /**
        Destroys the random number generator.
        */
        ~Blake2xbPRNG() = default;

    protected:
        prng_type type() const noexcept override
        {
            return prng_type::blake2xb;
        }

        void refill_buffer() override;

    private:
        std::uint64_t counter_ = 0;
    };

    class Blake2xbPRNGFactory : public UniformRandomGeneratorFactory
    {
    public:
        /**
        Creates a new Blake2xbPRNGFactory. The seed will be sampled randomly
        for each Blake2xbPRNG instance created by the factory instance, which is
        desirable in most normal use-cases.
        */
        Blake2xbPRNGFactory() : UniformRandomGeneratorFactory()
        {}

        /**
        Creates a new Blake2xbPRNGFactory and sets the default seed to the given
        value. For debugging purposes it may sometimes be convenient to have the
        same randomness be used deterministically and repeatedly. Such randomness
        sampling is naturally insecure and must be strictly restricted to debugging
        situations. Thus, most users should never use this constructor.

        @param[in] default_seed The default value for a seed to be used by all
        created instances of Blake2xbPRNG
        */
        Blake2xbPRNGFactory(prng_seed_type default_seed) : UniformRandomGeneratorFactory(default_seed)
        {}

        /**
        Destroys the random number generator factory.
        */
        ~Blake2xbPRNGFactory() = default;

    protected:

         auto create_impl(prng_seed_type seed) -> std::shared_ptr<UniformRandomGenerator> override
                {
                        return std::make_shared<Blake2xbPRNG>(seed);
                }

    private:
    };


} // poseidon

#endif //POSEIDON_BLAKE2XBPRNG_H
