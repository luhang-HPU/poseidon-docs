//
// Created by lxs on 6/1/23.
//

#ifndef POSEIDON_RANDOMTOSTANDARDADAPTER_H
#define POSEIDON_RANDOMTOSTANDARDADAPTER_H
#include "UniformRandomGenerator.h"
namespace poseidon {

    class RandomToStandardAdapter {
    private:
        std::shared_ptr<UniformRandomGenerator> generator_;
    public:
        using result_type = std::uint32_t;
        RandomToStandardAdapter(std::shared_ptr<UniformRandomGenerator> generator) : generator_(generator)
        {
            /**
        Creates a new RandomToStandardAdapter backed by a given UniformRandomGenerator.

        @param[in] generator A backing UniformRandomGenerator instance
        @throws std::invalid_argument if generator is null
        */
            if (!generator_)
            {
                throw std::invalid_argument("generator cannot be null");
            }
        }

        /**
       Returns a new random number from the backing UniformRandomGenerator.
       */
        inline result_type operator()()
        {
            return generator_->generate();
        }

        /**
        Returns the backing UniformRandomGenerator.
        */
        inline std::shared_ptr<UniformRandomGenerator> generator() const noexcept
        {
            return generator_;
        }

        /**
        Returns the smallest possible output value.
        */
        inline static constexpr result_type min() noexcept
        {
            return std::numeric_limits<result_type>::min();
        }

        /**
        Returns the largest possible output value.
        */
        static constexpr result_type max() noexcept
        {
            return std::numeric_limits<result_type>::max();
        }

    };

} // poseidon

#endif //POSEIDON_RANDOMTOSTANDARDADAPTER_H
