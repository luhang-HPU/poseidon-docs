//
// Created by lxs on 5/22/23.
//

#ifndef POSEIDON_PLAINTEXT_H
#define POSEIDON_PLAINTEXT_H

#include "rns_polynomial.h"
#include "PoseidonContext.h"
#include "MetaData.h"
namespace poseidon {

    class Plaintext {
    private:
        RNSPolynomial* poly_;
        MetaData* metaData_;
    public:
        Plaintext();
        Plaintext(const Plaintext& copy);
        Plaintext(const PoseidonContext &param, int level);
        Plaintext &operator=(const Plaintext &assign);
        Plaintext &operator=(Plaintext &&assign);
        ~Plaintext();
        RNSPolynomial* poly() const;
        MetaData* metaData() const;

        int newMetaData(const mpf_class &scaling_factor,bool isNTT,int level,int poly_degree);
        int newPoly(const PoseidonContext& context,int level);
        int newPoly(shared_ptr<CrtContext> crtContext,int level);
        bool isValid() const;

    private:
        int id;
    public:
        void compute_id();
        const int get_id() const ;
        void set_id(int id);
    };

} // poseidon

#endif //POSEIDON_PLAINTEXT_H
