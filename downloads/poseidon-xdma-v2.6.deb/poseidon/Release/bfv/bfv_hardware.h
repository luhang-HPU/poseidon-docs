//
// Created by lrj on 23-6-19.
//


#ifndef BFV_HARDWARE_API_H
#define BFV_HARDWARE_API_H

#include <algorithm>
#include <chrono>
#include <cstddef>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <mutex>
#include <numeric>
#include <random>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
#include <gmpxx.h>
#include "../PoseidonContext.h"
#include "../Ciphertext.h"
#include "../Plaintext.h"
#include "../RelinKeys.h"
#include "../GaloisKeys.h"
#include "../hardware/xdma.h"
#include "../hardware/ConfigGen.h"
using namespace poseidon;
#define BFV_RNS_MODS_D1 std::vector<uint32_t>{(uint32_t)2147565569, (uint32_t)2147573761, (uint32_t)4294483969, (uint32_t)4294475777, (uint32_t)4294451201, (uint32_t)4294008833, (uint32_t)4294828033, (uint32_t)(1 << 31) + 1, (uint32_t)2147721217}
#define BFV_RNS_MODS_D2 std::vector<uint32_t>{(uint32_t)2147565569, (uint32_t)2148155393, (uint32_t)2148384769, (uint32_t)2148728833, (uint32_t)4293836801, (uint32_t)4293230593, (uint32_t)4293181441, (uint32_t)4292984833, (uint32_t)4292804609, (uint32_t)4292755457, (uint32_t)4294475777, (uint32_t)(1 << 31) + 1, (uint32_t)2148794369}
#define BFV_RNS_MODS_D3 std::vector<uint32_t>{(uint32_t)2148728833, (uint32_t)2148794369, (uint32_t)2149810177, (uint32_t)2150072321, (uint32_t)2150301697, (uint32_t)2150563841, (uint32_t)2150694913, (uint32_t)2150760449, (uint32_t)4293230593, (uint32_t)4292804609, (uint32_t)4292313089, (uint32_t)4292149249, (uint32_t)4292116481, (uint32_t)4292018177, (uint32_t)4291952641, (uint32_t)4289462273, (uint32_t)4288905217, (uint32_t)4288806913, (uint32_t)4294475777, (uint32_t)(1 << 31) + 1, (uint32_t)2150891521}
#define BFV_RNS_MODS_D4 std::vector<uint32_t>{(uint32_t)2148728833, (uint32_t)2148794369, (uint32_t)2150301697, (uint32_t)2150563841, (uint32_t)2150694913, (uint32_t)2150760449, (uint32_t)2150891521, (uint32_t)2151677953, (uint32_t)2152071169, (uint32_t)2152923137, (uint32_t)2153054209, (uint32_t)2153250817, (uint32_t)2153840641, (uint32_t)2154823681, (uint32_t)2155216897, (uint32_t)4292149249, (uint32_t)4292018177, (uint32_t)4291952641, (uint32_t)4289462273, (uint32_t)4288806913, (uint32_t)4288086017, (uint32_t)4287823873, (uint32_t)4286709761, (uint32_t)4286251009, (uint32_t)4286054401, (uint32_t)4285464577, (uint32_t)4284874753, (uint32_t)4284088321, (uint32_t)4283301889, (uint32_t)4281204737, (uint32_t)4281008129, (uint32_t)4280156161, (uint32_t)4293918721, (uint32_t)(1 << 31) + 1, (uint32_t)2155282433}

#define BGV_RNS_MODS_D2 std::vector<uint32_t>{(uint32_t)2147565569, (uint32_t)2148155393, (uint32_t)2148384769, (uint32_t)2148728833, (uint32_t)2148794369, (uint32_t)4227862528}
#define BGV_RNS_MODS_D3 std::vector<uint32_t>{(uint32_t)2148728833, (uint32_t)2148794369, (uint32_t)2149810177, (uint32_t)2150072321, (uint32_t)2150301697, (uint32_t)2150563841, (uint32_t)2150694913, (uint32_t)2150760449, (uint32_t)2150891521, (uint32_t)3221229568}
#define BGV_RNS_MODS_D4 std::vector<uint32_t>{(uint32_t)2148728833, (uint32_t)2148794369, (uint32_t)2150301697, (uint32_t)2150563841, (uint32_t)2150694913, (uint32_t)2150760449, (uint32_t)2150891521, (uint32_t)2151677953, (uint32_t)2152071169, (uint32_t)2152923137, (uint32_t)2153054209, (uint32_t)2153250817, (uint32_t)2153840641, (uint32_t)2154823681, (uint32_t)2155216897, (uint32_t)2155282433, (uint32_t)3221229568}


class Hardware_BFVBGV_Api{
public:

    Hardware_BFVBGV_Api(PoseidonContext context);
    Hardware_BFVBGV_Api(PoseidonContext context, const poseidon::RelinKeys &relin_keys);

    int config();
    int config_relin_keys(const RelinKeys &relin_keys);
    int config_galois_keys(const GaloisKeys &rot_keys, uint64_t rot_key_addr,uint64_t kr);

    int send_data(const Ciphertext &ciph, const uint64_t &addr); // TO-DO, change to private
    int send_data(const Plaintext &plain, const uint64_t &addr);
    int read_data(Ciphertext &ciph, uint64_t addr);
    int read_data(Plaintext &plain, uint64_t addr);

    int add_ciph(uint64_t ciph0_addr,uint64_t ciph1_addr,uint64_t wb_addr) const;
    int sub_ciph(uint64_t ciph0_addr,uint64_t ciph1_addr,uint64_t wb_addr) const;
    int add_plain(uint64_t ciph_addr,uint64_t plain_addr,uint64_t wb_addr) const;
    int sub_plain(uint64_t ciph_addr,uint64_t plain_addr,uint64_t wb_addr) const;
    int rotate(uint64_t ciph_addr,uint64_t wb_addr,uint64_t rot_key_addr, uint64_t kr) const;
    int multiply_plain(uint64_t ciph1_addr,uint64_t plain_addr,uint64_t wb_addr) const;
    int multiply_ciph(uint64_t ciph1_addr,uint64_t ciph2_addr) const;
    int relinearize(uint64_t ciph1_addr,uint64_t ciph2_addr,uint64_t wb_addr) const;
    int send_key(const Ciphertext &key_ciph, uint64_t addr) const;
    //int send_key(const seal::Ciphertext &key_ciph, uint64_t addr) const;
    int config_intt();
    int config_intt_mult();




    inline const uint32_t poly_length() const{
        return poly_length_;
    }
    inline const uint32_t rns_max() const{
        return rns_max_;
    }
    inline const uint32_t deg_flag()const{
        return deg_flag_;
    }
    inline const uint32_t degree() const{
        return degree_;
    }


private:
    PoseidonContext context_;
    uint32_t deg_flag_;
    uint32_t degree_;
    SchemeType scheme_type_;
    uint32_t rns_max_;
    uint32_t rns_q_;
    uint32_t rns_b_;
    uint32_t rns_qk_;

    uint32_t poly_length_;
    uint64_t plain_modulus_;
    uint32_t plain_modulus_w32_;
    mpz_t q_mod_t_;
    bool configured_=false;
    std::vector<uint32_t> rns_mods_;
    std::vector<std::vector<uint32_t>> intt_param_;
    std::vector<std::vector<uint32_t>> intt_param_mult_;
    std::vector<std::vector<uint32_t>> conv_para0_0th_;
    std::vector<std::vector<uint32_t>> conv_para1_0th_;
    std::vector<std::vector<uint32_t>> conv_para0_1th_;
    std::vector<std::vector<uint32_t>> conv_para1_1th_;
    std::vector<std::vector<uint32_t>> conv_para0_2th_;
    std::vector<std::vector<uint32_t>> conv_para1_2th_;
    std::vector<std::vector<uint32_t>> conv_para0_3th_;
    std::vector<std::vector<uint32_t>> conv_para1_3th_;

    void conv_para_compute(uint32_t rns_c, uint32_t rns_b,
    const std::vector<uint32_t> &rns_c_mod, const std::vector<uint32_t> &rns_b_mod,
            std::vector<std::vector<uint32_t>> &rns_mod_inv, std::vector<std::vector<uint32_t>> &rns_conv_array);
};



#include "MemoryPool2.h"


#endif //BFV_TEST_HARD_EVALUATOR_H
