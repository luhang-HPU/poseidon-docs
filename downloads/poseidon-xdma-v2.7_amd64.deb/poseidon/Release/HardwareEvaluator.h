//
// Created by lxs on 23-6-16.
//

#ifndef POSEIDON_HARDWAREEVALUATOR_H
#define POSEIDON_HARDWAREEVALUATOR_H
#include "Evaluator.h"
#include "PoseidonContext.h"
#include "hardware/ConfigGen.h"
#include "hardware/hardware_api.h"
#include "./bfv/bfv_hardware.h"
namespace poseidon {

    class HardwareEvaluator : public Evaluator
    {
    public:
        HardwareEvaluator(const PoseidonContext &context)
        : Evaluator(context),rns_max_(context.crt_context()->primes().size()),rns_ud_l_(context.crt_context()->num_primes_q()),
        rns_ud_h_(context.crt_context()->primes().size()-1),
        hardware_api_(context.crt_context(),rns_ud_l_,rns_max_,rns_ud_l_,rns_ud_h_),
        hardware_bfv_api_(Hardware_BFVBGV_Api(context))
        {
            //Hardware_CKKSApi hardware_api(context.crt_context(),rns_ud_l_,rns_max_,rns_ud_l_,rns_ud_h_);
            if(context_.scheme_type() == CKKS){
                hardware_api_.hardware_init();
                this->degree_ = context_.poly_degree();
                auto memoryManager=  MemoryManager::getInstance();
            }
            else if(context_.scheme_type() == BFV){
                hardware_bfv_api_.config();
                this->poly_length_ = hardware_bfv_api_.poly_length();
                this->rns_max_ = hardware_bfv_api_.rns_max();
                this->deg_flag_ = hardware_bfv_api_.deg_flag();
                this->degree_ = hardware_bfv_api_.degree();
                auto memoryManager=  bfv::MemoryManager::getInstance(hardware_bfv_api_);

            }
        }

        HardwareEvaluator(const PoseidonContext &context,const RelinKeys &relinKeys)
                : Evaluator(context),rns_max_(context.crt_context()->primes().size()),rns_ud_l_(context.crt_context()->num_primes_q()),
                  rns_ud_h_(context.crt_context()->primes().size()-1),
                  hardware_api_(context.crt_context(),rns_ud_l_,rns_max_,rns_ud_l_,rns_ud_h_),
                  hardware_bfv_api_(Hardware_BFVBGV_Api(context,relinKeys))
        {
            //Hardware_CKKSApi hardware_api(context.crt_context(),rns_ud_l_,rns_max_,rns_ud_l_,rns_ud_h_);
            if(context_.scheme_type() == CKKS){
                hardware_api_.hardware_init();
            }
            else if(context_.scheme_type() == BFV || context_.scheme_type() == BGV){
                hardware_bfv_api_.config();
                hardware_bfv_api_.config_relin_keys(relinKeys);
                this->poly_length_ = hardware_bfv_api_.poly_length();
                this->rns_max_ = hardware_bfv_api_.rns_max();
                this->deg_flag_ = hardware_bfv_api_.deg_flag();
                this->degree_ = hardware_bfv_api_.degree();

                auto memoryManager=  bfv::MemoryManager::getInstance(hardware_bfv_api_);
            }
        }

    public:
        void add_plain( Ciphertext &ciph,  Plaintext &plain,Ciphertext &result) override; //ckks & bfv
        void add( Ciphertext &ciph1,  Ciphertext &ciph2,Ciphertext &result) override; //ckks & bfv
        void sub( Ciphertext &ciph1,  Ciphertext &ciph2,Ciphertext &result) override; //ckks & bfv

    public: //bfv
        void rotate_row(Ciphertext &encrypted, int rot_step, const GaloisKeys &galois_keys, Ciphertext &destination);
        void rotate_col(Ciphertext &encrypted, const GaloisKeys &galois_keys, Ciphertext &destination);
        

        //ckks
    public:
        void ftt_fwd( Plaintext &plain ,Plaintext &result) override;
        void ftt_fwd( Ciphertext &ciph, Ciphertext &result) override;
        void ftt_inv( Plaintext &plain ,Plaintext &result) override;
        void ftt_inv( Ciphertext &ciph ,Ciphertext &result) override;
        static void ntt128(Plaintext &plain, Plaintext &result);
        static void intt128(Plaintext &plain, Plaintext &result);
        void read(Ciphertext &ciph) override;

        void rotate( Ciphertext &ciph, Ciphertext &result,const GaloisKeys &rot_key, int r) override;
        void rescale(Ciphertext &ciph) override;
        void rescale_dynamic(Ciphertext &ciph,mpf_class scale) override;

        void conjugate( Ciphertext &ciph,Ciphertext &result ,const GaloisKeys &conj_key) override;
        void multiply( Ciphertext &ciph0, Ciphertext &ciph1,Ciphertext &result, const RelinKeys &relin_key) override;
        void multiply_dynamic( Ciphertext &ciph1, Ciphertext &ciph2,Ciphertext &result, const RelinKeys &relin_key) override;

        void multiplyByDiagMatrixBSGS( Ciphertext &ciph, MatrixPlain& plain_mat,Ciphertext &result,const GaloisKeys &rot_key) override;
        void evaluatePolyVector( Ciphertext &ciph,Ciphertext &destination,const PolynomialVector &polys,mpf_class scalingfactor,const RelinKeys &relin_key,CKKSEncoder &encoder) override;
        void evaluatePolyVector( Ciphertext &ciph,Ciphertext &destination,const PolynomialVector &polys,
                                 mpf_class scalingfactor,const RelinKeys &relin_key,CKKSEncoder &encoder,Decryptor &dec);

        void dft( Ciphertext &ciph, LinearMatrixGroup& matrix_group,Ciphertext &result,const GaloisKeys &rot_key) override;
        void coeff_to_slot( Ciphertext &ciph, LinearMatrixGroup& matrix_group,Ciphertext &result_real,Ciphertext &result_imag,
                           const GaloisKeys &rot_key,const GaloisKeys &conj_key,CKKSEncoder &encoder) override;
        void slot_to_coeff( Ciphertext &ciph_real, Ciphertext &ciph_imag, LinearMatrixGroup& matrix_group,Ciphertext &result,
        const GaloisKeys &rot_key,const GaloisKeys &conj_key,CKKSEncoder &encoder) override;
        void eval_mod( Ciphertext &ciph,Ciphertext &result,const EvalModPoly &eva_poly,const RelinKeys &relin_key,CKKSEncoder &encoder) override;
//        void exp_taylor(const Ciphertext &ciph, Ciphertext &result,const RelinKeys &relin_key) override;
//        void exp(const Ciphertext &ciph, Ciphertext &result, complex<double> const_data,const RelinKeys &relin_key, CKKSEncoder enc) override;
        void bootstrap(Ciphertext &ciph,Ciphertext &result,const EvalModPoly &eva_poly,LinearMatrixGroup& matrix_group0,LinearMatrixGroup &matrix_group1,
                               const RelinKeys &relin_key, const GaloisKeys &rot_key,const GaloisKeys &conj_key,CKKSEncoder &encoder) override;
    private:
    protected:
        void ckks_add_plain(Ciphertext &encrypted, Plaintext &plain, Ciphertext &destination) override;
        void ckks_multiply_plain( Ciphertext &ciph,  Plaintext &plain,Ciphertext &result,bool isDirect) override;
        void bfv_bgv_multiply_plain( Ciphertext &encrypted,  Plaintext &plain,Ciphertext &destination) override;

    private:
        void ckks_add(Ciphertext &encrypted1, Ciphertext &encrypted2, Ciphertext &destination);
        void ckks_sub(Ciphertext &encrypted1, Ciphertext &encrypted2, Ciphertext &destination);


        void ckks_multiply_plain(Ciphertext &encrypted, Plaintext &plain, Ciphertext &destination) ;
        void ckks_rescale(Ciphertext &ciph);
        void bfvbgv_rescale(Ciphertext &ciph);


        void recurse_dynamic(const map <int,Ciphertext> &monomialBasis,const RelinKeys &relinKeys ,int targetLevel ,mpf_class targetScale ,
                                           const PolynomialVector &pol, int log_split,int log_degree, Ciphertext &destination,CKKSEncoder &encoder,bool isOdd,bool isEven,int &num,Decryptor &dec);
        void ckks_multiply( Ciphertext &ciph0, Ciphertext &ciph1,Ciphertext &result, const RelinKeys &relin_key);
        void recurse(const map <int,Ciphertext> &monomialBasis,const RelinKeys &relinKeys ,int targetLevel ,mpf_class targetScale ,
                     const PolynomialVector &pol, int log_split,int log_degree, Ciphertext &destination,CKKSEncoder &encoder,bool isOdd,bool isEven,int &num);
        void evaluatePolyFromPolynomialBasis(bool is_even,bool is_odd, const map <int,Ciphertext> &monomialBasis,const RelinKeys &relinKeys ,int targetLevel ,mpf_class targetScale ,
                                             const PolynomialVector &pol, int log_split,int log_degree, Ciphertext &destination,CKKSEncoder &encoder);
        void GenPower(map <int,Ciphertext> &monomialBasis,int n,bool lazy,bool isChev,mpf_class scale,const RelinKeys &relin_key);
        void genPower(map <int,Ciphertext> &monomialBasis,int n,bool lazy,bool isChev,mpf_class scale,const RelinKeys &relin_key);
        //void rescale_dynamic(Ciphertext &ciph,mpf_class scale);
        //void multiply_dynamic( Ciphertext &ciph1, Ciphertext &ciph2,Ciphertext &result, const RelinKeys &relin_key);

        void bfv_bgv_add(Ciphertext &encrypted1, Ciphertext &encrypted2, Ciphertext &destination);
        void bfv_bgv_sub(Ciphertext &encrypted1, Ciphertext &encrypted2, Ciphertext &destination);
        void bfv_bgv_add_plain(Ciphertext &encrypted, Plaintext &plain, Ciphertext &destination);
        void bfv_sub_plain(Ciphertext &encrypted, Plaintext &plain, Ciphertext &destination);
        void bfv_multiply(Ciphertext &encrypted1, Ciphertext &encrypted2, Ciphertext &destination);
        void bgv_multiply(Ciphertext &encrypted1, Ciphertext &encrypted2, Ciphertext &destination);
        int low_modulus(Ciphertext& ciph, int level);

        uint32_t rns_max_;
        uint8_t rns_ud_l_;
        uint8_t rns_ud_h_;
        const RelinKeys *relin_id_ = nullptr;
        const GaloisKeys *conj_id_ = nullptr;
        Hardware_CKKSApi hardware_api_;
        Hardware_BFVBGV_Api hardware_bfv_api_;

        uint32_t poly_length_;
        uint32_t deg_flag_;
        uint32_t degree_;




    };

    class HardwareEnvaluatorFactory : public EvaluatorFactory
    {
    protected:
         auto create_impl(const PoseidonContext &context) -> shared_ptr<Evaluator> override
        {
            return  make_shared<HardwareEvaluator>(context);
        }

        auto create_impl(const PoseidonContext &context,const RelinKeys &relinKeys) -> shared_ptr<Evaluator> override
        {
            return  make_shared<HardwareEvaluator>(context,relinKeys);
        }
    };
} // poseidon

#endif //POSEIDON_HARDWAREEVALUATOR_H
