//
// Created by lxs on 6/6/23.
//

#ifndef POSEIDON_GLOBALS_H
#define POSEIDON_GLOBALS_H
//once_flag haware_init_flag;
namespace poseidon{
    namespace util{
        namespace global_variables {
            constexpr double noise_standard_deviation = 3.2;

            constexpr double noise_distribution_width_multiplier = 6;

            constexpr double noise_max_deviation = noise_standard_deviation * noise_distribution_width_multiplier;
        }
    }

}



#endif //POSEIDON_GLOBALS_H
