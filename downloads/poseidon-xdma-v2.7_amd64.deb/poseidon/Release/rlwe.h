//
// Created by lxs on 6/1/23.
//
#ifndef RLWE_H
#define RLWE_H

#include "PoseidonContext.h"
#include "random/RandomToStandardAdapter.h"
#include "random/ClippedNormalDistribution.h"
#include "SecretKey.h"
#include "PublicKey.h"
#include "Ciphertext.h"
#include "globals.h"
#include "random/random_sample.h"
#include "util/polyarithsmallmod.h"
using namespace std;
namespace poseidon{
    namespace util{
        void sample_poly_ternary( shared_ptr<UniformRandomGenerator> prng, const PoseidonContext &params, RNSPolynomial &poly,bool isExtend = false);
        void sample_poly_ternary_with_hamming( shared_ptr<UniformRandomGenerator> prng, const PoseidonContext &params, RNSPolynomial &poly,bool isExtend = false);
        void sample_poly_normal(shared_ptr<UniformRandomGenerator> prng, const PoseidonContext &params, RNSPolynomial &poly,bool isExtend = false);
        void sample_poly_cbd(shared_ptr<UniformRandomGenerator> prng, const PoseidonContext &params, RNSPolynomial &poly,bool isExtend = false);
        void sample_poly_ternary_trig( shared_ptr<UniformRandomGenerator> prng, const PoseidonContext &params, RNSPolynomial &poly,bool isExtend = false);
        void sample_poly_uniform(shared_ptr<UniformRandomGenerator> prng, const PoseidonContext &params, RNSPolynomial &poly,bool isExtend = false);
        void encrypt_zero_asymmetric(const PublicKey &public_key, const PoseidonContext &context, bool is_ntt_form, Ciphertext &destination,bool isExtend = false);
        void encrypt_zero_symmetric(const SecretKey &secret_key, const PoseidonContext &context, bool is_ntt_form, Ciphertext &destination,bool isExtend = false);
    }
}

#endif