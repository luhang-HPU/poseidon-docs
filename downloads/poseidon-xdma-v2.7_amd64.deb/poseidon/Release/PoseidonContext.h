

#ifndef CKKS_PARAM_H
#define CKKS_PARAM_H

#include "define.h"
#include "CrtContext.h"   
#include <cstdlib>
#include <cmath>
#include "galois.h"
#include "ParametersLiteral.h"
#include "random/UniformRandomGeneratorFactory.h"
#include "globals.h"
#include "util/RNSTool.h"
using namespace std;
namespace poseidon
{


  class PoseidonContext{
    private:
      uint32_t poly_degree_;
      uint32_t hamming_weight_;
      uint32_t plain_modulus_;
      mpf_class scaling_factor_f_;
      SchemeType scheme_type_;

      std::shared_ptr<poseidon::CrtContext> crt_context_{ nullptr };
      std::shared_ptr<UniformRandomGeneratorFactory> random_generator_{nullptr};
      std::shared_ptr<util::GaloisTool> galois_tool_{nullptr};
      std::shared_ptr<util::RNSTool> rns_tool_{nullptr};
      void clear();

    public:

      PoseidonContext(const ParametersLiteral& paramLiteral);
      PoseidonContext(const PoseidonContext& param) = default;
      ~PoseidonContext();
      /**
        Getter methods.
        */
      void set_random_generator(std::shared_ptr<UniformRandomGeneratorFactory> random_generator) noexcept;
      std::shared_ptr<UniformRandomGeneratorFactory> random_generator() const noexcept;

      std::shared_ptr<poseidon::CrtContext> crt_context() const;
      std::shared_ptr<RNSTool> rns_tool() const;
      inline std::shared_ptr<poseidon::util::GaloisTool> galois_tool() const
      {
          return this->galois_tool_;
      }

      const SchemeType scheme_type() const;
      const mpf_class scaling_factor() const;
      const uint32_t hamming_weight() const;
      const uint32_t poly_degree() const;
      const uint32_t plain_modulus() const;
  };

  
}

#endif









