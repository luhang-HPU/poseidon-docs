#ifndef HARDWARE_SRUCTURE_H
#define HARDWARE_SRUCTURE_H
#include <vector>
#include "../define.h"
#include "../MemoryPool.h"

class Poly {
private:
    int degree;
    std::vector<std::vector<uint32_t>> ftts;
    int id;
public:

   // 默认构造函数
    Poly() {
        degree = 0;
        ftts.clear();
    }
    // 带参构造函数
    Poly(int degree, std::vector<std::vector<uint32_t>> ftts) {
        this->degree = degree;
        this->ftts = ftts;
    }
    // 拷贝构造函数
    Poly(const Poly& other) {
        id = other.getid();
        degree = other.degree;
        ftts = other.ftts;
    }
    
    // 获取degree
    int getDegree() const {
        return degree;
    }
    // 设置degree
    void setDegree(int degree) {
        this->degree = degree;
    }

    int getid() const{
        return id;
    }
    void setid(int id) {
       this->id = id;
   }
    // 获取ftts
    std::vector<std::vector<uint32_t>> getFtts() const {
        return ftts;
    }
    // 设置ftts
    void setFtts(std::vector<std::vector<uint32_t>> ftts) {
        this->ftts = ftts;
    }
};
class Ciph {
private:
    Poly c0;
    Poly c1;
    int id;
public:
    // 默认构造函数
    Ciph() {
        c0 = Poly();
        c1 = Poly();
    }
    // 带参构造函数
    Ciph(Poly c0, Poly c1) {
        this->c0 = c0;
        this->c1 = c1;
    }
    // 拷贝构造函数
    Ciph(const Ciph& other) {
        id = other.id;
        c0 = other.c0;
        c1 = other.c1;
    }
    // 赋值运算符
    Ciph& operator=(const Ciph& other) {
        if (this != &other) {
            c0 = other.c0;
            c1 = other.c1;
        }
        return *this;
    }
    // 析构函数
    ~Ciph() {

    }
    // 获取c0
    Poly getC0() const {
        return c0;
    }
    // 设置c0
    void setC0(Poly c0) {
        this->c0 = c0;
    }
    // 获取c1
    Poly getC1() const {
        return c1;
    }
    // 设置c1
    void setC1(Poly c1) {
        this->c1 = c1;
    }
    int getid() {
        return id;
    }
    void setid(int id) {
        this->id = id;
    }
};
#endif 
