//
// Created by lrj on 23-4-21.
//

#ifndef HOST_API_XDMA_H
#define HOST_API_XDMA_H
#include <stdio.h>
#include <cstdlib>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/timeb.h>
#include <byteswap.h>
#include <errno.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <vector>
#include <poll.h>

/* ltoh: little endian to host */
/* htol: host to little endian */
#if __BYTE_ORDER == __LITTLE_ENDIAN
#define ltohl(x)       (x)
#define ltohs(x)       (x)
#define htoll(x)       (x)
#define htols(x)       (x)
#elif __BYTE_ORDER == __BIG_ENDIAN
#define ltohl(x)     __bswap_32(x)
#define ltohs(x)     __bswap_16(x)
#define htoll(x)     __bswap_32(x)
#define htols(x)     __bswap_16(x)
#endif

//#define RNSMAX    0x28
// ADDR


#define MODULUS_CARDADDR_0        0x200002000
#define MODULUS_CARDADDR_1        0x200004000
#define MODULUS_CARDADDR_2        0x200008000
#define MODULUS_CARDADDR_3        0x20000e000
#define MODULUS_CARDADDR_4        0x200010000

#define BARRETT0_CARDADDR_0       0x200006000
#define BARRETT0_CARDADDR_1       0x20000a000

#define BARRETT1_CARDADDR          0x20000c000

#define INTT_PARAM_CARDADDR_0      0x2100000
#define INTT_PARAM_CARDADDR_1      0x82100000

#define RESCALE_PARAM_CARDADDR     0x3300000

#define CONV0_CARDADDR             0x120
#define PARAM0_D0_CARDADDR          0x120
#define PARAM0_D1_CARDADDR          0x1120
#define PARAM0_D2_CARDADDR          0x2120
#define PARAM0_D3_CARDADDR          0x3120
#define PARAM0_D4_CARDADDR          0x4120

#define CONV1_CARDADDR             0x140
#define PARAM1_D0_CARDADDR          0x140
#define PARAM1_D1_CARDADDR          0x1140
#define PARAM1_D2_CARDADDR          0x2140
#define PARAM1_D3_CARDADDR          0x3140
#define PARAM1_D4_CARDADDR          0x4140


#define FUSION_ROU_CARDADDR     0x103400000

#define FUSION_ROU_INV_CARDADDR 0x103900000

#define ROU_CARDADDR            0x101400000

#define ROU_INV_CARDADDR        0x101800000

#define RELINEAR_KEY_CARDADDR   0x101c00000

#define CONJUGATE_KEY_CARDADDR  0x103000000


#define ZERO_ADDR                  0x182000000
#define CONSTANT_0_ADDR                  0x182000000
#define CONSTANT_1_ADDR           0x183400000
#define CONSTANT_4096_ADDR          0x183600000

#define NEG_INV_PROD_Q_MOD_M_TILDE_CARDADDR 0x182200000

#define PROD_Q_MOD_BSK_INV_M_TILDE_MOD_BSK_CARDADDR 0x182400000

#define INV_M_TILDE_MOD_BSK_CARD_ADDR 0x182600000

#define INV_PROD_Q_MOD_BSK_CARD_ADDR 0x182800000

#define INV_PROD_B_MOD_M_SK_CARD_ADDR 0x182a00000

#define NEG_PROD_B_MOD_Q_ELT_CARD_ADDR 0x182c00000

#define COEFF_DIV_PLAIN_MODULUS_CARD_ADDR 0x182e00000

#define QK_HALF_CARD_ADDR 0x183000000
#define QK_INV_CARD_ADDR 0x183200000


#define QK_INV_QP_CARD_ADDR 0x183800000
#define MOD_SWITCH_FACTORS_ADDR 0x183c00000
#define PLAIN_MODS_W32 0x183e00000
#define MOD_QK_ADDR     0x183a00000

#define PARAM_BAR   0x200000000
#define USER_BAR    0x00000000
#define BIAS_ADDR0  0x00000000
#define BIAS_ADDR1  0x00000008
#define BIAS_ADDR2  0x00000010
#define BIAS_ADDR3  0x00000018
#define BIAS_ADDR4  0x0000001C
#define BIAS_ADDR5  0x00000020
#define BIAS_ADDR6  0x00000028
#define BIAS_ADDR7  0x0000002C
#define BIAS_GPIO   0x00000000
#define CLEAN_ENABLE 0x00000001
#define CLEAN_DISABLE 0x00000000


#ifdef __cplusplus
extern "C"
{
#endif

#define USER_DEVICE                 "/dev/xdma0_user"
#define DATA_W_DEVICE               "/dev/xdma0_h2c_0"
#define DATA_W_DEVICE_0               "/dev/xdma0_h2c_0"
#define DATA_W_DEVICE_1               "/dev/qdma5e000-MM-1"
#define DATA_W_DEVICE_2               "/dev/qdma5e000-MM-2"
#define DATA_W_DEVICE_3               "/dev/qdma5e000-MM-3"
#define DATA_W_DEVICE_4               "/dev/qdma5e000-MM-4"
#define DATA_W_DEVICE_5               "/dev/qdma5e000-MM-5"
#define DATA_W_DEVICE_6               "/dev/qdma5e000-MM-6"
#define DATA_W_DEVICE_7               "/dev/qdma5e000-MM-7"
#define DATA_R_DEVICE               "/dev/xdma0_c2h_0"
#define INTR_EVENT0 "/dev/xdma0_events_0"
#define INTR_EVENT1 "/dev/xdma0_events_1"
#define INTR_EVENT2 "/dev/xdma0_events_2"
#define INTR_EVENT3 "/dev/xdma0_events_3"
#define INTR_EVENT4 "/dev/xdma0_events_4"
#define INTR_EVENT5 "/dev/xdma0_events_5"
int reg_rw(const char *device, uint64_t address, char width, uint64_t data, int wr);

//int xdma_h2c(uint64_t host_addr,uint64_t card_addr,uint32_t deg_flag, uint32_t rns_num, int type);
void clean_intr(uint64_t val);
int dma_rw(int device, uint64_t host_addr, char direction, uint64_t card_addr, uint64_t size);
#ifdef __cplusplus
}
#endif

int xdma_h2c_v(const std::vector<std::vector<uint32_t>> &host_data,uint64_t card_addr,uint32_t deg_flag, uint32_t rns_num);
int xdma_c2h_v(std::vector<std::vector<uint32_t>> &host_data, uint64_t card_addr, uint32_t deg_flag, uint32_t rns_num);
int xdma_h2c(std::vector<uint32_t> &host_config_data,uint64_t card_addr,uint32_t deg_flag, uint32_t rns_num, int type);

int xdma_h2c(std::vector<uint64_t> &host_config_data,uint64_t card_addr,uint32_t rns_num);
int xdma_h2c(std::vector<uint32_t> &host_config_data,uint64_t card_addr,uint32_t rns_num);
int xdma_c2h(std::vector<uint32_t> &host_config_data,uint64_t card_addr,uint32_t rns_num);

#define XDMAH2C   0x00
#define XDMAC2H   0x01
#define CKKS_ADD_CIPH  0x00
#define CKKS_ADD_PLAIN 0x01
#define CKKS_SUB_CIPH  0x02
#define CKKS_MULT_CIPH  0x03
#define CKKS_MULT_PLAIN 0x04
#define CKKS_RESCALE   0x05
#define CKKS_ROTATE    0x06
#define CKKS_CONJUGATE 0x07
#define FTT_FWD        0x08
#define FTT_INV        0x09
#define BFV_MULTIPLY_CIPH 0x0A
#define BFV_ADD_CIPH 0x0B
#define BFV_SUB_CIPH 0x0C
#define BFV_ADD_PLAIN 0x0D
#define BFV_SUB_PLAIN 0x0E
#define BFV_MULTIPLY_PLAIN 0x0F
#define BFV_ROTATE 0x10
#define BFV_ROTATE_8192 0x11
#define BFV_RELINEARIZE 0x12
#define BFV_RELINEARIZE_8192 0x13
#define BFV_ROTATE_16384 0x14
#define BFV_ROTATE_32768 0x15
#define BFV_RELINEARIZE_16384 0x16
#define BFV_RELINEARIZE_32768 0x17

#define BGV_ADD_CIPH 0x18
#define BGV_SUB_CIPH 0x19
#define BGV_ADD_PLAIN 0x1A
#define BGV_SUB_PLAIN 0x1B
#define BGV_MULTIPLY_PLAIN 0x1C
#define BGV_MULTIPLY_CIPH 0x1D
#define BGV_RELINEARIZE_8192 0x1E
#define BGV_ROTATE_8192 0x1F
#define BGV_RELINEARIZE_16384 0x20
#define BGV_ROTATE_16384 0x21
#define BGV_RELINEARIZE_32768 0x22
#define BGV_ROTATE_32768 0x23
#define BFV_RESCALE 0x24
#define BGV_RESCALE 0x25

#define NOT_INIT 1











//#define DEBUG_FLAG
#define TIME_COUNT
#ifdef DEBUG_FLAG
#define DEBUG_PRINT(fmt, ...) \
  printf(fmt, ##__VA_ARGS__)
#else
#define DEBUG_PRINT(fmt, ...) \
  do {} while(0)
#endif
#ifdef TIME_COUNT
#define TIME_PRINT(fmt, ...) \
  printf(fmt, ##__VA_ARGS__)
#else
#define DEBUG_PRINT(fmt, ...) \
  do {} while(0)
#endif

#endif //HOST_API_XDMA_H

