//
// Created by lxs on 5/30/23.
//

#ifndef POSEIDON_COMMON_H
#define POSEIDON_COMMON_H
#include "define.h"
#include <vector>
#include <array>
#include <limits>
#include <numeric>
#include <iostream>
namespace poseidon {

    namespace util{
        //data param
        constexpr int bytes_per_uint64 = sizeof(std::uint64_t);
        constexpr int bits_per_nibble = 4;
        constexpr int bits_per_byte = 8;
        // IsNegligibleThreshold : threshold under which a coefficient
// of a polynomial is ignored.
        constexpr double IsNegligibleThreshold  = 1e-14;
        constexpr int bits_per_uint64 = bytes_per_uint64 * bits_per_byte;
        constexpr int nibbles_per_byte = 2;
        constexpr int nibbles_per_uint64 = bytes_per_uint64 * nibbles_per_byte;


//=========== common arithmetic check =====================
        template <typename T, typename = std::enable_if_t<std::is_integral<T>::value>>
        inline constexpr T mul_safe(T in1) noexcept
        {
            return in1;
        }

        template <typename T, typename = std::enable_if_t<std::is_integral<T>::value>>
        inline constexpr T mul_safe(T in1, T in2)
        {
            if constexpr (std::is_unsigned<T>::value)
            {
                if (in1 && (in2 > (std::numeric_limits<T>::max)() / in1))
                {
                    throw std::logic_error("unsigned overflow");
                }
            }
            else
            {
                // Positive inputs
                if ((in1 > 0) && (in2 > 0) && (in2 > (std::numeric_limits<T>::max)() / in1))
                {
                    throw std::logic_error("signed overflow");
                }
                    // Negative inputs
                else if ((in1 < 0) && (in2 < 0) && ((-in2) > (std::numeric_limits<T>::max)() / (-in1)))
                {
                    throw std::logic_error("signed overflow");
                }
                    // Negative in1; positive in2
                else if ((in1 < 0) && (in2 > 0) && (in2 > (std::numeric_limits<T>::max)() / (-in1)))
                {
                    throw std::logic_error("signed underflow");
                }

                    // Positive in1; negative in2
                else if ((in1 > 0) && (in2 < 0) && (in2 < (std::numeric_limits<T>::min)() / in1))
                {
                    throw std::logic_error("signed underflow");
                }
            }
            return static_cast<T>(in1 * in2);
        }

        template <typename T, typename... Args, typename = std::enable_if_t<std::is_integral<T>::value>>
        inline constexpr T mul_safe(T in1, T in2, Args &&... args)
        {
            return mul_safe(mul_safe(in1, in2), mul_safe(std::forward<Args>(args)...));
        }


        template <typename T, typename = std::enable_if_t<std::is_arithmetic<T>::value>>
        inline constexpr T add_safe(T in1) noexcept
        {
            return in1;
        }

        template <typename T, typename = std::enable_if_t<std::is_arithmetic<T>::value>>
        inline constexpr T add_safe(T in1, T in2)
        {
            if constexpr (std::is_unsigned<T>::value)
            {
                if (in2 > (std::numeric_limits<T>::max)() - in1)
                {
                    throw std::logic_error("unsigned overflow");
                }
            }
            else
            {
                if (in1 > 0 && (in2 > (std::numeric_limits<T>::max)() - in1))
                {
                    throw std::logic_error("signed overflow");
                }
                else if (in1 < 0 && (in2 < (std::numeric_limits<T>::min)() - in1))
                {
                    throw std::logic_error("signed underflow");
                }
            }
            return static_cast<T>(in1 + in2);
        }

        template <typename T, typename... Args, typename = std::enable_if_t<std::is_arithmetic<T>::value>>
        inline constexpr T add_safe(T in1, T in2, Args &&... args)
        {
            return add_safe(add_safe(in1, in2), add_safe(std::forward<Args>(args)...));
        }

        template <typename T, typename = std::enable_if_t<std::is_arithmetic<T>::value>>
        inline T sub_safe(T in1, T in2)
        {
            if constexpr (std::is_unsigned<T>::value)
            {
                if (in1 < in2)
                {
                    throw std::logic_error("unsigned underflow");
                }
            }
            else
            {
                if (in1 < 0 && (in2 > (std::numeric_limits<T>::max)() + in1))
                {
                    throw std::logic_error("signed underflow");
                }
                else if (in1 > 0 && (in2 < (std::numeric_limits<T>::min)() + in1))
                {
                    throw std::logic_error("signed overflow");
                }
            }
            return static_cast<T>(in1 - in2);
        }


        template <
                typename T, typename S, typename = std::enable_if_t<std::is_arithmetic<T>::value>,
                typename = std::enable_if_t<std::is_arithmetic<S>::value>>
        inline constexpr bool fits_in(S value [[maybe_unused]]) noexcept
        {
            bool result = false;

            if constexpr (std::is_same<T, S>::value)
            {
                // Same type
                result = true;
            }
            else if constexpr (sizeof(S) <= sizeof(T))
            {
                // Converting to bigger type
                if constexpr(std::is_integral<T>::value && std::is_integral<S>::value)
                {
                    // Converting to at least equally big integer type
                    if constexpr(
                            (std::is_unsigned<T>::value && std::is_unsigned<S>::value) ||
                            (!std::is_unsigned<T>::value && !std::is_unsigned<S>::value))
                    {
                        // Both either signed or unsigned
                        result = true;
                    }
                    else if constexpr(std::is_unsigned<T>::value && std::is_signed<S>::value)
                    {
                        // Converting from signed to at least equally big unsigned type
                        result = value >= 0;
                    }
                }
                else if constexpr(std::is_floating_point<T>::value && std::is_floating_point<S>::value)
                {
                    // Both floating-point
                    result = true;
                }

                // Still need to consider integer-float conversions and all
                // unsigned to signed conversions
            }

            if constexpr(std::is_integral<T>::value && std::is_integral<S>::value)
            {
                // Both integer types
                if (value >= 0)
                {
                    // Non-negative number; compare as std::uint64_t
                    // Cannot use unsigned_leq with C++14 for lack of `if constexpr'
                    result = static_cast<std::uint64_t>(value) <=
                             static_cast<std::uint64_t>((std::numeric_limits<T>::max)());
                }
                else
                {
                    // Negative number; compare as std::int64_t
                    result =
                            static_cast<std::int64_t>(value) >= static_cast<std::int64_t>((std::numeric_limits<T>::min)());
                }
            }
            else if constexpr(std::is_floating_point<T>::value)
            {
                // Converting to floating-point
                result = (static_cast<double>(value) <= static_cast<double>((std::numeric_limits<T>::max)())) &&
                         (static_cast<double>(value) >= -static_cast<double>((std::numeric_limits<T>::max)()));
            }
            else
            {
                // Converting from floating-point
                result = (static_cast<double>(value) <= static_cast<double>((std::numeric_limits<T>::max)())) &&
                         (static_cast<double>(value) >= static_cast<double>((std::numeric_limits<T>::min)()));
            }

            return result;
        }


















        template <
                typename T, typename S, typename = std::enable_if_t<std::is_integral<T>::value>,
                typename = std::enable_if_t<std::is_integral<S>::value>>
        inline constexpr bool unsigned_geq(T in1, S in2) noexcept
        {
            return static_cast<std::uint64_t>(in1) >= static_cast<std::uint64_t>(in2);
        }




        template <
                typename T, typename S, typename = std::enable_if_t<std::is_arithmetic<T>::value>,
                typename = std::enable_if_t<std::is_arithmetic<S>::value>>
        inline T safe_cast(S value)
        {
            if constexpr (!std::is_same<T, S>::value)
            {
                if (!fits_in<T>(value))
                {
                    throw std::logic_error("cast failed");
                }
            }
            return static_cast<T>(value);
        }





        //
        void poseidon_memzero(void *data, size_t size);

//        template <typename T, typename = std::enable_if_t<is_uint32_v<T> || is_uint64_v<T>>>
//        inline T reverse_bits(T operand, int bit_count)
//        {
//#ifdef SEAL_DEBUG
//            if (bit_count < 0 ||
//                static_cast<std::size_t>(bit_count) > mul_safe(sizeof(T), static_cast<std::size_t>(bits_per_byte)))
//            {
//                throw std::invalid_argument("bit_count");
//            }
//#endif
//            // Just return zero if bit_count is zero
//            return (bit_count == 0) ? T(0)
//                                    : reverse_bits(operand) >> (sizeof(T) * static_cast<std::size_t>(bits_per_byte) -
//                                                                static_cast<std::size_t>(bit_count));
//        }
        inline void print_example_banner(std::string title)
        {
            if (!title.empty())
            {
                std::size_t title_length = title.length();
                std::size_t banner_length = title_length + 2 * 10;
                std::string banner_top = "+" + std::string(banner_length - 2, '-') + "+";
                std::string banner_middle = "|" + std::string(9, ' ') + title + std::string(9, ' ') + "|";

                std::cout << std::endl << banner_top << std::endl << banner_middle << std::endl << banner_top << std::endl;
            }
        }
        inline constexpr int hamming_weight(unsigned char value)
        {
            int t = static_cast<int>(value);
            t -= (t >> 1) & 0x55;
            t = (t & 0x33) + ((t >> 2) & 0x33);
            return (t + (t >> 4)) & 0x0F;
        }


        template <typename... Ts>
        struct VoidType
        {
            using type = void;
        };

        template <typename... Ts>
        using poseidon_void_t = typename VoidType<Ts...>::type;

        template <typename ForwardIt, typename Size, typename Func>
        inline ForwardIt poseidon_for_each_n(ForwardIt first, Size size, Func &&func)
        {
            for (; size--; (void)++first)
            {
                func(*first);
            }
            return first;
        }

        template <typename T, typename...>
        struct IsUInt64
                : std::conditional<
                        std::is_integral<T>::value && std::is_unsigned<T>::value && (sizeof(T) == sizeof(std::uint64_t)),
                        std::true_type, std::false_type>::type
        {};

        template <typename T, typename U, typename... Rest>
        struct IsUInt64<T, U, Rest...>
                : std::conditional<IsUInt64<T>::value && IsUInt64<U, Rest...>::value, std::true_type, std::false_type>::type
        {};

        template <typename T, typename... Rest>
        constexpr bool is_uint64_v = IsUInt64<T, Rest...>::value;

        template <typename T, typename...>
        struct IsUInt32
                : std::conditional<
                        std::is_integral<T>::value && std::is_unsigned<T>::value && (sizeof(T) == sizeof(std::uint32_t)),
                        std::true_type, std::false_type>::type
        {};

        template <typename T, typename U, typename... Rest>
        struct IsUInt32<T, U, Rest...>
                : std::conditional<IsUInt32<T>::value && IsUInt32<U, Rest...>::value, std::true_type, std::false_type>::type
        {};

        template <typename T, typename... Rest>
        constexpr bool is_uint32_v = IsUInt32<T, Rest...>::value;



        template <typename T, typename = std::enable_if_t<is_uint32_v<T> || is_uint64_v<T>>>
        inline constexpr T reverse_bits(T operand) noexcept
        {
            if constexpr(is_uint32_v<T>)
            {
                operand = (((operand & T(0xaaaaaaaa)) >> 1) | ((operand & T(0x55555555)) << 1));
                operand = (((operand & T(0xcccccccc)) >> 2) | ((operand & T(0x33333333)) << 2));
                operand = (((operand & T(0xf0f0f0f0)) >> 4) | ((operand & T(0x0f0f0f0f)) << 4));
                operand = (((operand & T(0xff00ff00)) >> 8) | ((operand & T(0x00ff00ff)) << 8));
                return static_cast<T>(operand >> 16) | static_cast<T>(operand << 16);
            }
            else if constexpr(is_uint64_v<T>)
            {

                return static_cast<T>(reverse_bits(static_cast<std::uint32_t>(operand >> 32))) |
                       (static_cast<T>(reverse_bits(static_cast<std::uint32_t>(operand & T(0xFFFFFFFF)))) << 32);

            }
        }

        template <typename T, typename = std::enable_if_t<is_uint32_v<T> || is_uint64_v<T>>>
        inline T reverse_bits(T operand, int bit_count)
        {

            // Just return zero if bit_count is zero
            return (bit_count == 0) ? T(0)
                                    : reverse_bits(operand) >> (sizeof(T) * static_cast<std::size_t>(bits_per_byte) -
                                                                static_cast<std::size_t>(bit_count));
        }

    }

} // poseidon

#endif //POSEIDON_COMMON_H
