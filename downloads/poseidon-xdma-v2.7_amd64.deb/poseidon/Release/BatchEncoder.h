//
// Created by lxs on 23-6-25.
//

#ifndef POSEIDON_BATCHENCODER_H
#define POSEIDON_BATCHENCODER_H
#include "CrtContext.h"
#include "PoseidonContext.h"
#include "Plaintext.h"
namespace poseidon {

    class BatchEncoder {
    public:
        BatchEncoder(const PoseidonContext &context);
        void encode(const vector<uint32_t> &vec ,Plaintext &plain);
        void encode(const vector<uint32_t> &vec , Plaintext &plain,int level);

        void decode(const Plaintext &plain,vector<uint32_t> &vec);
    private:
        SchemeType scheme_type_;
        vector<uint32_t> matrix_reps_index_map_;
        std::shared_ptr<poseidon::CrtContext> crt_context_{ nullptr };
        int encode_rns_inter(const vector<uint32_t> &vec, vector<uint32_t> &result);
        int decode_rns_inter(const vector<uint32_t> &vec, vector<uint32_t> &result);
        void populate_matrix_reps_index_map();


    };

} // poseidon

#endif //POSEIDON_BATCHENCODER_H
