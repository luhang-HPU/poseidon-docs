//
// Created by lxs on 5/19/23.
//

#ifndef POSEIDON_PARAMETERSLITERAL_H
#define POSEIDON_PARAMETERSLITERAL_H
#include <iostream>
#include <vector>
#include "define.h"

using namespace std;

namespace poseidon {



    class ParametersLiteral {
    public:
        SchemeType Type;
        DegreeType degreeType;
        uint32_t LogN;                                                 // Log2 of the ringdegree
        uint32_t LogSlots;                                             // Log2 of the number of slots
        vector<uint32_t> LogQ;                                        // Log2 of the ciphertext prime moduli
        vector<uint32_t> LogP;                                        // Log2 of the key-switch auxiliary prime moduli
        vector<uint32_t> Q;
        vector<uint32_t> P;
        uint32_t LogScale;                                             // Log2 of the scale
        uint32_t H;
        uint32_t T;
        uint32_t q0_level;
        ParametersLiteral();
        ParametersLiteral(SchemeType Type, uint32_t LogN, uint32_t LogSlots, const vector<uint32_t>& LogQ, const vector<uint32_t>& LogP, uint32_t LogScale, uint32_t H,uint32_t T = 0,int q0_level = 0);
    private:
        SchemeType scheme_;
        std::size_t poly_modulus_degree_ = 0;



        void compute_params_id();
        bool is_valid_scheme(SchemeType schemeType) const noexcept;


    };



    class CKKSParametersLiteralDefault : public ParametersLiteral{
        private:
            int init(DegreeType degreeType);
        public:
            CKKSParametersLiteralDefault(DegreeType degreeType);
    };

    class BFVParametersLiteralDefault : public ParametersLiteral{
    private:
        int init(DegreeType degreeType);
    public:
        BFVParametersLiteralDefault(DegreeType degreeType);
    };

    class BGVParametersLiteralDefault : public ParametersLiteral{
    private:
        int init(DegreeType degreeType);
    public:
        BGVParametersLiteralDefault(DegreeType degreeType);
    };



}

//
//
//namespace std{
//    template <>
//    struct hash<poseidon::parms_id_type>{
//        std::size_t operator()(const poseidon::parms_id_type &params_id) const{
//            std::uint64_t result = 17;
//            result = 31 * result + params_id[0];
//            result = 31 * result + params_id[1];
//            result = 31 * result + params_id[2];
//            result = 31 * result + params_id[3];
//            return static_cast<std::size_t>(result);
//        }
//    };
//
//
//    template <>
//    struct hash<poseidon::ParametersLiteral>{
//        std::size_t operator()(const poseidon::ParametersLiteral &params) const{
//            hash<poseidon::parms_id_type> param_id_hash;
//            //return param_id_hash(params.  )
//        }
//    };
//
//}

#endif //POSEIDON_PARAMETERSLITERAL_H




