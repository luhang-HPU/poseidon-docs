//
// Created by lxs on 6/8/23.
//

#ifndef POSEIDON_GALOISKEYS_H
#define POSEIDON_GALOISKEYS_H
#include "define.h"
#include "KeySwitchKey.h"
namespace poseidon {

    class GaloisKeys : public KeySwitchKey
    {
    public:

        static inline  std::size_t get_index(std::uint32_t galois_elt)
        {
            return GetIndexFromElt(galois_elt);
        }

        inline bool has_key(std::uint32_t galois_elt) const
        {
            std::size_t index = get_index(galois_elt);
            //return data().size() > index && data().at(index).data().isValid();
            return data().size() > index && !data().at(index).empty();
        }
    private:
        static inline std::size_t GetIndexFromElt(std::uint32_t galois_elt){
            //galois_elt rang [1, 2N-1] && is odd  -> result rang [0,N-1]
            return (std::size_t)((galois_elt - 1) >> 1);
        }
    };

} // poseidon

#endif //POSEIDON_GALOISKEYS_H
