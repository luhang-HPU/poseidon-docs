//
// Created by lxs on 5/25/23.
//

#ifndef POSEIDON_METADATA_H
#define POSEIDON_METADATA_H
#include <gmpxx.h>
#include "MemoryPool.h"
namespace poseidon{
    class MetaData {
    private:
        mpf_class scaling_factor_;
        uint32_t correction_factor_ = 1;
        int32_t level_;
        uint32_t poly_degree_;
        bool isNTT_;
        uint64_t id_;
    public:
        MetaData(const mpf_class &scaling_factor,bool isNTT,int level,int poly_degree);
        MetaData(const MetaData& metaData) = default;
        MetaData &operator=(const MetaData &assign) = default;


        void setId(uint64_t id);
        uint64_t getId() const;
        void setNTT(bool isTrue);
        bool isNTT() const;
        void setScalingFactor(const mpf_class &scaling_factor);
        const mpf_class getScalingFactor() const;
        void setCorrectionFactor(uint32_t correction_factor);
        const uint32_t getCorrectionFactor() const;

        void setLevel(int level);
        const int32_t getLevel() const;
        void setDegree(int degree);
        const uint32_t getDegree() const;

    };
}



#endif //POSEIDON_METADATA_H
