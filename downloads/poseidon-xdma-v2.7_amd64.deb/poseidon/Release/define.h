
#ifndef DEFINE_H
#define DEFINE_H

#include <stdio.h>
#include <complex>
#include <complex>
#include <iostream>
#include <memory>
#include <vector>

#define BANNER                                              \
 "                     __ \n"     \
 "        __          /  \\\n"     \
 "       /  \\_______  \\__/        \n"     \
 "       \\__/      /   /   /   \n"     \
 "        _____   /   /   /\n"     \
 "               /   /   /    \n"     \
 "              /   /   /\n"  \
 "             /   /   /  \n"      \
 "            /   /   /         __\n" \
 "   __  ____/   /   /_________/  \\ \n"     \
 "  /  \\________/  ___________ \\__/\n"  \
 "  \\__/     \n"                                     \
 "             \n\n"

#define VERSION 2.6

#ifdef POSEIDON_USE_STD_BYTE
#include <cstddef>
namespace poseidon
{
    using poseidon_byte = std::byte;
} // namespace seal
#else
namespace poseidon
{
    enum class poseidon_byte : unsigned char
    {
    };
} // namespace seal
#endif

// Join
#define _POSEIDON_JOIN(M, N) M##N
#define POSEIDON_JOIN(M, N) _POSEIDON_JOIN(M, N)
// Detect system
#define POSEIDON_SYSTEM_OTHER 1
#define POSEIDON_SYSTEM_WINDOWS 2
#define POSEIDON_SYSTEM_UNIX_LIKE 3

#if defined(_WIN32)
#define POSEIDON_SYSTEM POSEIDON_SYSTEM_WINDOWS
#elif defined(__linux__) || defined(__FreeBSD__) || defined(EMSCRIPTEN) || (defined(__APPLE__) && defined(__MACH__))
#define POSEIDON_SYSTEM POSEIDON_SYSTEM_UNIX_LIKE
#else
#define POSEIDON_SYSTEM POSEIDON_SYSTEM_OTHER
#error "Unsupported system"
#endif


// Which random number generator to use by default
#define POSEIDON_DEFAULT_PRNG_FACTORY Blake2xbPRNGFactory

// C++14 does not have std::for_each_n so we use a custom implementation
#ifndef POSEIDON_USE_STD_FOR_EACH_N
#define POSEIDON_ITERATE poseidon::util::poseidon_for_each_n
#else
#define POSEIDON_ITERATE std::for_each_n
#endif

// Which distribution to use for noise sampling: rounded Gaussian or Centered Binomial Distribution
#ifdef POSEIDON_USE_GAUSSIAN_NOISE
#define POSEIDON_NOISE_SAMPLER sample_poly_normal
#else
#define POSEIDON_NOISE_SAMPLER sample_poly_cbd //sample_poly_ternary_trig//
//sample_poly_ternary_with_hamming
#endif

//#define DEGREE       	    2048
#define MAX_RNS_NUM       	20

#ifndef DEGREE_TYPE
#define DEGREE_TYPE
enum SchemeType{
    CKKS,
    BFV,
    BGV
};

enum DegreeType {
    degree_16,
    degree_1024,
    degree_2048,
    degree_4096,
    degree_8192,
    degree_16384,
    degree_32768,
    degree_65535
};
#endif

//Memory HBM

//#define HBM_SIZE            1
//#define SIZE_PER_HBM        134217728/32
//#define FIRST_HBM_ADDR      0x14000000
//#define SECOND_HBM_ADDR     0x114000000



#endif