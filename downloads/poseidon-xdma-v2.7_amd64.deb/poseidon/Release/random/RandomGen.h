//
// Created by lxs on 5/30/23.
//

#ifndef POSEIDON_RANDOMGEN_H
#define POSEIDON_RANDOMGEN_H
#include "../define.h"
#include "../common.h"
#include <random>
#include <string.h>
#include <algorithm>
using  namespace std;
namespace poseidon {
    constexpr std::size_t prng_seed_uint64_count = 8;

    constexpr std::size_t prng_seed_byte_count = prng_seed_uint64_count * util::bytes_per_uint64;

    using prng_seed_type = std::array<std::uint64_t, prng_seed_uint64_count>;

    /**
    A type indicating a specific pseud-random number generator.
    */
    enum class prng_type : std::uint8_t
    {
        unknown = 0,

        blake2xb = 1,

        shake256 = 2
    };

    void random_bytes(poseidon_byte *buf, size_t count);
    inline std::uint64_t random_uint64(){
        std::uint64_t result;
        random_bytes(reinterpret_cast<poseidon_byte *>(&result),sizeof(result));;
        return result;
    }

    class UniformRandomGenerator;


    class UniformRandomGeneratorInfo {
        friend class UniformRandomGenerator;
    public:
        /**
        Creates a new UniformRandomGeneratorInfo.
        */
        UniformRandomGeneratorInfo() = default;
        /**
        Creates a new UniformRandomGeneratorInfo.

        @param[in] type The PRNG type
        @param[in] seed The PRNG seed
        */
        UniformRandomGeneratorInfo(prng_type type, prng_seed_type seed) : type_(type), seed_(std::move(seed))
        {}
        /**
        Creates a new UniformRandomGeneratorInfo.
        @param[in] copy The UniformRandomGeneratorInfo to copy from
        */
        UniformRandomGeneratorInfo(const UniformRandomGeneratorInfo &copy) = default;

        /**
        Copies a given UniformRandomGeneratorInfo to the current one.

        @param[in] assign The UniformRandomGeneratorInfo to copy from
        */
        UniformRandomGeneratorInfo &operator=(const UniformRandomGeneratorInfo &assign) = default;

        /**
       Compares two UniformRandomGeneratorInfo instances.

       @param[in] compare The UniformRandomGeneratorInfo to compare against
       */
        inline bool operator==(const UniformRandomGeneratorInfo &compare) const noexcept
        {
            return (seed_ == compare.seed_) && (type_ == compare.type_);
        }

        /**
        Compares two UniformRandomGeneratorInfo instances.

        @param[in] compare The UniformRandomGeneratorInfo to compare against
        */
        inline bool operator!=(const UniformRandomGeneratorInfo &compare) const noexcept
        {
            return !operator==(compare);
        }

        /**
        Clears all data in the UniformRandomGeneratorInfo.
        */
        void clear() noexcept
        {
            type_ = prng_type::unknown;
            util::poseidon_memzero(seed_.data(), prng_seed_byte_count);
        }
        /**
        Destroys the UniformRandomGeneratorInfo.
        */
        ~UniformRandomGeneratorInfo()
        {
            clear();
        }
        std::shared_ptr<UniformRandomGenerator> make_prng() const;

        /**
        Returns whether this object holds a valid PRNG type.
        */
        inline bool has_valid_prng_type() const noexcept
        {
            switch (type_)
            {
                case prng_type::blake2xb:
                    /* fall through */

                case prng_type::shake256:
                    /* fall through */

                case prng_type::unknown:
                    return true;
            }
            return false;
        }
        /**
        Returns the PRNG type.
        */
        inline prng_type &type() noexcept
        {
            return type_;
        }
        /**
        Returns the PRNG type.
        */
        inline prng_type type() const noexcept
        {
            return type_;
        }



        /**
        Returns a reference to the PRNG seed.
        */
        inline const prng_seed_type &seed() const noexcept
        {
            return seed_;
        }

        /**
        Returns a reference to the PRNG seed.
        */
        inline prng_seed_type &seed() noexcept
        {
            return seed_;
        }
    public:
        //void save_members(std::ostream &stream) const;

        //void load_members(std::istream &stream);

        prng_type type_ = prng_type::unknown;

        prng_seed_type seed_ = {};
    };


} // poseidon

#endif //POSEIDON_RANDOMGEN_H
