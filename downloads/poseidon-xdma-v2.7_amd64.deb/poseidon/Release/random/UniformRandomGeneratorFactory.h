//
// Created by lxs on 6/1/23.
//

#ifndef POSEIDON_UNIFORMRANDOMGENERATORFACTORY_H
#define POSEIDON_UNIFORMRANDOMGENERATORFACTORY_H
#include "RandomGen.h"
#include "UniformRandomGenerator.h"
//#include "Blake2xbPRNG.h"
namespace poseidon {

    class UniformRandomGeneratorFactory {
    private:
        bool use_random_seed_ = false;
        prng_seed_type default_seed_ = {};
    public:
        UniformRandomGeneratorFactory();
        UniformRandomGeneratorFactory(prng_seed_type default_seed);
        /**
        Destroys the random number generator factory.
        */
        virtual ~UniformRandomGeneratorFactory() = default;
        /**
        Returns the default random number generator factory. This instance should
        not be destroyed.
        */
        static auto DefaultFactory() -> std::shared_ptr<UniformRandomGeneratorFactory>;

        auto create() -> std::shared_ptr<UniformRandomGenerator>;
        /**
       Creates a new uniform random number generator seeded with the given seed,
       overriding the default seed for this factory instance.

       @param[in] seed The seed to be used for the created random number generator
       */
        auto create(prng_seed_type seed) -> std::shared_ptr<UniformRandomGenerator>;
        /**
        Returns whether the random number generator factory creates random number
        generators seeded with a random seed, or if a default seed is used.
        */
        inline bool use_random_seed() noexcept
        {
            return use_random_seed_;
        }

        /**
        Returns the default seed used to seed every random number generator created
        by this random number generator factory. If use_random_seed() is false, then
        the returned seed has no meaning.
        */
        inline prng_seed_type default_seed() noexcept
        {
            return default_seed_;
        }

    protected:
        virtual auto create_impl(prng_seed_type seed) -> std::shared_ptr<UniformRandomGenerator> = 0;

    };

} // poseidon

#endif //POSEIDON_UNIFORMRANDOMGENERATORFACTORY_H
