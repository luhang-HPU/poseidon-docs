//
// Created by lxs on 6/1/23.
//

#ifndef POSEIDON_UNIFORMRANDOMGENERATOR_H
#define POSEIDON_UNIFORMRANDOMGENERATOR_H
#include "RandomGen.h"
namespace poseidon {

    class UniformRandomGenerator {
    public:
        /**
        Creates a new UniformRandomGenerator instance initialized with the given seed.

        @param[in] seed The seed for the random number generator
        */
        UniformRandomGenerator(prng_seed_type seed)
                : seed_([&seed]() {
            vector<uint64_t> new_seed(seed.size());
            std::copy(seed.cbegin(), seed.cend(), new_seed.begin());
            return new_seed;
        }()),
        buffer_(buffer_size_ ),
        buffer_begin_(&(*buffer_.begin())), buffer_end_(&(*buffer_.end())), buffer_head_(&(*buffer_.end()))
        {
            //refresh();
        }


        inline prng_seed_type seed() const noexcept
        {
            prng_seed_type ret{};
            std::copy(seed_.cbegin(), seed_.cend(), ret.begin());
            return ret;
        }

        /**
        Fills a given buffer with a given number of bytes of randomness.
        */
        void generate(std::size_t byte_count, poseidon_byte *destination);

        /**
        Generates a new unsigned 32-bit random number.
        */
        inline std::uint32_t generate()
        {
            std::uint32_t result;
            generate(sizeof(result), reinterpret_cast<poseidon_byte *>(&result));
            return result;
        }

        /**
        Discards the contents of the current randomness buffer and refills it
        with fresh randomness.
        */
        inline void refresh()
        {
            //std::lock_guard<std::mutex> lock(mutex_);
            refill_buffer();
            //buffer_head_ = buffer_begin_;
        }

        /**
        Returns a UniformRandomGeneratorInfo object representing this PRNG.
        */
        inline UniformRandomGeneratorInfo info() const noexcept
        {
            UniformRandomGeneratorInfo result;
            std::copy_n(seed_.cbegin(), prng_seed_uint64_count, result.seed_.begin());
            result.type_ = type();
            return result;
        }

        /**
        Destroys the random number generator.
        */
        virtual ~UniformRandomGenerator() = default;

    protected:
        virtual prng_type type() const noexcept = 0;
        virtual void refill_buffer() = 0;

        const vector<uint64_t> seed_;
        const std::size_t buffer_size_ = 4096;

    private:
        vector<poseidon_byte> buffer_;
        //std::mutex mutex_;

    protected:
        poseidon_byte *const buffer_begin_;

        poseidon_byte *const buffer_end_;

        poseidon_byte *buffer_head_;

    };



} // poseidon

#endif //POSEIDON_UNIFORMRANDOMGENERATOR_H
