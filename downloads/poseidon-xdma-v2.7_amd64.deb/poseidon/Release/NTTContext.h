#ifndef NTT_CONTEXT_H
#define NTT_CONTEXT_H

#include "define.h"
#include "util/number_theory.h"
#include "util/bit_operations.h"
namespace poseidon
{
  class NTTContext
  {
    private:
      uint32_t coeff_modulus_;
      uint32_t degree_;
      uint32_t root_of_unity_src_;
      uint32_t intt_conv_;
      std::vector <uint32_t> roots_of_unity_;
      std::vector <uint32_t> roots_of_unity_inv_;
      std::vector <uint32_t> reversed_bits_;
 

    public:
      NTTContext(uint32_t coeff_modulus,uint32_t poly_degree,uint32_t root_of_unity);
      NTTContext(uint32_t coeff_modulus,uint32_t poly_degree);
      void precompute_ntt(uint32_t root_of_unity);
      int ntt(int *coeffs,const std::vector <uint32_t> &roots_of_unity,std::vector <long long> &result);
      int ntt(const std::vector <int> &coeffs,const std::vector <uint32_t> &roots_of_unity,std::vector <long long> &result);
      int ntt(const std::vector <uint32_t> &coeffs,const std::vector <uint32_t> &roots_of_unity,std::vector <uint32_t> &result,bool bit_reserve=true);
      int intt(const std::vector <uint32_t> &coeffs,const std::vector <uint32_t> &roots_of_unity,std::vector <uint32_t> &result,bool bit_reserve=true);
      int ftt_fwd(const std::vector <uint32_t> &coeffs,std::vector <uint32_t> &result,bool bit_reserve=true);
      int ftt_inv(const std::vector <uint32_t> &coeffs,std::vector <uint32_t> &result,bool bit_reserve=true);
      int reverse(int *result, int len);
      std::vector <uint32_t> roots_of_unity();
      std::vector <uint32_t> roots_of_unity_inv();
      std::vector <uint32_t> reversed_bits();
      uint32_t degree();
      uint32_t coeff_modulus();

      inline uint32_t intt_conv(){
          return intt_conv_;
      }
    
  };
  

}


#endif