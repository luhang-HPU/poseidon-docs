//
// Created by lxs on 6/5/23.
//

#ifndef POSEIDON_CIPHERTEXT_H
#define POSEIDON_CIPHERTEXT_H
#include "rns_polynomial.h"
#include "MetaData.h"
namespace poseidon {

    class Ciphertext {
    public:
        /**
        Creates an empty public key.
        */
        Ciphertext();
        Ciphertext(const Ciphertext &copy);
        Ciphertext(Ciphertext &&source) = default;
        ~Ciphertext();
        /**
        Copies an old PublicKey to the current one.

        @param[in] assign The PublicKey to copy from
        */
        Ciphertext &operator=(const Ciphertext &assign);
        /**
       Moves an old PublicKey to the current one.

       @param[in] assign The PublicKey to move from
       */
        Ciphertext &operator=(Ciphertext &&assign);
        void newPoly(const PoseidonContext& context,uint32_t rns_num_q,uint32_t rns_num_p);
        void newPoly(shared_ptr<CrtContext> crtContext,uint32_t rns_num_q,uint32_t rns_num_p);
        void newMetaData(const mpf_class &scaling_factor,bool isNTT,uint32_t level,uint32_t poly_degree);
        void newMetaData(const MetaData& metaData);
        bool isValid() const;
        RNSPolynomial* c0() const;
        RNSPolynomial* c1() const;
        MetaData* metaData() const;
    private:
        RNSPolynomial* c0_ = nullptr;
        RNSPolynomial* c1_ = nullptr;
        MetaData* metaData_ = nullptr;

    private:
        int id_c0;
        int id_c1;
    public:
        void compute_id();
        const int get_id_c0() const;
        void set_id_c0(int id);
        const int get_id_c1() const;
        void set_id_c1(int id);
    };



    class Ciphertext_RLWE {
    public:
        /**
        Creates an empty public key.
        */
        Ciphertext_RLWE() = default;
        Ciphertext_RLWE(const Ciphertext_RLWE &copy) = default;
        Ciphertext_RLWE(Ciphertext_RLWE &&source) = default;
        ~Ciphertext_RLWE() = default;
        /**
        Copies an old PublicKey to the current one.

        @param[in] assign The PublicKey to copy from
        */
        Ciphertext_RLWE &operator=(const Ciphertext_RLWE &assign) = default;
        /**
       Moves an old PublicKey to the current one.

       @param[in] assign The PublicKey to move from
       */
        Ciphertext_RLWE &operator=(Ciphertext_RLWE &&assign) = default;

        inline bool isValid() const{
            if(a_.empty() == false && b_.empty() == false){
                return true;
            }
            return false;
        }

        inline vector<uint32_t > &a(){
            return a_;
        }

        inline const vector<uint32_t > &a() const{
            return a_;
        }

        inline vector<vector<uint32_t >> &b(){
            return b_;
        }
        inline const vector<vector<uint32_t >> &b() const{
            return b_;
        }

        inline vector<uint32_t > &modulus(){
            return modulus_;
        }

        inline const vector<uint32_t > &modulus() const{
            return modulus_;
        }

        inline size_t &degree(){
            return degree_;
        }

        inline const size_t &degree() const{
            return degree_;
        }

        inline void resize(size_t size){
            a_.resize(size);
            b_.resize(size);
            if(!degree_){
                throw invalid_argument("no degree");
            }
            for(int i = 0; i < size; i++){
                b_[i].resize(degree_);
            }
            modulus_.resize(size);
        }

    private:
        vector<uint32_t > a_{};
        vector<vector<uint32_t >> b_{};
        vector<uint32_t > modulus_{};
        size_t degree_ = 0;
    };

} // poseidon

#endif //POSEIDON_CIPHERTEXT_H
