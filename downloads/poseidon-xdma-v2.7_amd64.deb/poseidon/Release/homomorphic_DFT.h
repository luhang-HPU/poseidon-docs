//
// Created by lxs on 23-6-15.
//

#ifndef POSEIDON_HOMOMORPHIC_DFT_H
#define POSEIDON_HOMOMORPHIC_DFT_H
#include "define.h"
#include <complex>
#include <iostream>
#include <memory>
#include <vector>
#include <map>
#include <cmath>
#include "linear_transform.h"
#include "CKKSEncoder.h"
using namespace std;
namespace poseidon {
    typedef int DFTType;
    const DFTType Encode = 0;
    const DFTType Decode = 1;
    vector<complex<double> > GetRootsFloat64(int NthRoot);
    tuple<vector<vector<complex<double> > >, vector<vector<complex<double> > >, vector<std::vector<complex<double> > > > ifftPlainVec(int logN, int dslots, vector<complex<double> > roots, vector<int> pow5);
    tuple<vector<vector<complex<double> > >, vector<vector<complex<double> > >, vector<std::vector<complex<double> > > > fftPlainVec(int logN, int dslots, vector<complex<double> > roots, vector<int> pow5);
    void sliceBitReverseInPlace(std::vector<std::complex<double> >& slice, int N);
    void addToDiagMatrix(std::map<int, std::vector<std::complex<double> > >& diagMat, int index, std::vector<std::complex<double> > vec);
    std::vector<std::complex<double> > add(const std::vector<std::complex<double> >& a, const std::vector<std::complex<double> >& b);
    std::vector<std::complex<double> > mul(const std::vector<std::complex<double> >& a, const std::vector<std::complex<double> >& b);
    std::vector<std::complex<double> > rotate(const std::vector<std::complex<double> >& x, int n);
    std::map<int, std::vector<std::complex<double> > > genFFTDiagMatrix(int logL, int fftLevel, std::vector<std::complex<double> > a, std::vector<std::complex<double> > b, std::vector<std::complex<double> > c, DFTType ltType, bool bitreversed);
    std::map<int, std::vector<std::complex<double> > > multiplyFFTMatrixWithNextFFTLevel(std::map<int, std::vector<std::complex<double> > > vec, int logL, int N, int nextLevel, std::vector<std::complex<double> > a, std::vector<std::complex<double> > b, std::vector<std::complex<double> > c, DFTType ltType, bool bitreversed);
    map<int, vector<complex<double> > > genRepackMatrix(int logL, bool bitreversed);

    class HomomorphicDFTMatrixLiteral {
    private:
            // Member variables
        DFTType type_;
        uint32_t logN_;
        uint32_t logSlots_;
        uint32_t levelStart_;
        std::vector<uint32_t> levels_;
        bool repackImag2Real_;
        double scaling_;
        bool bitReversed_;
        uint32_t logBSGSRatio_;
        uint32_t Depth(bool actual);

    public:
        DFTType getType() const;
        uint32_t getLogN() const;
        uint32_t getLogSlots() const;
        uint32_t getLevelStart() const ;
        const vector<uint32_t> &getLevels() const ;
        bool getRepackImag2Real() const ;
        double getScaling() const ;
        bool getBitReversed() const ;
        uint32_t getLogBSGSRatio() const ;
        vector<map<int, vector<complex<double> > > > GenMatrices();
        void create(LinearMatrixGroup &mat_group,  CKKSEncoder &encoder,uint32_t step);

        HomomorphicDFTMatrixLiteral(DFTType type, uint32_t logN, uint32_t logSlots,
                                    uint32_t levelStart, vector<uint32_t> levels,
        bool repackImag2Real = false,
        double scaling = 1.0,
        bool bitReversed = false,
        uint32_t logBSGSRatio = 0);
    };



} // poseidon

#endif //POSEIDON_HOMOMORPHIC_DFT_H
