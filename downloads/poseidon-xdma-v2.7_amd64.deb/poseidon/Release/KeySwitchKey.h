//
// Created by lxs on 6/8/23.
//

#ifndef POSEIDON_KEYSWITCHKEY_H
#define POSEIDON_KEYSWITCHKEY_H
#include "define.h"
#include "PublicKey.h"
namespace poseidon {

    class KeySwitchKey {
        friend class KeyGenerator;
    public:
        KeySwitchKey() = default;
        KeySwitchKey(const KeySwitchKey &copy) = default;
        KeySwitchKey(KeySwitchKey &&source) = default;
        KeySwitchKey &operator = (const KeySwitchKey &assign);
        KeySwitchKey &operator = (KeySwitchKey &&assign) = default;

        inline std::size_t size() const noexcept
        {
//            return std::accumulate(keys_.cbegin(), keys_.cend(), std::size_t(0), [](std::size_t res, auto &next_key) {
//                return res + (next_key.empty() ? 0 : 1);
//            });
            return keys_.size();
        }

        inline std::vector<std::vector<PublicKey>> &data() noexcept
        {
            return keys_;
        }

        inline const std::vector<std::vector<PublicKey>> &data() const noexcept
        {
            return keys_;
        }

        auto &data(std::size_t index);


        const auto &data(std::size_t index) const;
    private:
        std::vector<std::vector<PublicKey>> keys_{};

    };

} // poseidon

#endif //POSEIDON_KEYSWITCHKEY_H
