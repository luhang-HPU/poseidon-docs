//
// Created by lxs on 23-9-25.
//

#ifndef POSEIDON_GIOBALS_H
#define POSEIDON_GIOBALS_H
#include "soft_memorypool.h"
using namespace std;
namespace poseidon {

    namespace util{
        namespace global_variables{
            extern std::shared_ptr<S_MemoryPool> const global_memory_pool;
#ifndef _M_CEE
            extern thread_local std::shared_ptr<S_MemoryPool> const tls_memory_pool;
#endif
        }
    }

} // poseidon

#endif //POSEIDON_GIOBALS_H
