#ifndef NUMBER_THEORY_H
#define NUMBER_THEORY_H

# include <cmath>
# include "../define.h"
# include <gmpxx.h>
#include "../common.h"
#include <iostream>
#include <type_traits>
#include "../modulus.h"

using namespace poseidon::util;
using namespace std;

namespace Util {
    bool is_prime(uint64_t num, int num_trials);
    //bool is_prime(const poseidon::Modulus &modulus, size_t num_rounds = 40);
    std::uint64_t gcd(std::uint64_t x, std::uint64_t y);
    inline bool are_coprime(std::uint64_t x, std::uint64_t y) noexcept
    {
        return !(Util::gcd(x, y) > 1);
    }



    long long qpow(long long x, long long y, long long p);

    long long mod_inv(long long val, long long modulus);

    long long find_generator(long long modulus);

    long long root_of_unity(long long order, long long modulus);

    long long qmult(long long a, long long b, long long p);

    long long fmod(long long data_in, long long modulus);

    int mod_inv(std::vector<uint32_t> modulus_q, std::vector<uint32_t> &mod_inv_result);

    int mod_inv_q(std::vector<uint32_t> modulus_q, int rns_num, std::vector<uint32_t> &mod_inv_result);

    int conv_x_to_rns(std::vector<uint32_t> modulus, mpz_t *x, int x_num, std::vector<std::vector<uint32_t>> &coeffs);

    int conv_x_q_to_rns(std::vector<uint32_t> modulus, int rns_num, mpz_t *x, int x_num,
                        std::vector<std::vector<uint32_t>> &coeffs);

    int conv_rns_to_x(std::vector<uint32_t> modulus, std::vector<std::vector<uint32_t>> coeffs, mpz_t *x, int x_num);

    int conv_rnsq_to_rnsp(std::vector<uint32_t> modulus, int cur_rns_num, int raise_rns_num,
                          std::vector<std::vector<uint32_t>> coeffs, std::vector<std::vector<uint32_t>> &coeffs_result);

    int conv_rnsq_to_rnsp2(std::vector<uint32_t> modulus, int cur_rns_num, int raise_rns_num,
                           std::vector<std::vector<uint32_t>> coeffs, std::vector<std::vector<uint32_t>> &mult_mod,
                           std::vector<std::vector<uint32_t>> &coeffs_result);


    int math_talor_exp(std::vector<std::complex<double>> vec, std::vector<std::complex<double>> &taylor_exp_vec,
                       std::complex<double> const_data, int num_iterations, int taylor_coeff);

    int  multiply_naive(mpz_class *op1,const mpz_class *op2,
                        mpz_class *poly_res,const mpz_class &coeff_modulus,int degree);

    int  multiply_naive(mpz_t *op1,const mpz_t *op2,
                        mpz_t *poly_res,const vector<uint32_t> &coeff_modulus,int degree);

    int multiply_naive(const vector<uint32_t > poly1,const vector<uint32_t > poly2,
                   vector<uint32_t > &poly_res, uint32_t modulus,int degree);

//    template<typename T, typename = std::enable_if_t<is_uint32_v<T> || is_uint64_v<T>>>
//    inline T reverse_bits_t(T operand, int bit_count) {
//
//        // Just return zero if bit_count is zero
//        return (bit_count == 0) ? T(0)
//                                : reverse_bits_t(operand) >> (sizeof(T) * static_cast<std::size_t>(bits_per_byte) -
//                                                            static_cast<std::size_t>(bit_count));
//    }

    inline unsigned int reverse_bits_t(unsigned int n, uint32_t bits) {
        unsigned int reversed = 0;
        for (uint32_t i = 0; i < bits; i++) {
            reversed <<= 1;
            reversed |= n & 1;
            n >>= 1;
        }

        return reversed;
    }


    uint32_t qpow1(uint32_t root,uint32_t pow,uint32_t modulus);

    void cal_x0_to_xn_2(uint32_t root,uint32_t mod,vector<mpz_class > &res,int degree);

    void cal_x0_to_xn_1(uint32_t root,uint32_t mod,vector<uint32_t > &res,int degree);
}

#endif