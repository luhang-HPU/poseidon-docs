//
// Created by lxs on 8/8/23.
//

#ifndef POSEIDON_RNSTOOL_H
#define POSEIDON_RNSTOOL_H
#include <vector>
#include <gmpxx.h>
#include "polyarithsmallmod.h"
#include "../NTTContext.h"
using namespace std;
namespace poseidon{
    namespace util{
        class RNSBase{
        public:
            RNSBase(const std::vector<Modulus> &rnsbase);
            RNSBase(RNSBase &&source) = default;
            RNSBase(const RNSBase &copy);
            RNSBase &operator=(const RNSBase &assign) = delete;

            inline const Modulus &operator[](std::size_t index) const
            {
                if (index >= size_)
                {
                    throw std::out_of_range("index is out of range");
                }
                return base_[index];
            }


            inline std::size_t size() const noexcept
            {
                return size_;
            }

            inline const vector<Modulus> &base() const noexcept
            {
                return base_;
            }

            inline const mpz_class &base_prod() const noexcept
            {
                return base_prod_;
            }

            inline const vector<mpz_class> &punctured_prod_array() const noexcept
            {
                return punctured_prod_array_;
            }

            inline const vector<uint32_t> &inv_punctured_prod_mod_base_array() const noexcept
            {
                return inv_punctured_prod_mod_base_array_;
            }
            //void decompose(const vector<uint32_t> &value,vector<uint32_t> &dest);
            void decompose(const mpz_class &value,vector<uint32_t> &dest);
            bool contains(const Modulus &value) const noexcept;
            bool is_subbase_of(const RNSBase &superbase) const noexcept;
            RNSBase extend(const Modulus &value) const;
            RNSBase extend(const RNSBase &other) const;


        private:
            RNSBase() : size_(0)
            {
            }


            bool initialize();
            std::size_t size_;
            vector<Modulus> base_;
            mpz_class base_prod_;
            vector<mpz_class> punctured_prod_array_; //mao
            vector<uint32_t> inv_punctured_prod_mod_base_array_;
        };




        class BaseConverter{
        public:
            BaseConverter(const RNSBase &ibase, const RNSBase &obase)
              : ibase_(ibase), obase_(obase)
            {
                initialize();
            }


            inline std::size_t ibase_size() const noexcept
            {
                return ibase_.size();
            }
            inline std::size_t obase_size() const noexcept
            {
                return obase_.size();
            }

//            void exact_base_convert(const vector<uint32_t> &in, vector<uint32_t> &out) const;
            uint32_t exact_base_convert(const vector<uint32_t> &in) const;
            void exact_convert_array(const vector<vector<uint32_t>> &in, vector<uint32_t> &out) const;



        private:
            BaseConverter(const BaseConverter &copy) = delete;

            BaseConverter(BaseConverter &&source) = delete;

            BaseConverter &operator=(const BaseConverter &assign) = delete;

            BaseConverter &operator=(BaseConverter &&assign) = delete;

            void initialize();
            vector<vector<uint32_t>> base_change_matrix_;
            RNSBase ibase_;
            RNSBase obase_;
        };








        class RNSTool {
        public:
            static void fast_Bconv(const vector<vector<uint32_t>> &x, vector<vector<uint32_t>> &res,const vector<uint32_t>& mod_qi,const vector<uint32_t>& mod_B);


        public:
            RNSTool(size_t poly_modulus_degree, const vector<uint32_t> &coeff_modulus, const vector<uint32_t> &plain_modulus);
            void initialize(size_t poly_modulus_degree,const vector<uint32_t> &q, const vector<uint32_t>  &t);

            void fastbconv_m_tilde(const vector<vector<uint32_t>> &input, vector<vector<uint32_t>> &destination);
            void fastbconv_sk(const vector<vector<uint32_t>> & input, vector<vector<uint32_t>> & destination);

            void sm_mrq(const vector<vector<uint32_t>> & input, vector<vector<uint32_t>> & destination);
            void fast_floor(const vector<vector<uint32_t>> & input, vector<vector<uint32_t>> & destination);
            void mod_t_and_divide_q_last_inplace(const vector<vector<uint32_t>> & input, vector<vector<uint32_t>> &destination);
            void divide_q_last_inplace(const vector<vector<uint32_t>> & input, vector<vector<uint32_t>> &destination);


            inline  vector<NTTContext> &base_B_ntt() {
                return base_Bsk_ntt_;
            }

            inline const vector<uint32_t> &base_Bsk() const{
                return base_Bsk_;
            }

            inline const vector<uint32_t> &base_q() const{
                return base_q_;
            }

            inline const vector<uint32_t> &base_B() const{
                return base_B_;
            }

            inline const vector<uint32_t> base_Bskq() const{
                vector<uint32_t >tmp(base_q_);
                tmp.insert(tmp.end(),base_Bsk_.begin(),base_Bsk_.end());
                return tmp;
            }

            inline const uint32_t inv_q_last_mod_t() const{
                return inv_q_last_mod_t_;
            }


        private:
            size_t coeff_count_;
            vector<uint32_t> base_q_;
            vector<uint32_t> plain_modulus_;
            vector<uint32_t> base_Bsk_;
            vector<uint32_t> base_B_;
            vector<uint32_t> base_Bsk_m_tilde_;
            vector<uint32_t> base_q_to_Bsk_conv_;
            uint32_t m_tilde_;
            uint32_t m_sk_;
            uint32_t neg_inv_prod_q_mod_m_tilde_;
            uint32_t inv_prod_B_mod_m_sk_;
            vector<uint32_t> prod_q_mod_Bsk_;
            vector<uint32_t> prod_B_mod_q_;
            vector<uint32_t> inv_m_tilde_mod_Bsk_;
            vector<uint32_t> inv_prod_q_mod_Bsk_;

            vector<NTTContext> base_Bsk_ntt_;


            uint32_t inv_q_last_mod_t_;
            vector<uint32_t> inv_q_last_mod_q_;





            void fast_Bconv_m_tilde(const vector<vector<uint32_t>>& x,vector<vector<uint32_t>> &res,const vector<uint32_t>& mod_qi,const vector<uint32_t>& mod_B,uint32_t m);

        };
    }
}


#endif //POSEIDON_RNSTOOL_H
