//
// Created by lxs on 8/9/23.
//

#ifndef POSEIDON_POLYARITHSMALLMOD_H
#define POSEIDON_POLYARITHSMALLMOD_H
#include <vector>
#include <gmpxx.h>
#include <algorithm>
using namespace std;
namespace poseidon{
    namespace util{
        //uint
        uint32_t multiply_uint_mod(uint32_t x,  uint32_t y,uint32_t  modulus);
        uint32_t sub_uint_mod(uint32_t x,  uint32_t y,uint32_t  modulus);
        uint32_t add_uint_mod(uint32_t x,  uint32_t y,uint32_t  modulus);
        uint32_t negate_uint_mod(uint32_t x,uint32_t modulus);

        uint32_t multiply_add_uint_mod(uint32_t operand1, uint32_t operand2, uint32_t operand3,
                                       uint32_t modulus);

        uint32_t multiply_sub_uint_mod(uint32_t operand1, uint32_t operand2, uint32_t operand3,
                                       uint32_t modulus);

        //poly
        void multiply_poly_coeffmod(
                const vector<uint32_t> &poly1,const vector<uint32_t> &poly2, size_t coeff_count, uint32_t modulus,
                vector<uint32_t> &result);
        void multiply_poly_scalar_coeffmod(
                const vector<uint32_t> &poly, size_t coeff_count, uint32_t scalar, uint32_t modulus,
                vector<uint32_t> &result);

        void add_poly_scalar_coeffmod(
                const vector<uint32_t> &poly, size_t coeff_count, uint32_t scalar, uint32_t modulus,
                vector<uint32_t> &result);
        void add_poly_coeffmod(
                const vector<uint32_t> &poly1,const vector<uint32_t> &poly2, size_t coeff_count, uint32_t modulus,
                vector<uint32_t> &result);

        void sub_poly_coeffmod(
                const vector<uint32_t> &poly1,const vector<uint32_t> &poly2, size_t coeff_count, uint32_t modulus,
                vector<uint32_t> &result);

        void sub_poly_scalar_coeffmod(
                const vector<uint32_t> &poly1,uint32_t scalar, size_t coeff_count, uint32_t modulus,
                vector<uint32_t> &result);

        void dyadic_product_coeffmod(const vector<uint32_t> &operand1, const vector<uint32_t> &operand2, size_t coeff_count, uint32_t modulus,
                                     vector<uint32_t> &result);
        void modulo_poly_coeffs(const vector<uint32_t> &operand1, size_t coeff_count, uint32_t modulus, vector<uint32_t> &result);

        void negate_poly_coeffmod(const vector<uint32_t> &operand1, size_t coeff_count, uint32_t modulus,vector<uint32_t> &result);


        }
}




#endif //POSEIDON_POLYARITHSMALLMOD_H
