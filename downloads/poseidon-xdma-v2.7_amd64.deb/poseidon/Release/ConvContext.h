#ifndef CONV_CONTEXT_H
#define CONV_CONTEXT_H

#include <vector>
#include "define.h"
#include <gmpxx.h>
namespace poseidon{

    class ConvContext
    {
    private:
        std::vector <uint32_t> primes_conv_inv_; //q_i_m_inv(param 1)
        std::vector <uint32_t> primes_p_inv_; //p_inv (param 3)
        std::vector <uint32_t> primes_degree_inv_; //intt scalar(param 4)
        std::vector <uint32_t> primes_combine_degree_conv_inv_;//combine primes_conv_inv_(param 1) and primes_degree_inv_ (param 4)data
        std::vector <std::vector <uint32_t>> primes_conv_;
        std::vector <std::vector <uint32_t>> primes_conv_combine_p_inv_; //combine primes_conv(param 2) and p_inv (param 3)data
        std::vector <std::vector <uint32_t>> primes_conv_add_p_inv_param_; //store primes_conv(param 2) and p_inv (param 3) together
        int cal_intt_conv(int degree,std::vector <uint32_t> primes);
        int cal_raise_conv(int q_len,int p_offset,int p_len,std::vector <uint32_t> primes);
        int cal_reduce_conv(int q_len,int p_offset,int p_len,std::vector <uint32_t> primes);
    public:
        ConvContext(int degree,int q_len,int p_offset,int p_len,bool isRaise,bool isRescale,std::vector <uint32_t> primes);
        ConvContext(int degree,std::vector <uint32_t> primes);
        std::vector<uint32_t> primes_conv_inv();
        std::vector<uint32_t> primes_combine_degree_conv_inv();
        std::vector<uint32_t> primes_degree_inv();
        std::vector <std::vector <uint32_t>> primes_conv();  
        std::vector <std::vector <uint32_t>> primes_conv_combine_p_inv();  
        std::vector <uint32_t> primes_p_inv();
        std::vector <std::vector <uint32_t>> primes_conv_add_p_inv_param();
    };



}


#endif