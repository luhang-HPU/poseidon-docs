//
// Created by lxs on 5/29/23.
//

#ifndef POSEIDON_KEYGENERATOR_H
#define POSEIDON_KEYGENERATOR_H
#include "PoseidonContext.h"
#include "SecretKey.h"
#include "PublicKey.h"
#include "rlwe.h"
#include "RelinKeys.h"
#include "GaloisKeys.h"
namespace poseidon{
    class KeyGenerator {

    public:
        KeyGenerator(const  PoseidonContext& params);
        KeyGenerator(const  PoseidonContext& params,const SecretKey &sk);
        const SecretKey &secret_key() const;

        inline void create_public_key(PublicKey &destination) const
        {
            //destination = GenPublicKey(false);
            GenPublicKey(false,destination);
        }
        void GenPublicKey(bool save_seed, PublicKey& public_key) const;

        inline void create_relin_keys(RelinKeys &destination)
        {
            destination = create_relin_keys(1, false);
        }

        inline void create_galois_keys(const std::vector<std::uint32_t> &galois_elts, GaloisKeys &destination)
        {
            destination = create_galois_keys(galois_elts, false);
        }

        inline void create_galois_keys(const std::vector<int> &steps, GaloisKeys &destination)
        {
            destination = create_galois_keys(context_.galois_tool()->get_elts_from_steps(steps), false);
        }

        inline void create_galois_keys(GaloisKeys &destination)
        {
            std::vector<int> steps;
            steps.push_back(0);
            uint32_t n = context_.poly_degree();
            for(uint32_t i = 1; i < (n >> 1); i *= 2)
            {
                steps.push_back(i);
                steps.push_back(-i);
            }
            destination = create_galois_keys(context_.galois_tool()->get_elts_from_steps(steps), false);
        }

        inline void create_conj_keys(GaloisKeys &destination)
        {
            destination = create_conj_keys(1, false);
        }







    private:
        KeyGenerator(const KeyGenerator &copy) = delete;
        KeyGenerator &operator=(const KeyGenerator &assign) = delete;
        KeyGenerator(KeyGenerator &&source) = delete;
        KeyGenerator &operator=(KeyGenerator &&assign) = delete;
        PoseidonContext context_;
        SecretKey sk_pq_;
        SecretKey sk_;
        bool sk_generated_ = false;
        void generate_one_kswitch_key(SecretKey& new_key, vector<PublicKey> &destination, bool save_seed);
        RelinKeys create_relin_keys(size_t count, bool save_seed);
        GaloisKeys create_conj_keys(size_t count, bool save_seed);
        GaloisKeys create_galois_keys(const std::vector<std::uint32_t> &galois_elts,bool save_seed);
        int GenSecretKey(bool is_initialized = false);
        //PublicKey GenPublicKey(bool save_seed) const;



    };
}



#endif //POSEIDON_KEYGENERATOR_H
