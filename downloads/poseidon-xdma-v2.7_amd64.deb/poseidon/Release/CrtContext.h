#ifndef CRT_CONTEXT_H
#define CRT_CONTEXT_H
#include <unordered_map>
#include <vector>
#include "define.h"
#include "util/number_theory.h"
#include "NTTContext.h"
#include <gmpxx.h>
#include "ConvContext.h"
namespace poseidon 
{
    class CrtContext {
    private:
        uint32_t poly_degree_;
        uint32_t num_primes_q_;
        std::vector<uint32_t> primes_;
        std::vector<uint32_t> primes_q_;
        int q0_level_;
        uint64_t q0_;
        std::vector<uint32_t> primes_p_;
        bool has_ringT_;
        uint32_t primes_t_;
        std::vector<uint32_t> t_inv_;
        std::vector<uint32_t> q_inv_t_;
        std::vector<uint32_t> qHalfModT_;
        std::vector<uint64_t> barrett_reduction_c_;
        std::vector<uint64_t> barrett_reduction_cc_;
        mpz_class *level_modulus_;
        mpz_class P_;
        std::vector<NTTContext> ntt_;
        std::vector<uint32_t> prime_Bsk_;
        std::vector<ConvContext> conv_;
        std::vector<ConvContext> conv_B_; //bfv base b





        //void generate_primes( uint32_t num_primes,uint32_t q0_size,uint32_t prime_size,uint64_t mod);


        int GenerateNTTPrimes(uint32_t num_primes, uint32_t prime_size, uint64_t NthRoot, vector<uint64_t> &primes);

        int generate_primes(int logN, const vector<uint32_t> &logQ, const vector<uint32_t> &logP);

        void generate_primes_barrett_params();

        void generate_ntt_contexts();

        int generate_modulus_at_level(int num_primes_q);

        int generate_mod_p(int num_primes_p);


    public:
        CrtContext(int logN,const vector<uint32_t>& logQ,const vector<uint32_t>& logP,int q0_level,bool has_t,uint32_t primes_t, bool direct);

        void generate_default_primes_conv();



        std::vector<uint32_t> primes();
        std::vector<uint32_t> primes_q();
        std::vector<uint32_t> primes_p();
        const uint64_t q0() const;
        const int q0_level() const;
        std::vector <uint32_t> t_inv_q();
        std::uint32_t q_inv_t(int level);
        std::uint32_t q_half(int level);
        uint32_t primes_t();
        std::vector<uint64_t> primes_barrett_reduction_c();
        std::vector<uint64_t> primes_barrett_reduction_cc();
        std::vector<NTTContext> ntt_contexts();
        std::vector<ConvContext> conv_contexts();
        uint32_t degree();
        uint32_t num_primes_q();
        uint32_t maxLevel();
        const mpz_class ModulusAtLevel(int level) const;
        const mpz_class P() const;
    };
}

#endif


