//
// Created by lxs on 23-6-19.
//

#ifndef POSEIDON_LINEAR_TRANSFORM_H
#define POSEIDON_LINEAR_TRANSFORM_H
#include <iostream>
#include <vector>
#include <map>
#include "CKKSEncoder.h"
#include "BatchEncoder.h"
#include "util/matrix_operation.h"
using namespace std;
typedef map<int, vector<int>> IndexMap;
bool IsInSliceInt(int x,const vector<int>& slice);

namespace poseidon {
    class MatrixPlain{
    private:

    public:
        uint32_t LogSlots;
        uint32_t N1;
        uint32_t level;
        mpf_class scale;
        //map <int,Plaintext> plain_vec;  //<index,plaintext>
        vector<int> rot_index;
        map <int,Plaintext> plain_vec;
        MatrixPlain() = default;
    };

    class LinearMatrixGroup{
    public:
        LinearMatrixGroup() = default;
        inline  vector<MatrixPlain> &data() noexcept{
            return matrices_;
        }

        inline  const vector<MatrixPlain> &data() const noexcept{
            return matrices_;
        }


        inline  vector<int> &rot_index()  noexcept{
            return rotate_index_;
        }

        inline  const vector<int> &rot_index()  const noexcept{
            return rotate_index_;
        }

        inline  const int step() const noexcept {
            return scalar_step_;
        }

        inline void set_step(uint32_t step)  noexcept {
            scalar_step_ = step;
        }
    private:
        vector<MatrixPlain> matrices_;
        vector<int> rotate_index_;
        uint32_t scalar_step_;
    };


    /*函数 BsgsIndex 的功能是将一个稀疏矩阵中所有非零元素的旋转值（一个元素在矩阵中旋转的角度）分别映射到两个向量中，
以便后续的差分对算法（Babai's Stocastic Group Search，简称 BSGS）能够高效地计算矩阵乘法。

具体来说，函数的输入参数如下：

el：一个稀疏矩阵，用 C++ 的 std::map<int, std::vector<uint64_t> > 表示，其中 std::map 中的键表示对角线编号，std::vector 中的元素表示该对角线上的非零元素值。
slots：一个整数，表示旋转值的范围，即所有可能的旋转值的个数。
N1：一个整数，表示矩阵中每个元素的旋转值的最高位所占的二进制位数。
index：一个 std::map<int,std::vector<int> > 类型的引用，用于存储将旋转值映射到的对角线编号，其中 std::map 中的键表示对角线编号，std::vector 中的元素表示该对角线上的所有旋转值。
rotN1：一个 std::vector<int> 类型的引用，用于存储所有旋转值所对应的一级索引值。
rotN2：一个 std::vector<int> 类型的引用，用于存储所有旋转值所对应的二级索引值。


函数的输出结果包括了三个部分：

将所有非零元素的旋转值映射到的对角线编号，保存在 index 中；
将所有旋转值所对应的一级索引值，保存在 rotN1 中；
将所有旋转值所对应的二级索引值，保存在 rotN2 中。


函数的具体实现流程如下：

遍历稀疏矩阵 el 中的所有非零元素，计算每个元素的旋转值 rot；
将 rot 映射到一级索引值 idxN1 和二级索引值 idxN2 上，其中 idxN1 表示将 rot 的最高位清零后除以 N1 所得到的值再乘以 N1，idxN2 表示 rot 除以 N1 所得到的余数；
将 idxN1 和 idxN2 存储到 index 中的合适位置，同时将 idxN1 存储到 rotN1 中；
将 idxN2 存储到 rotN2 中，确保 rotN2 中不会出现重复的索引值。
通过这样的处理，我们可以将稀疏矩阵中的所有非零元素的旋转值映射到一级索引和二级索引上，并且可以高效地计算矩阵乘法。

*/

    template<typename T>
    tuple<IndexMap, vector<int>, vector<int> >  BSGSIndex(const T& el, int slots, int N1) {
        std::map<int,bool> rotN1Map;
        std::map<int,bool> rotN2Map;
        std::vector<int> nonZeroDiags;

        IndexMap index;
        vector<int> rotN1, rotN2;
        // Convert el to nonZeroDiags
        nonZeroDiags.reserve(el.size());
        for (typename T::const_iterator it = el.begin(); it != el.end(); ++it) {
            nonZeroDiags.push_back(it->first);
        }

        for (typename std::vector<int>::const_iterator it = nonZeroDiags.begin(); it != nonZeroDiags.end(); ++it) {
            int rot = *it;
            rot &= (slots - 1);
            int idxN1 = ((rot / N1) * N1) & (slots - 1);
            int idxN2 = rot & (N1 - 1);
            index[idxN1].push_back(idxN2);
            if (rotN1Map.find(idxN1) == rotN1Map.end()) {
                rotN1Map[idxN1] = true;
                rotN1.push_back(idxN1);
            }
            rotN2Map[idxN2] = true;
        }

        rotN2.clear();
        for (typename std::map<int,bool>::const_iterator it = rotN2Map.begin(); it != rotN2Map.end(); ++it) {
            rotN2.push_back(it->first);
        }

        return make_tuple(index, rotN1, rotN2);
    }

    template<typename T>
    int FindBestBSGSRatio(const T& diagMatrix, int maxN, int logMaxRatio) {
        int minN;
        double maxRatio = double(1 << logMaxRatio);

        for (int N1 = maxN; N1 >= 2; N1 >>= 1) {
            vector<int> rotN1, rotN2;
            IndexMap index;
            tie(index, rotN1, rotN2) = BSGSIndex(diagMatrix, maxN, N1);

            int nbN1 = rotN1.size() - 1, nbN2 = rotN2.size() - 1;

            if (double(nbN1) / double(nbN2) == maxRatio) {
                return N1;
            }

            if ( double(nbN1)/ double(nbN2) > maxRatio) {
                return N1 * 2;
            }
        }

        return 1;
    }

    template<typename T>
    void copyRotInterface(vector<T> &a, vector<T> &b ,  int rot){
        size_t n = a.size();

        if(b.size() >= rot){
            copy(b.begin()+rot, b.end(), a.begin());
            copy(b.begin(),b.begin()+rot,a.begin()+n-rot);

        }
        else{
            copy(b.begin(),b.end(),a.begin()+n-rot);

        }

    }

    template<typename T>
    void copyRotInterface_bfv(vector<T> &a, vector<T> &b ,  int rot){
        size_t n = a.size();
        auto slots = n >> 1;

        a = matrix_operations::rotate_slots_vec(b,-rot);
    }



    template<typename T>
    void addMatrixRotToList(const  map<int, vector<T>> &value,vector<int> &rot_index,int N1,int slots,bool repack){
        int index = 0;
        bool exist;
        for(auto i : value){

            index = (i.first / N1) *N1;

            if (repack == true){
                // Sparse repacking, occurring during the first IDFT matrix.
                index &= (2*slots - 1);
            } else {
                // Other cases
                index &= (slots - 1);
            }
            exist = IsInSliceInt(index, rot_index);
            if (index != 0 && !exist) {

                rot_index.push_back(index);
            }

            index = i.first & (N1 - 1);
            exist = IsInSliceInt(index, rot_index);
            if (index != 0 && !exist) {
                rot_index.push_back(index);
            }
        }
    }

    template<typename T>
    void GenLinearTransformBSGS(MatrixPlain &plain_mat,vector<int>& rotate_index, CKKSEncoder &encoder,  map<int, vector<T>> &value, int level ,mpf_class scale, int LogBSGSRatio, int  logSlots){
        auto slots = 1 << logSlots;
        auto N1 = FindBestBSGSRatio(value, slots, LogBSGSRatio);
        plain_mat.N1 = N1;
        plain_mat.LogSlots = logSlots;
        plain_mat.level = level;
        plain_mat.scale = scale;

        addMatrixRotToList(value,rotate_index,N1,slots,false);
        auto [index,n1,n2] = BSGSIndex(value,slots,N1);
        vector<T> values(slots);

        for(auto j : index){
            int a = 0;
            auto rot = -(j.first) & (slots - 1);
            for (auto i : index[j.first]) {
                //plain_mat.plain_vec[j+i]

                copyRotInterface(values,value[j.first+i] , rot);

                encoder.encode(values,plain_mat.plain_vec[j.first+i] ,scale,level);

            }
        }
    }

    template<typename T>
    void GenMatrixformBSGS(MatrixPlain &plain_mat,vector<int>& rotate_index, CKKSEncoder &encoder, vector<vector<T >> mat_data , int level ,mpf_class scale, int LogBSGSRatio, int  logSlots){

        map<int, vector<T>> value;
        for(int i = 0; i < mat_data.size(); i++){
            value[i] = mat_data[i];
        }

        auto slots = 1 << logSlots;
        auto N1 = FindBestBSGSRatio(value, slots, LogBSGSRatio);
        plain_mat.N1 = N1;
        plain_mat.LogSlots = logSlots;
        plain_mat.level = level;
        plain_mat.scale = scale;

        addMatrixRotToList(value,rotate_index,N1,slots,false);
        auto [index,n1,n2] = BSGSIndex(value,slots,N1);
        vector<T> values(slots);

        for(auto j : index){
            int a = 0;
            auto rot = -(j.first) & (slots - 1);
            for (auto i : index[j.first]) {
                //plain_mat.plain_vec[j+i]

                copyRotInterface(values,value[j.first+i] , rot);

                encoder.encode(values,plain_mat.plain_vec[j.first+i] ,scale,level);

            }
        }
    }

    template<typename T>
    void GenMatrixformBSGS(MatrixPlain &plain_mat, vector<int>& rotate_index, BatchEncoder &encoder, vector<vector<T >> mat_data , int level , mpf_class scale, int LogBSGSRatio, int  logSlots){
//        Plaintext a;
//        encoder.encode(mat_data[0],a);
        map<int, vector<T>> value;
        for(int i = 0; i < mat_data.size(); i++){
            value[i] = mat_data[i];
        }

        auto slots = 1 << logSlots;
        auto N1 = FindBestBSGSRatio(value, slots, LogBSGSRatio);
        plain_mat.N1 = N1;
        plain_mat.LogSlots = logSlots;
        plain_mat.level = level;
        plain_mat.scale = scale;

        addMatrixRotToList(value,rotate_index,N1,slots,false);
        auto [index,n1,n2] = BSGSIndex(value,slots,N1);
        vector<T> values(slots);

        for(auto j : index){
            int a = 0;
            //auto rot = -(j.first) & (slots - 1);
            auto rot = j.first;
            for (auto i : index[j.first]) {
                //plain_mat.plain_vec[j+i]

                copyRotInterface_bfv(values,value[j.first+i] , rot);
                encoder.encode(values,plain_mat.plain_vec[j.first+i],level);
                //encoder.encode(values,a);

            }
        }
    }



}








#endif //POSEIDON_LINEAR_TRANSFORM_H
