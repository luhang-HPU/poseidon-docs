//
// Created by lxs on 23-10-16.
//

#ifndef POSEIDON_LWE_H
#define POSEIDON_LWE_H
#include "../PoseidonContext.h"
#include "../Ciphertext.h"
#include "../SecretKey.h"
#include "RGSWCiphertext.h"
#include "TLWECiphertext.h"
#include "Ciphertext_RGSW.h"

namespace poseidon{
    namespace util{
        void SampleExt(const PoseidonContext &context,const Ciphertext &ct, Ciphertext &lwe, int k);
        void SampleExt(const PoseidonContext &context,const Ciphertext &ct, Ciphertext_RLWE &lwe, int k);
        void SampleExtInv(const PoseidonContext &context, const vector<Ciphertext> &lwe_group, Ciphertext &rlwe, SecretKey key);
        void LWEModulusSwitch(const PoseidonContext &context,const Ciphertext &ct,Ciphertext &ct2);
        void LWEModulusSwitch_2N(const PoseidonContext &context, Ciphertext_RLWE &ct,uint32_t new_mod);
        uint32_t LWEDecrypt(const Ciphertext_RLWE &ct,SecretKey key);
        void LWEDecrypt(const PoseidonContext &context,const Ciphertext &ct,SecretKey key);
        void LWEDecrypt(const PoseidonContext &context,const Ciphertext &ct,SecretKey key,uint32_t mod);


    }

    class tfhe{
    public:
        inline tfhe(const RGSWOpt &rgswOpt)
        :rgswOpt_(rgswOpt)
        {}
        void tfhe_mux_rotate(TLWECiphertext &result, const TLWECiphertext &accum, const RGSWCiphertext &bki,int32_t  barai);
        void tfhe_blind_rotate(TLWECiphertext &result, const TLWECiphertext &accum, const vector<RGSWCiphertext> &bki,const vector<uint32_t > &barai);

    private:
        RGSWOpt rgswOpt_;

    };

    class tfhe_evaluator{
    public:
        inline explicit tfhe_evaluator(Opt_RGSW rgswOpt)
                :rgswOpt_(std::move(rgswOpt))
        {}
        void tfhe_mux_rotate(Ciphertext_TLWE &result, const Ciphertext_TLWE &accum, const Ciphertext_RGSW &bki,int32_t  barai);
        void tfhe_blind_rotate(Ciphertext_TLWE &result, const Ciphertext_TLWE &accum, const vector<Ciphertext_RGSW> &bki,const vector<uint32_t > &bara);

    private:
        Opt_RGSW rgswOpt_;
    };



}




#endif //POSEIDON_LWE_H
