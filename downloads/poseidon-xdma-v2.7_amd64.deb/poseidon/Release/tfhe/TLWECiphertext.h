//
// Created by lxs on 6/8/23.
//

#ifndef POSEIDON_TLWE_CIPH_H
#define POSEIDON_TLWE_CIPH_H
#include "../KeySwitchKey.h"
#include "../SecretKey.h"
#include "../common.h"
namespace poseidon {
    class TLWEPoly{
    public:
         [[nodiscard]] inline  uint32_t  degree() const{
            return safe_cast<uint32_t >(data_[0].size());
        }

        [[nodiscard]] inline  uint32_t rns_num() const{
            return safe_cast<uint32_t >(data_.size());
        }

        inline void alloc(uint32_t rns_num, uint32_t degree){
             data_.resize(rns_num);
             for(auto &rns : data_){
                 rns.resize(degree,0);
             }
         }

        inline void clear(){
            for(auto &rns : data_){
                for(auto &uint : rns)
                    uint = 0;
            }
        }

        [[nodiscard]] inline vector<vector<uint32_t>> &data(){
            return data_;
         }

        [[nodiscard]] inline const vector<vector<uint32_t>> &data() const{
            return data_;
        }

    private:
        vector<vector<uint32_t>> data_;//rns 8 degree

    };



    class Ciphertext_TLWE{
    public:
        Ciphertext_TLWE() = default;
        Ciphertext_TLWE(const Ciphertext_TLWE &copy) = default;
        Ciphertext_TLWE(Ciphertext_TLWE &&assign) = default;
        Ciphertext_TLWE &operator=(const Ciphertext_TLWE &copy) = default;
        Ciphertext_TLWE &operator=(Ciphertext_TLWE &&assign) = default;

        inline void alloc(uint32_t poly_num,uint32_t rns_num, uint32_t degree){
            data_.resize(poly_num);
            for(auto &poly : data_){
                poly.alloc(rns_num,degree);
            }
        }

        inline const vector<TLWEPoly>  &data() const{
            return data_;
        }

        inline vector<TLWEPoly>  &data() {
            return data_;
        }

    private:
        vector<TLWEPoly> data_{};//(poly_num * degree)
    };


    void tlwe_clear(Ciphertext_TLWE &result);
    void tlwe_ftt_fwd(Ciphertext_TLWE &result,vector <NTTContext> &ntt);
    void tlwe_ftt_inv(Ciphertext_TLWE &result,vector <NTTContext> &ntt);
    void tlwe_add_inplace(Ciphertext_TLWE &result,const Ciphertext_TLWE &sample,const vector <uint32_t> &modulus);
    void tlwe_sub_inplace(Ciphertext_TLWE &result,const Ciphertext_TLWE &sample,const vector <uint32_t> &modulus);

    void tlwe_add_mul(Ciphertext_TLWE &result,const TLWEPoly &p,const Ciphertext_TLWE &sample, const vector <uint32_t> &modulus);
    void poly_mul_x_ai(TLWEPoly &result, int32_t a, const TLWEPoly &source,const vector<uint32_t> &modulus);
    void poly_mul_x_aiMinus1(TLWEPoly &result, int32_t a, const TLWEPoly &source,const vector<uint32_t> &modulus);
    void tlwe_mul_x_ai(Ciphertext_TLWE &result, int32_t a, const Ciphertext_TLWE &source,const vector<uint32_t> &modulus);
    void tlwe_mul_x_aiMinus1(Ciphertext_TLWE &result, int32_t a, const Ciphertext_TLWE &source,const vector<uint32_t> &modulus);




    // mod 2N
    class TLWECiphertext{
    public:
        TLWECiphertext() = default;
        TLWECiphertext(const TLWECiphertext &copy) = default;
        TLWECiphertext(TLWECiphertext &&assign) = default;
        TLWECiphertext &operator=(const TLWECiphertext &copy) = default;
        TLWECiphertext &operator=(TLWECiphertext &&assign) = default;

        void alloc(int32_t poly_num,int32_t degree);

        inline const vector<vector<uint32_t>>  &data() const{
            return data_;
        }

        inline vector<vector<uint32_t>>  &data() {
            return data_;
        }


    private:
        vector<vector<uint32_t>> data_{};//(poly_num * degree)
    };

    class TLWESecretKey{
    public:
        TLWESecretKey() = default;
        TLWESecretKey(const TLWESecretKey &copy) = default;
        TLWESecretKey(TLWESecretKey &&assign) = default;
        TLWESecretKey &operator=(const TLWESecretKey &copy) = default;
        TLWESecretKey &operator=(TLWESecretKey &&assign) = default;
        void alloc(int32_t degree);

        inline const vector<uint32_t> &data() const{
            return data_;
        }

        inline vector<uint32_t>  &data() {
            return data_;
        }

    private:
        vector<uint32_t> data_{};//

    };


    class TLWEDecomp{
    public:
        TLWEDecomp() = default;
        TLWEDecomp(const TLWEDecomp &copy) = default;
        TLWEDecomp(TLWEDecomp &&assign) = default;
        TLWEDecomp &operator=(const TLWEDecomp &copy) = default;
        TLWEDecomp &operator=(TLWEDecomp &&assign) = default;


        inline vector<vector<TLWESecretKey>> const &data() const{
            return data_;
        }

        inline vector<vector<TLWESecretKey>>  &data() {
            return data_;
        }

    private:
        vector<vector<TLWESecretKey>> data_{};//poly_num * l
    };



    TLWESecretKey get_from_secret_key(const SecretKey &key);
    void tlwe_add_inplace(TLWECiphertext &result,const TLWECiphertext &sample, uint32_t modulus);
    void tlwe_add_mul_naive(TLWECiphertext &result,const vector<uint32_t> &p,const TLWECiphertext &sample, uint32_t modulus);
    void tlwe_add_mul_ntt(TLWECiphertext &result,const vector<uint32_t> &p,const TLWECiphertext &sample, uint32_t modulus);

    void tlwe_clear(TLWECiphertext &result);
    void poly_mul_x_ai(vector<uint32_t > &result, int32_t a, const vector<uint32_t > &source,uint32_t modulus);
    void poly_mul_x_aiMinus1(vector<uint32_t > &result, int32_t a, const vector<uint32_t > &source,uint32_t modulus);
    void tlwe_mul_x_ai(TLWECiphertext &result, int32_t a, const TLWECiphertext &source,uint32_t modulus);
    void tlwe_mul_x_aiMinus1(TLWECiphertext &result, int32_t a, const TLWECiphertext &source,uint32_t modulus);












} // poseidon

#endif
