//
// Created by lxs on 10/30/23.
//

#ifndef POSEIDON_MULTIPLICATION_TFHE_H
#define POSEIDON_MULTIPLICATION_TFHE_H
#include "TLWECiphertext.h"
namespace poseidon{
    namespace util{

        void torusPolynomialMultNaive_aux(vector<uint32_t > &result, const vector<uint32_t > &poly1, const vector<uint32_t > &poly2, const size_t N) {
            uint32_t ri;
            for (int32_t i=0; i<N; i++) {
                ri=0;
                for (int32_t j=0; j<=i; j++) {
                    ri += poly1[j]*poly2[i-j];
                }
                for (int32_t j=i+1; j<N; j++) {
                    ri -= poly1[j]*poly2[N+i-j];
                }
                result[i]=ri;
            }
        }

/**
 * This is the naive external multiplication of an integer polynomial
 * with a torus polynomial. (this function should yield exactly the same
 * result as the karatsuba or fft version) 
 */
         void torusPolynomialMultNaive(vector<uint32_t > &result, const vector<uint32_t > &poly1, const vector<uint32_t > &poly2) {
            auto N = poly1.size();
            //assert(result!=poly2);
            assert(poly2.size()==N);
            result.resize(N);
            torusPolynomialMultNaive_aux(result, poly1, poly2, N);
        }


        void torusPolynomialMultNaive_plain_aux(uint32_t * __restrict result, const int32_t* __restrict poly1, const uint32_t* __restrict poly2, const int32_t N) {
            const int32_t _2Nm1 = 2*N-1;
            uint32_t ri;
            for (int32_t i=0; i<N; i++) {
                ri=0;
                for (int32_t j=0; j<=i; j++) {
                    ri += poly1[j]*poly2[i-j];
                }
                result[i]=ri;
            }
            for (int32_t i=N; i<_2Nm1; i++) {
                ri=0;
                for (int32_t j=i-N+1; j<N; j++) {
                    ri += poly1[j]*poly2[i-j];
                }
                result[i]=ri;
            }
        }
/**
 * This function multiplies 2 polynomials (an integer poly and a torus poly) by using Karatsuba
 * The karatsuba function is torusPolynomialMultKaratsuba: it takes in input two polynomials and multiplies them 
 * To do that, it uses the auxiliary function Karatsuba_aux, which is recursive ad which works with 
 * the vectors containing the coefficients of the polynomials (primitive types)
 */

// A and B of size = size
// R of size = 2*size-1
        void Karatsuba_aux(uint32_t* R, const int32_t* A, const uint32_t* B, const int32_t size, const char* buf){
            const int32_t h = size / 2;
            const int32_t sm1 = size-1;

            //we stop the karatsuba recursion at h=4, because on my machine,
            //it seems to be optimal
            if (h<=4)
            {
                torusPolynomialMultNaive_plain_aux(R, A, B, size);
                return;
            }

            //we split the polynomials in 2
            int32_t* Atemp = (int32_t*) buf; buf += h*sizeof(int32_t);
            uint32_t* Btemp = (uint32_t*) buf; buf+= h*sizeof(uint32_t);
            uint32_t* Rtemp = (uint32_t*) buf; buf+= size*sizeof(uint32_t);
            //Note: in the above line, I have put size instead of sm1 so that buf remains aligned on a power of 2

            for (int32_t i = 0; i < h; ++i)
                Atemp[i] = A[i] + A[h+i];
            for (int32_t i = 0; i < h; ++i)
                Btemp[i] = B[i] + B[h+i];

            // Karatsuba recursivly
            Karatsuba_aux(R, A, B, h, buf); // (R[0],R[2*h-2]), (A[0],A[h-1]), (B[0],B[h-1])
            Karatsuba_aux(R+size, A+h, B+h, h, buf); // (R[2*h],R[4*h-2]), (A[h],A[2*h-1]), (B[h],B[2*h-1])
            Karatsuba_aux(Rtemp, Atemp, Btemp, h, buf);
            R[sm1]=0; //this one needs to be set manually
            for (int32_t i = 0; i < sm1; ++i)
                Rtemp[i] -= R[i] + R[size+i];
            for (int32_t i = 0; i < sm1; ++i)
                R[h+i] += Rtemp[i];
        }


//        void torusPolynomialMultKaratsuba(vector<uint32_t > &result, const vector<uint32_t > &poly1, const vector<uint32_t > &oly2){
//            auto N = poly1.size();
//            uint32_t* R = new uint32_t[2*N-1];
//            char* buf = new char[16*N]; //that's large enough to store every tmp variables (2*2*N*4)
//
//            // Karatsuba
//            Karatsuba_aux(R, poly1->coefs, poly2->coefsT, N, buf);
//
//            // reduction mod X^N+1
//            for (int32_t i = 0; i < N-1; ++i)
//                result->coefsT[i] = R[i] - R[N+i];
//            result->coefsT[N-1] = R[N-1];
//
//            delete[] R;
//            delete[] buf;
//        }
//
        

    }
}


#endif //POSEIDON_MULTIPLICATION_TFHE_H
