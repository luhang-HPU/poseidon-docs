//
// Created by lxs on 6/8/23.
//

#ifndef POSEIDON_CIPH_RGSW_H
#define POSEIDON_CIPH_RGSW_H
#include "../KeySwitchKey.h"
#include "../SecretKey.h"
#include "TLWECiphertext.h"


struct BigNUm_RNS{
    mpz_class bigNum;
    vector<uint32_t > rns_vec;
};

inline void bigNum_to_rns(const mpz_class &big_num, const vector<uint32_t > &modulus,vector<uint32_t > &rns_vec){
    if(modulus.empty()){
        throw invalid_argument("BigNUm_RNS : no modulus!");
    }

    auto size = modulus.size();

    if(rns_vec.empty()){
        rns_vec.resize(size);
    }
    mpz_class tmp;
    for(size_t i = 0; i < size; i++){
        mpz_mod_ui(tmp.get_mpz_t(),big_num.get_mpz_t(),modulus[i]);
        rns_vec[i] = tmp.get_ui();
    }
}

namespace poseidon {
    class Params_RGSW{
    public:
        inline Params_RGSW(const vector<uint32_t > &modulus ,uint32_t l, uint32_t degree,uint32_t BGbit, uint32_t poly_num)
          :l_(l),poly_num_(poly_num),degree_(degree),modulus_(modulus), Bgbit_(BGbit),Bg_(1 << BGbit),halfBg_(1 << (BGbit - 1))
        {

            auto sizes =  modulus.size();
            auto bits = mul_safe(sizeof(uint32_t)*8,sizes) ;
            mask_mod_ = Bg_ - 1;
            max_bit_ = bits;


            h_.resize(l);
            for (int32_t i = 0; i < l; ++i) {
                auto kk = (bits - (i + 1) * Bgbit_);
                mpz_mul_2exp(h_[i].bigNum.get_mpz_t(),mpz_class(1).get_mpz_t(),kk); // 1/(Bg^(i+1)) as a Torus32
                gmp_printf("h[%d] : %Zd\n",i,h_[i].bigNum.get_mpz_t());
                bigNum_to_rns(h_[i].bigNum,modulus_,h_[i].rns_vec);
            }

        }



        ~Params_RGSW() = default;
        Params_RGSW(const Params_RGSW &copy) = default;
        Params_RGSW(Params_RGSW &&assign) = default;
        Params_RGSW &operator=(const Params_RGSW &copy) = delete;
        Params_RGSW &operator=(Params_RGSW &&assign) = default;
        [[nodiscard]] inline  uint32_t l() const{
            return l_;
        }

        inline uint32_t &l(){
            return l_;
        }
        [[nodiscard]] inline  uint32_t max_bit() const{
            return max_bit_;
        }

        [[nodiscard]] inline  uint32_t Bgbit() const{
            return Bgbit_;
        }

        inline uint32_t &Bgbit() {
            return Bgbit_;
        }

        [[nodiscard]] inline  uint32_t Bg() const{
            return Bg_;
        }

        [[nodiscard]] inline  uint32_t mask_mod() const{
            return mask_mod_;
        }

        [[nodiscard]] inline  uint32_t halfBg() const{
            return halfBg_;
        }




        [[nodiscard]] inline const vector<BigNUm_RNS > &h() const{ //rns
            return h_;
        }

//        inline const uint32_t &offset() const{
//            return offset_;
//        }

        [[nodiscard]] inline  uint32_t poly_num() const{
            return poly_num_;
        }


        [[nodiscard]] inline  uint32_t degree() const{
            return degree_;
        }

        inline  vector<uint32_t> &modulus() {
            return modulus_;
        }
        [[nodiscard]] inline const vector<uint32_t> &modulus() const{
            return modulus_;
        }



    private:

        uint32_t degree_ = 0;
        uint32_t poly_num_ = 0;
        uint32_t l_ = 0; ///< decomp length
        uint32_t max_bit_ = 0;
        uint32_t Bgbit_ = 0;///< log_2(Bg)
        uint32_t mask_mod_ = 0;
        vector<uint32_t> modulus_{};
        uint32_t Bg_ = 0; //size = rns //Bg_ < 32bit
        uint32_t halfBg_ = 0; ///< Bg/2
        vector<BigNUm_RNS> h_{}; ///< powers of Bgbit
        vector<NTTContext> ntt_{};

        //const TLweParams *tlwe_params; ///< Params of each row


    };




    //mod 2N
    class Ciphertext_RGSW
    {
    public:
        Ciphertext_RGSW() = default;
        Ciphertext_RGSW(const Ciphertext_RGSW &copy) = default;
        Ciphertext_RGSW(Ciphertext_RGSW &&assign) = default;
        Ciphertext_RGSW &operator=(const Ciphertext_RGSW &copy) = default;
        Ciphertext_RGSW &operator=(Ciphertext_RGSW &&assign) = default;

        inline void alloc(const Params_RGSW &params){
            auto block = params.poly_num();
            auto l = params.l();
            auto rns_num = params.modulus().size();
            auto degree = params.degree();
            data_.resize(block);
            for(auto &b : data_){
                b.resize(l);
                for(size_t i = 0; i < l; i++){
                    b[i].alloc(block,rns_num,degree);
                }
            }
        }

        [[nodiscard]] inline bool is_valid() const{
            if(data_.empty()){
                return false;
            }
            return true;
        }

        [[nodiscard]] inline bool ntt_state() const{
            return is_ntt_;
        }

        inline bool &ntt_state() {
            return is_ntt_;
        }

        [[nodiscard]] inline vector<vector<Ciphertext_TLWE>> const &data() const{
            return data_;
        }

        inline vector<vector<Ciphertext_TLWE>>  &data() {
            return data_;
        }

    private:
        vector<vector<Ciphertext_TLWE>> data_; //block * l
        bool is_ntt_ = false;
    };



    //
    class Opt_RGSW{
    public:
        inline Opt_RGSW(Params_RGSW rgswParams)
        :params_(std::move(rgswParams))
        {
            auto &modulus = params_.modulus();
            auto degree = params_.degree();
            for(auto &mod : modulus){
                ntt_.emplace_back(mod,degree);
            }
        }

        [[nodiscard]] inline const Params_RGSW &params() const{
            return params_;
        }

        void ftt_fwd( Ciphertext_RGSW &sample);
        void ftt_inv( Ciphertext_RGSW &sample);
        void add_h(Ciphertext_RGSW &result);
        void poly_decomp_h(vector<TLWEPoly> &poly_d,const TLWEPoly &tlwe_poly);
        void tlwe_decomp_h(Ciphertext_TLWE &decomp,const Ciphertext_TLWE &tlwe);
        void external_product(const Ciphertext_RGSW &sample,  Ciphertext_TLWE &accum);

//        void add_mul_h(Ciphertext_RGSW &result,const vector<uint32_t > &message);
//        void add_mul_h_scalar(Ciphertext_RGSW &result,uint32_t scalar);
//        void poly_decomp_h(vector<TLWESecretKey> &poly_d,const vector<uint32_t > &tlwe_poly);
//        void poly_decomp_h_ntt(vector<TLWESecretKey> &poly_d,const vector<uint32_t > &tlwe_poly);
//        void tlwe_decomp_h(TLWEDecomp &tlwe_d, const TLWECiphertext &ciph);
//        void tlwe_decomp_h_ntt(TLWEDecomp &tlwe_d, const TLWECiphertext &ciph);
//
//
//        void external_product_ntt(const Ciphertext_RGSW &sample,  TLWECiphertext &accum);
//        void encrypt_zero(Ciphertext_RGSW &result, double alpha, const TLWESecretKey &key);
//        void external_product(const Ciphertext_RGSW &sample,  TLWECiphertext &accum);

    private:
        Params_RGSW params_;
        vector<NTTContext> ntt_{};


    };


} // poseidon

#endif
