//
// Created by lxs on 6/8/23.
//

#ifndef POSEIDON_RGSW_CIPH_H
#define POSEIDON_RGSW_CIPH_H
#include "../KeySwitchKey.h"
#include "../SecretKey.h"
#include "TLWECiphertext.h"
namespace poseidon {
    class RGSWParams{
    public:
        inline RGSWParams(uint32_t l, uint32_t BGbit, uint32_t k,uint32_t degree, uint32_t modulus)
          :l_(l),poly_num_(k),Bgbit_(BGbit),Bg_(1 << Bgbit_),halfBg_(1 << (Bgbit_-1)),
          maskMod_(Bg_ - 1),kpl_(k * l),degree_(degree),modulus_(modulus)
        {
            h_.resize(l);
            for (int32_t i = 0; i < l; ++i) {
                int32_t kk = (32 - (i + 1) * Bgbit_);
                h_[i] = 1 << kk; // 1/(Bg^(i+1)) as a Torus32
            }

            // offset = Bg/2 * (2^(32-Bgbit) + 2^(32-2*Bgbit) + ... + 2^(32-l*Bgbit))
            uint32_t temp1 = 0;
            for (int32_t i = 0; i < l; ++i) {
                uint32_t temp0 = 1 << (32 - (i + 1) * Bgbit_);
                temp1 += temp0;
            }
            offset_ = temp1 * halfBg_;
        }

        ~RGSWParams() = default;
        RGSWParams(const RGSWParams &copy) = default;
        RGSWParams(RGSWParams &&assign) = default;
        RGSWParams &operator=(const RGSWParams &copy) = delete;
        RGSWParams &operator=(RGSWParams &&assign) = default;
        inline const uint32_t l() const{
            return l_;
        }

        inline uint32_t &l(){
            return l_;
        }

        inline const uint32_t Bgbit() const{
            return Bgbit_;
        }

        inline uint32_t &Bgbit() {
            return Bgbit_;
        }

        inline const uint32_t Bg() const{
            return Bg_;
        }

        inline const uint32_t halfBg() const{
            return halfBg_;
        }

        inline const uint32_t maskMod() const{
            return maskMod_;
        }

        inline const uint32_t kpl() const{
            return kpl_;
        }

        inline const vector<uint32_t > &h() const{
            return h_;
        }

        inline const uint32_t &offset() const{
            return offset_;
        }

        inline const uint32_t &poly_num() const{
            return poly_num_;
        }


        inline const uint32_t &degree() const{
            return degree_;
        }

        inline const uint32_t &modulus() const{
            return modulus_;
        }



    private:
        uint32_t modulus_ = 0;
        uint32_t degree_ = 0;
        uint32_t poly_num_ = 1;
        uint32_t l_ = 0; ///< decomp length
        uint32_t Bgbit_ = 0;///< log_2(Bg)
        uint32_t Bg_ = 0;///< decomposition base (must be a power of 2)
        uint32_t halfBg_ = 0; ///< Bg/2
        uint32_t maskMod_ = 0; ///< Bg-1
        //const TLweParams *tlwe_params; ///< Params of each row
        uint32_t kpl_ = 0; ///< number of rows = (k+1)*l
        vector<uint32_t > h_{}; ///< powers of Bgbit
        uint32_t offset_ = 0;
    };




    //mod 2N
    class RGSWCiphertext
    {
    public:
        RGSWCiphertext() = default;
        RGSWCiphertext(const RGSWCiphertext &copy) = default;
        RGSWCiphertext(RGSWCiphertext &&assign) = default;
        RGSWCiphertext &operator=(const RGSWCiphertext &copy) = default;
        RGSWCiphertext &operator=(RGSWCiphertext &&assign) = default;

        void alloc(const RGSWParams &params);


        inline vector<vector<TLWECiphertext>> const &data() const{
            return data_;
        }

        inline vector<vector<TLWECiphertext>>  &data() {
            return data_;
        }

    private:
        vector<vector<TLWECiphertext>> data_; //block * l
        bool is_ntt_ = false;
    };

    class RGSWOpt{
    public:
        inline RGSWOpt(RGSWParams rgswParams,const NTTContext &ntt)
        :params_(std::move(rgswParams)),ntt_(ntt)
        {}

        bool is_valid(const RGSWCiphertext &ciph);
        inline const RGSWParams &params() const{
            return params_;
        }

        TLWESecretKey get_from_secret_key(const SecretKey &key);
        void ftt_fwd( RGSWCiphertext &sample);
        void ftt_inv( RGSWCiphertext &sample);

        void add_h(RGSWCiphertext &result);
        void add_h_ntt(RGSWCiphertext &result);

        void add_mul_h(RGSWCiphertext &result,const vector<uint32_t > &message);
        void add_mul_h_scalar(RGSWCiphertext &result,uint32_t scalar);
        void poly_decomp_h(vector<TLWESecretKey> &poly_d,const vector<uint32_t > &tlwe_poly);
        void poly_decomp_h_ntt(vector<TLWESecretKey> &poly_d,const vector<uint32_t > &tlwe_poly);
        void tlwe_decomp_h(TLWEDecomp &tlwe_d, const TLWECiphertext &ciph);
        void tlwe_decomp_h_ntt(TLWEDecomp &tlwe_d, const TLWECiphertext &ciph);


        void external_product_ntt(const RGSWCiphertext &sample,  TLWECiphertext &accum);
        void encrypt_zero(RGSWCiphertext &result, double alpha, const TLWESecretKey &key);
        void external_product(const RGSWCiphertext &sample,  TLWECiphertext &accum);



    private:
        RGSWParams params_;
        NTTContext ntt_;


    };










} // poseidon

#endif
