//
// Created by lxs on 6/5/23.
//

#ifndef POSEIDON_ENCRYPTOR_H
#define POSEIDON_ENCRYPTOR_H

#include "PoseidonContext.h"
#include "PublicKey.h"
#include "SecretKey.h"
#include "Plaintext.h"
#include "rlwe.h"

namespace poseidon {

    class Encryptor {
    public:
        /**
       Creates an Encryptor instance initialized with the specified PoseidonContext
       and public key.

       @param[in] context The PoseidonContext
       @param[in] public_key The public key
       @throws std::invalid_argument if the encryption parameters are not valid
       @throws std::invalid_argument if public_key is not valid
       */
        Encryptor(const PoseidonContext &context, const PublicKey &public_key);

        /**
        Creates an Encryptor instance initialized with the specified PoseidonContext
        and secret key.

        @param[in] context The PoseidonContext
        @param[in] secret_key The secret key
        @throws std::invalid_argument if the encryption parameters are not valid
        @throws std::invalid_argument if secret_key is not valid
        */
        Encryptor(const PoseidonContext &context, const SecretKey &secret_key);

        /**
        Creates an Encryptor instance initialized with the specified PoseidonContext,
        secret key, and public key.

        @param[in] context The PoseidonContext
        @param[in] public_key The public key
        @param[in] secret_key The secret key
        @throws std::invalid_argument if the encryption parameters are not valid
        @throws std::invalid_argument if public_key or secret_key is not valid
        */
        Encryptor(const PoseidonContext &context, const PublicKey &public_key, const SecretKey &secret_key);

        /**
        Give a new instance of public key.

        @param[in] public_key The public key
        @throws std::invalid_argument if public_key is not valid
        */
        void set_public_key(const PublicKey &public_key)
        {
            public_key_ = public_key;
        }

        void encrypt_with_secret_key(const Plaintext &plain, Ciphertext &destination) const;
        void encrypt(const Plaintext &plain, Ciphertext &destination) const;




        /**
        Give a new instance of secret key.

        @param[in] secret_key The secret key
        @throws std::invalid_argument if secret_key is not valid
        */
        inline void set_secret_key(const SecretKey &secret_key)
        {
            secret_key_ = secret_key;
        }
    private:
        Encryptor(const Encryptor &copy) = delete;
        Encryptor(Encryptor &&source) = delete;
        Encryptor &operator=(const Encryptor &assign) = delete;
        Encryptor &operator=(Encryptor &&assign) = delete;
        void encrypt_internal(const Plaintext &plain, bool is_asymmetric, bool save_seed, Ciphertext &destination) const;
        PublicKey public_key_;
        SecretKey secret_key_;
        PoseidonContext context_;

    };

} // posedion

#endif //POSEIDON_ENCRYPTOR_H
