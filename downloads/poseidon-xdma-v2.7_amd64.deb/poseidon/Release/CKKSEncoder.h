#ifndef CKKS_ENCODE_H
#define CKKS_ENCODE_H

#include "define.h"
#include <gmpxx.h>


     
#include <cstdlib>
#include <cmath>
#include <complex>
#include "rns_polynomial.h"
#include "util/fft.h"
#include "PoseidonContext.h"
#include "Plaintext.h"
#include "Plaintext.h"

namespace poseidon{
    class CKKSEncoder:public FFT{
      private:
        std::shared_ptr<poseidon::CrtContext> crt_context_{ nullptr };
        int encode_rns_inter(vector<complex<double>> vec, vector<vector<uint32_t>>& result,int numSlots,const mpf_t scaling_factor,int level);
        int polyToComplexCRT(vector<vector<uint32_t>> vec, vector<complex<double>>& result,int numSlots,const mpf_t scaling_factor,int level,const mpz_t Q,bool isReal);
        int decode_rns_inter(const RNSPolynomial& poly, vector<complex<double>>& result,int  level,int numSlots,const mpf_t scaling_factor);
      public:
        inline const std::shared_ptr<poseidon::CrtContext> crt_context() const noexcept{
            return crt_context_;
        }
        using FFT::FFT;
        CKKSEncoder(const PoseidonContext& params);
        int encode_big_num(vector<complex<double>> vec,mpz_t *result,int numSlots,const mpf_t scaling_factor);

        void encode(vector<complex<double>> src, Plaintext &plain, const mpf_class scaling_factor) ;
        void encode(vector<complex<double>> res, Plaintext &plain, mpf_class scaling_factor,int level) ;


        int decode(const Plaintext &plain, vector<complex<double>>& vec) ;
        int decode_big_num(mpz_t *coeffs,vector<complex<double>>& result,int numSlots,const mpf_t scaling_factor);

    };
}

#endif